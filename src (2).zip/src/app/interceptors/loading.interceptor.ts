import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { LoaderService } from 'src/app/services/loader.service';

@Injectable()
export class LoadingInterceptor implements HttpInterceptor {

  constructor(private loadingService: LoaderService) {}

  private totalRequests = 0;

  private exclude_urls_from_loading = ['file_audit_data', 'user_login_list', 'check_fax_availability', 'trigger_list'];

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    // Remove any query parameters
    let urlWithoutQuery = request.url.split('?')[0];

    // Split the URL by '/' and get the last part
    let urlSplits = urlWithoutQuery.split('/');
    let lastUrl = urlSplits[urlSplits.length - 1];

    if (!this.exclude_urls_from_loading.includes(lastUrl)) {
      this.totalRequests++;
      this.loadingService.setLoading(true);
      return next.handle(request).pipe(
        finalize(() => {
          this.totalRequests--;
          if (this.totalRequests == 0) {
            this.loadingService.setLoading(false);
          }
        })
      );
    } else {
      return next.handle(request).pipe(
        finalize(() => {
          if (this.totalRequests == 0) {
            this.loadingService.setLoading(false);
          }
        })
      );
    }

  }
}
