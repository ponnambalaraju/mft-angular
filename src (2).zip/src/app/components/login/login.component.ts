import { CookieService } from 'ngx-cookie-service';
import { Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { MftService } from 'src/app/services/mft.service';
import { HttpParams, HttpResponse } from '@angular/common/http';
import { Users } from 'src/app/models/users';
import { PasswordInputComponent } from '../password-input/password-input.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent extends PasswordInputComponent {

  @ViewChild(PasswordInputComponent, { static: false })
  private passwordInputComponent: PasswordInputComponent;

  generatedCaptcha: string;
  userInputCaptcha: string;
  user_id_required: boolean
  empty_user_id: string = "";
  forgot_password_userid: string = '';
  authentication_type: number;
  temp_authentication_type: number;
  invalid_token: string = '';
  invalid_captcha: string = '';
  invalid_uid: string = '-';
  invalid_pwd: string = '';
  login_token: string = '';
  allowed_authentication_types: any = ''
  allowed_multifactor_authentication: any = ''
  containsUppercase: boolean = false;
  containsLowercase: boolean = false;
  containsNumber: boolean = false;
  containsSpecialCharacter: boolean = false;
  isMinLength: boolean = false;
  client_authentication_found: boolean = false;

  timer: any;
  loginForm = this.formBuilder.group({
    userid: ['', Validators.required],
    password: ['', Validators.required]
  });
  loading = false;
  //showComment = false;
  uid: string = '';
  pwd: string = '-';
  token: string = '';
  
  constructor(private cookie:CookieService, private formBuilder: FormBuilder, private router: Router, private mftServices: MftService, private loggedInUser: Users,
    public override modalService: NgbModal, public override el: ElementRef, public renderer: Renderer2) {
      super(modalService, el);
      this.generateCaptcha();
  }

  // convenience getter for easy access to form fields
  //get f() { return this.loginForm.controls; }

  generate_login_token() {
    var formData: any = new HttpParams().set('user_id', this.uid);

    this.mftServices.postData("login_token", formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.result === "SUCCESS") {
          //console.log('Token received');
          //this.mftServices.updatedAlert("The Login Token is sent to your registered mail");
          let popup_data = { process: 'Success', modalMessage: 'The Login Token is sent to your registered mail', yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
        } else {
          this.loading = false;
          let popup_data = { process: data.body.result, modalMessage: data.body.data, yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
          //this.mftServices.updatedAlert(data.body.result + " - " + data.body.data);
        }
      },
      (error) => {
          console.error('There was an error!', error.message);
          alert("Incorrect Username or Password");
          this.loading = false;
      }
    );
  }

  loginSubmit() {
    if (this.authentication_type === 5) {
      if (this.userInputCaptcha !== this.generatedCaptcha.toString()) {
        this.invalid_captcha = 'Invalid Captcha';
        return;
      }
    }
    if (this.authentication_type === 2) {
      if (this.login_token === '') {
        this.submitted = true;
        return;
      }
    }

    var formData: any = new HttpParams()
    .set('uid', this.uid)
    .set('login_token', this.login_token)
    .set('authentication_type', this.authentication_type);
    
    this.loggedInUser.setUser({ role_name: '' });
    this.mftServices.postData("login_request", formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.user_id !== undefined ) {
          const userData = { user_id: data.body.user_id, user_pk: data.body.user_pk, user_name: data.body.user_name, user_status: data.body.user_status,
            user_creation_date: data.body.user_creation_date, user_activation_date: data.body.user_activation_date, user_deactivation_date: data.body.user_deactivation_date,
            user_locked: data.body.user_locked, user_email: data.body.user_email, user_phone_no: data.body.user_phone_no, user_password: data.body.user_password,
            user_description: data.body.user_description, client_pk: data.body.client_pk, client_id: data.body.client_id, client_name: data.body.client_name,
            client_status: data.body.client_status, role_pk: data.body.role_pk, role_id: data.body.role_id, role_name: data.body.role_name, role_status: data.body.role_status, 
            allow_downloading_files: data.body.allow_downloading_files, user_created_by: data.body.user_created_by, functional_privileges_pk: data.body.functional_privileges_pk, profile_logo: data.body.profile_logo,
            app_modules_pk: data.body.app_modules_pk, client_list: data.body.client_list, table_headers_list: data.body.table_headers_list, customized_headers_list: data.body.customized_headers_list            
          };
          this.loggedInUser.setUser(userData);

          const newValue = 'New Value';
          this.mftServices.updateData(newValue);
          this.router.navigate(['dashboard']);
        } else if (data.body.result === 'FAILURE') {
          let popup_data = { process: data.body.result, modalMessage: data.body.data, yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
        } else {
          this.loading = false;
          var popup_data = { process: 'Failure', modalMessage: data.body.final_status, yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
        }
      },
      (error) => {
        console.error('There was an error!', error.message);
        this.loading = false;
        var data = { process: 'Failure', modalMessage: 'Incorrect Username or Password', yesButtonText: 'OK', isNoVisible: false };
        this.popupModalService.openMessageAlertPopupModal(data); return;
      }
    );
    this.loading = true;
  }

  forgot_password() {
    if (this.forgot_password_userid === '') {
      this.empty_user_id = 'Please enter User ID'; return;
    } else {
      this.submitted = true;

      var formData: any = new FormData();
      formData.append('user_id', this.forgot_password_userid),
      formData.append('mft_ui_address', this.mftServices.mft_ui_address)

      this.mftServices.postData("forgot_password", formData).subscribe(
        (data: HttpResponse<any>) => {
          this.handleCancelClick();
          if (data.body.result === "SUCCESS") {
            let popup_data = { process: 'Forgot Password', modalMessage: 'The password reset link is sent to your registered mail.', yesButtonText: 'OK', isNoVisible: false };
            this.popupModalService.openMessageAlertPopupModal(popup_data); return;
          } else {
            this.loading = false;
            let popup_data = { process: 'Forgot Password', modalMessage: data.body.result, yesButtonText: 'OK', isNoVisible: false };
            this.popupModalService.openMessageAlertPopupModal(popup_data); return;
          }
        },
        (error) => {
            console.error('There was an error!', error.message);
            alert("Incorrect Username or Password");
            this.loading = false;
        }
      );
    }
  }

  generateCaptcha() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let captcha = '';
    for (let i = 0; i < 6; i++) {
      const randomIndex = Math.floor(Math.random() * chars.length);
      captcha += chars.charAt(randomIndex);
    }
    this.generatedCaptcha = captcha;
  }

  refreshCaptcha() {
    this.generateCaptcha();
    this.userInputCaptcha = ''; // Clear the user input
    //this.isCorrect = false; // Reset the correctness status
  }

  onAuthenticationTypeChange(event: any) {
    this.temp_authentication_type = event.target.value;
    this.invalid_captcha = '';
    this.invalid_token = '';
  }

  updateMultiFactorView() {
    this.authentication_type = parseInt(this.temp_authentication_type.toString());
    if (this.authentication_type === 2) {
      this.generate_login_token()
    }
    this.handleCancelClick();
  }

  clearinvaliduid() {
    if (this.uid === "") {
      this.invalid_uid = '';
    } else {
      this.invalid_uid = '-'; 
    }
  }
  clearinvalidpwd() {
    this.pwd = this.passwordInputComponent.childValue;
  }

  login() {
    let childValue = this.passwordInputComponent.childValue;
    // this.cookie.set("UserDetails","User ID:-"+this.uid+",Password:-"+this.pwd)
  
    if (this.uid === "" || childValue === "" || childValue === undefined) {
      if (childValue === "" || childValue === undefined) {
        this.pwd = '';
      }
      if (this.uid === "") {
        this.invalid_uid = '';
      }
      return;
    }
    
    var formData: any = new HttpParams()
    .set('uid', this.uid)
    .set('pwd', childValue);
    
    this.mftServices.postData("login", formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.result === 'SUCCESS') {
          if (data.body.user_id !== undefined && data.body.user_id !== "") {
            const userData = { user_id: data.body.user_id, user_pk: data.body.user_pk, user_name: data.body.user_name, user_status: data.body.user_status,
              user_creation_date: data.body.user_creation_date, user_activation_date: data.body.user_activation_date, user_deactivation_date: data.body.user_deactivation_date,
              user_locked: data.body.user_locked, user_email: data.body.user_email, user_phone_no: data.body.user_phone_no, user_password: data.body.user_password,
              user_description: data.body.user_description, client_pk: data.body.client_pk, client_id: data.body.client_id, client_name: data.body.client_name,
              client_status: data.body.client_status, role_pk: data.body.role_pk, role_id: data.body.role_id, role_name: data.body.role_name, role_status: data.body.role_status, 
              allow_downloading_files: data.body.allow_downloading_files, user_created_by: data.body.user_created_by, functional_privileges_pk: data.body.functional_privileges_pk, profile_logo: data.body.profile_logo,
              app_modules_pk: data.body.app_modules_pk, client_list: data.body.client_list, table_headers_list: data.body.table_headers_list, customized_headers_list: data.body.customized_headers_list                            
            };
            this.loggedInUser.setUser(userData);
            
            const newValue = 'New Value';
            this.mftServices.updateData(newValue);
            this.router.navigate(['dashboard']);
          } else {
            this.submitted = false;
            this.client_authentication_found = true;
            this.allowed_multifactor_authentication = data.body.allowed_multifactor_authentication;
            this.authentication_type = parseInt(data.body.default_multifactor_authentication.toString());

            this.allowed_authentication_types = data.body.allowed_authentication_types;
            this.togglePanelActive(true);
          }
        }
        else {
          this.client_authentication_found = false;
          let popup_data = { process: 'Failure', modalMessage: data.body.data, yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data);
        }
      },
      (error) => {
        console.error('There was an error!', error.message);
        this.loading = false;
        let popup_data = { process: 'Failure', modalMessage: 'Incorrect Username or Password', yesButtonText: 'OK', isNoVisible: false };
        this.popupModalService.openMessageAlertPopupModal(popup_data);
      }
    );
  }
 
  backToLogin() {
    this.togglePanelActive(false);
  }
 
  private togglePanelActive(isActive: boolean): void {
    const container = this.el.nativeElement.querySelector('.container');
    if (isActive) {
      this.renderer.addClass(container, 'right-panel-active');
    } else {
      this.renderer.removeClass(container, 'right-panel-active');
    }
  }

}
