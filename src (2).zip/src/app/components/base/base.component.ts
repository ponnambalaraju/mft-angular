import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AppInjector } from 'src/app/app.module';
import { ColumnDefs } from 'src/app/column-def';
import { PopupModalService } from 'src/app/services/popup-modal.service';
import cronstrue from 'cronstrue';
import { MftService } from 'src/app/services/mft.service';

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.css']
})
export class BaseComponent {

  submitted: boolean = false;
  closeResult: string = '';
  suppressRowClickSelection = false;
  edit_disable: boolean = true;
  active_disable: boolean = true;
  deactive_disable: boolean = true;
  popupModalService = AppInjector.get(PopupModalService);
  mftService = AppInjector.get(MftService);
  transferTypeOptions: any[] = [];

  constructor(protected modalService: NgbModal) { }

  openPopup(content: any) {
    this.submitted = false;
    this.modalService.open(content, { backdrop: 'static', ariaLabelledBy: 'modal-basic-title' }).result.then(
      (result) => {
        this.closeResult = `Closed with: ${result}`;
      },
      (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      }
    );
  }

  getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  handleCancelClick() {
    this.submitted = false; // Reset submitted flag
    this.modalService.dismissAll('Cancel click'); // Close the modal window
  };

  dummyCallback = function (data: any): void { };

  httpErrorHandler(httpError: HttpErrorResponse) {
    if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
      this.popupModalService.openTimeoutModal();
    } else {
      console.error('There was an error!', httpError.message);
    }
  }

  onRowClicked(event: any) {
    const selectedRows = event.api.getSelectedRows();
  
    if (selectedRows.length <= 1) {
      event.api.deselectAll();
      event.node.setSelected(true);
    } else if (selectedRows.length === 2) {
      this.shouldSuppressRowClickSelection ();
    }
  }
  shouldSuppressRowClickSelection(): boolean {
    return this.suppressRowClickSelection = true;
  }

  disableActiveDeactive(selectedData: any, hasActive: any, hasDeactive: any): void {
    this.active_disable = true;
    this.deactive_disable = true;
    this.edit_disable = true;

    if (hasActive && hasDeactive) {
      this.active_disable = true;
      this.deactive_disable = true;
      this.edit_disable = true;
    } else if (hasActive) {
      if (selectedData.length > 1){
        this.active_disable = true;
        this.deactive_disable = false;
        this.edit_disable = true;                          
      } else {
        this.active_disable = true;
        this.deactive_disable = false;
        this.edit_disable = false;
      }
    } else if (hasDeactive) {
      this.active_disable = false;
      this.deactive_disable = true;
      this.edit_disable = true;
    } else {
      this.active_disable = true;
      this.deactive_disable = true;
      this.edit_disable = true;
    }
  }

  openMessageAlertPopup(process: string, service: string, gridApi: any) {
    let selectedPKs = gridApi.getSelectedRows().map((row: any) => row[service +'_pk']);

    let popup_data = { process: process, modalMessage: 'Are you sure you want to '+ process + '?', yesButtonText: 'Yes', isNoVisible: true, selectedPKs: selectedPKs, service: service, gridApi: gridApi };
    this.popupModalService.openMessageAlertPopupModal(popup_data); return;
  }

  customizeHeaders(gridApi: any, app_modules_pk: number, columnDefs: ColumnDefs[], initial_column: string) {
    let selectedHeadersList = gridApi.getColumnDefs().filter((column: { hide?: boolean }) => !column.hide).map((column: { headerName: string, table_headers_pk: number }) => ({
      headerName: column.headerName,
      table_headers_pk: column.table_headers_pk
    }));
    let availableHeadersList = gridApi.getColumnDefs().filter((column: { hide?: boolean, suppressColumnsToolPanel?: boolean }) => (column.hide && !column.suppressColumnsToolPanel)).map((column: { headerName: string, table_headers_pk: number }) => ({
      headerName: column.headerName,
      table_headers_pk: column.table_headers_pk
    }));

    let selected_headers = this.mftService.loggedInUser.getUser()?.customized_headers_list?.filter((customized_header: { app_modules_pk: number }) => customized_header.app_modules_pk === app_modules_pk);
    let temp_customized_headers_pk;
    if (selected_headers && selected_headers.length > 0) {
      temp_customized_headers_pk = selected_headers[0].customized_headers_pk
    }

    var data = { popup: 'customizeheaders', app_modules_pk: app_modules_pk, availableHeadersList: availableHeadersList, selectedHeadersList: selectedHeadersList, httpUrl: 'save_column_headers', customized_headers_pk: temp_customized_headers_pk, columnDefs: columnDefs, gridApi: gridApi, initial_column: initial_column };
    this.popupModalService.openModal(data);
  }

  customizedHeaderView(app_modules_pk: number, initial_column: string, columnDefs: ColumnDefs[]) {
    let loggedInUser = this.mftService.loggedInUser.getUser();
    let selected_headers = loggedInUser?.customized_headers_list?.filter((customized_header: { app_modules_pk: number }) => customized_header.app_modules_pk === app_modules_pk);
    let customized_selected_table_headers;
    if (selected_headers && selected_headers.length > 0) {
      customized_selected_table_headers = selected_headers[0].selected_table_headers;
    }

    for (let i = 0; i < loggedInUser.table_headers_list.length; i++) {
      if (loggedInUser.table_headers_list[i].app_modules_pk === app_modules_pk) {
        let tempColumnDef: ColumnDefs = {
          headerName: loggedInUser.table_headers_list[i].headerName,
          field: loggedInUser.table_headers_list[i].field,
          //hide: customized_selected_table_headers === undefined || customized_selected_table_headers.length === 0 || customized_selected_table_headers.includes(loggedInUser.table_headers_list[i].table_headers_pk.toString()) ? customized_selected_table_headers === undefined && loggedInUser.table_headers_list[i].hide ? true : false : true,
          hide: this.columnHideValidation(customized_selected_table_headers, loggedInUser, i),
          minWidth: loggedInUser.table_headers_list[i].minWidth,
          maxWidth: loggedInUser.table_headers_list[i].maxWidth,
          sortable: loggedInUser.table_headers_list[i].sortable,
          filter: loggedInUser.table_headers_list[i].filter,
          resizable: loggedInUser.table_headers_list[i].resizable,
          suppressColumnsToolPanel: loggedInUser.table_headers_list[i].suppressColumnsToolPanel,
          headerCheckboxSelection: loggedInUser.table_headers_list[i].field === initial_column ? true : false,
          checkboxSelection: loggedInUser.table_headers_list[i].field === initial_column ? true : false,
          valueGetter: '',
          table_headers_pk: loggedInUser.table_headers_list[i].table_headers_pk
        };

        if (loggedInUser.table_headers_list[i].field === 'scheduler_description') {
          tempColumnDef.valueGetter = (params: any) => this.customValueFormatter(params);
        } else if (loggedInUser.table_headers_list[i].field === 'source_transfer_type') {
          tempColumnDef.valueGetter = (params: any) => this.transferTypeValueGetter(params, 'source_transfer_type');
        } else if (loggedInUser.table_headers_list[i].field === 'destination_transfer_type') {
          tempColumnDef.valueGetter = (params: any) => this.transferTypeValueGetter(params, 'destination_transfer_type');
        } else if (loggedInUser.table_headers_list[i].field === 'client_name') {
          tempColumnDef.valueGetter = (params: any) => this.clientNameFormatter(params);
        } else {
          tempColumnDef.valueGetter = '';
        }
        if (tempColumnDef.field === initial_column) {
          columnDefs.splice(0, 0, tempColumnDef);
        } else {
          columnDefs.push(tempColumnDef);
        }
      }
    }

    if (customized_selected_table_headers !== undefined && customized_selected_table_headers.length !== 0) {
      let customized_selected_table_headers_list = customized_selected_table_headers.split('|');
      for (let i = 0; i < customized_selected_table_headers_list.length; i++) {
        let colDef = columnDefs.find((colDef: { table_headers_pk: number; }) => colDef.table_headers_pk === Number(customized_selected_table_headers_list[i]));
        let colDefIndex = columnDefs.findIndex((colDef: { table_headers_pk: number; }) => colDef.table_headers_pk === Number(customized_selected_table_headers_list[i]));

        columnDefs.splice(colDefIndex, 1);
        if (colDef !== undefined) {
          columnDefs.splice(i, 0, colDef);
        }
      }
    }
  }

  columnHideValidation(customized_selected_table_headers: any, loggedInUser: any, i: number) {
    if (customized_selected_table_headers === undefined || customized_selected_table_headers.length === 0) {
      if (loggedInUser.table_headers_list[i].suppressColumnsToolPanel) {
        return true;
      } else {
        return loggedInUser.table_headers_list[i].hide;
      }
    } else {
      if (customized_selected_table_headers.split('|').includes(loggedInUser.table_headers_list[i].table_headers_pk.toString())) {
        return false;
      } else {
        return true;
      }
    }
  }
  
  customValueFormatter(params: any) {
    return cronstrue.toString(params.data.unix_cron_expression);
  }

  clientNameFormatter(params: any) {
    let client = this.mftService.loggedInUser.getUser().client_list.find((client: {client_pk: number}) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  }

  transferTypeValueGetter(params: any, transfertype: string) {
    let transfer_type;
    if (transfertype === 'source_transfer_type') {
      transfer_type = this.transferTypeOptions.find(transfer_type => transfer_type.transfer_type_pk == params.data.source_transfer_type);
      return transfer_type.transfer_type_name;
    } else {
      let dest_transfer_type = params.data.destination_transfer_type.split('|')

      if (dest_transfer_type.length === 1) {
        transfer_type = this.transferTypeOptions.find(transfer_type => transfer_type.transfer_type_pk == params.data.destination_transfer_type);
        if (transfer_type) {
          return transfer_type.transfer_type_name;
        } else {
          return '';
        }
      } else {
        let temp_transfer_type = '';
        for (let i=0; i<dest_transfer_type.length - 1; i++ ) {
          transfer_type = this.transferTypeOptions.find(transfer_type => transfer_type.transfer_type_pk == dest_transfer_type[i]);
          temp_transfer_type += transfer_type.transfer_type_name + ' | ';
        }
        return temp_transfer_type.slice(0, -3);;
      }
    }
  }

}
