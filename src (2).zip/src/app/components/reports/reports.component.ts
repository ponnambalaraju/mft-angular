import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { SelectionChangedEvent } from 'ag-grid-community';
import { BaseComponent } from '../base/base.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent extends BaseComponent implements OnInit {

  constructor(public override modalService: NgbModal) {
    super(modalService);
  }

  selectedDate: Date;
  ColumnDefs: any;
  userLoginColumnDefs: any[] | null = null;
  fileTransferColumnDefs: any[] | null = null;
  triggersColumnDefs: any[];
  schedulersColumnDefs: any[] | null = null;
  filesColumnDefs: any[] | null = null;
  TriggersAuditReport: any[] | null = null;
  FaxReport : any[] | null = null;
  RowData: any;
  AgLoad: boolean = true;
  gridApi: any;
  gridColumnApi: any;
  IsColumnsToFit: boolean = true;
  reportType: string;
  isButtonVisible = false;
  //Commented for Ng-bootstrap multiselect
  /* myForm: FormGroup;
  ShowFilter = false;
  limitSelection = false;
  dropdownList: { item_id: number, item_text: string }[] = [];
  selectedItems: { item_id: number, item_text: string }[] = [];
  dropdownSettings:IDropdownSettings = { }; */
  export_disable: boolean = true;
  totalFileCount:number;
  startDate: Date;
  endDate: Date;
  selectedDateRange: string;

  download_disable: boolean = true;
  rowData: any[] = [];
  sourceTransferTypeOptions: any[] = [];
  destinationTransferTypeOptions: any[] = [];
  clientOptions: any[];
  triggerOptions: any[];
  public user = { user_pk: '', client_pk: '', search_client_pk: '%', search_trigger_pk: '%' };

  ngOnInit() {
    this.getReportColumns();

    //Commented for Ng-bootstrap multiselect
    /* this.dropdownList = [
      { item_id: 1, item_text: 'Mumbai' },
      { item_id: 2, item_text: 'Bangaluru' },
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' },
      { item_id: 5, item_text: 'New Delhi' }
    ];

    this.selectedItems = [{ item_id: 3, item_text: 'Pune' },
    { item_id: 4, item_text: 'Navsari' }];

    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 2,
      allowSearchFilter: true
    };
    this.myForm = this.fb.group({
      city: [this.selectedItems]
    }); */

    this.reportType = "Files_Transferred_List";

    this.mftService.data$.subscribe((value) => {
      if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
        this.user.search_client_pk = "%";
      } else {
        this.user.search_client_pk = this.mftService.loggedInUser.getUser().client_pk;
      }
      const params = new HttpParams().set('client_pk', this.user.search_client_pk);
      this.mftService.loadData("active_client_list", params).subscribe(
        (data: HttpResponse<any>) => {
          this.clientOptions = data.body;
          if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
            this.user.search_client_pk = "%";
          }
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
      this.loadTriggerData();
    });

    this.mftService.loadData("get_transfer_type_list", new HttpParams()).subscribe(
      (data: HttpResponse<any>) => {
        for (const element of data.body) {
          if (element.transfer_type_system === "SOURCE" && element.transfer_type_status === "ACTIVE") {
            this.sourceTransferTypeOptions.push(element);
          } else if (element.transfer_type_system === "DESTINATION" && element.transfer_type_status === "ACTIVE") {
            this.destinationTransferTypeOptions.push(element);
          }
        }
      },
    );
  }

  getReportColumns() {
    this.ColumnDefs = [
      { headerName: 'File Audit PK', field: 'file_audit_pk', hide: true },
      { headerName: 'File Name', field: 'file_name', sortable: true, resizable: true, headerCheckboxSelection: true, checkboxSelection: true, minWidth: 600, suppressMenu: true },
      { headerName: 'File Size', field: 'file_size', sortable: true, resizable: true, minWidth: 150, suppressMenu: true },
      { headerName: 'Transferred at', field: 'file_transfer_at', sortable: true, resizable: true, minWidth: 250, suppressMenu: true },
      { headerName: 'Transfer Status', field: 'file_transfer_status', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
      { headerName: 'Remarks', field: 'file_transfer_failure_reason', sortable: true, resizable: true, minWidth: 350, suppressMenu: true }
    ];
  }

  BindData(params: any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.setRowData(this.RowData);
    if (this.IsColumnsToFit) {
      this.gridApi.sizeColumnsToFit();
    }
  }

  //Commented for Ng-bootstrap multiselect
  /* onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  toogleShowFilter() {
    this.ShowFilter = !this.ShowFilter;
    this.dropdownSettings = Object.assign({}, this.dropdownSettings, { allowSearchFilter: this.ShowFilter });
  }

  handleLimitSelection() {
    if (this.limitSelection) {
      this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: 2 });
    } else {
      this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: null });
    }
  } */

  loadTriggerData() {
    const params = new HttpParams().set('client_pk', this.user.search_client_pk);
    this.mftService.loadData("trigger_list", params).subscribe(
      (data: HttpResponse<any>) => {
        this.triggerOptions = data.body;
        //this.user.search_trigger_pk = "%";
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  /* download_files() {

    const selectedData = this.gridApi.getSelectedRows();

    if (selectedData.length <= 0) {
      const errorMessage = "No rows selected! Please select only Amazon s3 Files.";
      this.mftService.updatedAlert(errorMessage);
      return ;
    } else {
      var file_audit_pk_list: string = ''
      file_audit_pk_list = selectedData.map((row: any) => row.file_audit_pk).join('|');


      this.mftService.downloadFile(file_audit_pk_list).subscribe((response) => {
        if (response) {
          const contentDispositionHeader = response.headers.get('Content-Disposition');
          const fileName = contentDispositionHeader
            ? contentDispositionHeader.split(';')[1].trim().split('=')[1]
            : 'downloadedFile';

          const blob = new Blob([response.body as BlobPart], {
            type: response.headers.get('Content-Type') || 'application/octet-stream',
          });

          const link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = selectedData[0].file_name + ".pdf";
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      });
    };
  } */

  export_pdf() {

    const selectedData = this.gridApi.getSelectedRows();
    if(selectedData.length <= 0) {
      return
    }


    const totalFiles = selectedData.length; // Calculate the total number of files

    // Create jsPDF instance for triggersColumnDefs with landscape orientation and A3 format
    const triggersDoc = new jsPDF({
      orientation: 'landscape',
      format: 'a3',
    });

    const selectedColumns = this.gridColumnApi.getAllDisplayedColumns().map((column: any) => column.getColDef().field);


    // Filter selectedColumns based on triggersColumnDefs
    const filteredColumns = selectedColumns.filter((column: string) => {
      const triggersColumnDefs = this.triggersColumnDefs?.find((Def: any) => Def.field === column);
      return triggersColumnDefs !== undefined; // Include only columns found in triggersColumnDefs
    });

    const headersForTriggers = filteredColumns.map((column: string) => {
      const triggersColumnDefs = this.triggersColumnDefs?.find((Def: any) => Def.field === column);
      return triggersColumnDefs?.headerName || column; // Use headerName if available, otherwise use column
    });

    const tableDataForTriggers = selectedData.map((rowData: any) =>
      filteredColumns.map((column: string) => rowData[column])
    );


    if (headersForTriggers.length > 0) {
      // Assuming triggersDoc is your PDF document object
      (triggersDoc as any).autoTable({
          head: [headersForTriggers],
          body: tableDataForTriggers,
          margin: { top: 50, left: 5, right: 5, bottom: 20 },
          styles: {
            fontSize: 8,
            halign: 'center',
            textColor: [100, 100, 100]
          },
          headStyles: { fillColor: [211, 211, 211] }
      });

      const totalPages = triggersDoc.internal.pages.length;
      const selectedRowCount = selectedData.length;

      // Function to load the logo image
      const loadLogoImage = (imageSrc: string): Promise<HTMLImageElement> => {
          return new Promise((resolve, reject) => {
              const logoImage = new Image();
              logoImage.src = imageSrc;
              logoImage.onload = () => resolve(logoImage);
              logoImage.onerror = (error) => reject(error);
          });
      };

      // Load the logo image
      loadLogoImage('/assets/images/Report.png').then((logoImage) => {
        let currentPageNumber = 1;
          for (let i = 1; i <= totalPages; i++) {
              triggersDoc.setPage(i);

              triggersDoc.setFillColor(255, 255, 255);
              triggersDoc.rect(0, 0, triggersDoc.internal.pageSize.getWidth(), 42, 'F');

              triggersDoc.setFillColor(255, 255, 255);
              triggersDoc.rect(10, 10, 30, 30, 'F');
              const imageData = logoImage.src;
              triggersDoc.addImage(imageData, 'PNG', 10, 10, 30, 30);
              triggersDoc.setFontSize(12);

              triggersDoc.setFont('helvetica', 'bold');
              triggersDoc.setTextColor(0, 0, 0);
              triggersDoc.setFontSize(23);
              triggersDoc.text('Hephzibah Technologies Inc', 50, 25);
              triggersDoc.setFontSize(16);
              triggersDoc.text('MultiProtocol File Transfer', 50, 35);

              // Add watermark text
              triggersDoc.setTextColor(200, 200, 200); // Adjust color as needed
              triggersDoc.setFontSize(16);
              triggersDoc.setFont('Roboto', 'sans-serif');
              triggersDoc.text('© Copyright 2024 - Hephzibah Technologies Inc - All Rights Reserved.', triggersDoc.internal.pageSize.getWidth() / 2, triggersDoc.internal.pageSize.getHeight() - 20, {
                  align: 'center'
              });
            triggersDoc.setFontSize(12);
            if (i !== totalPages) {
                triggersDoc.text(`Page ${i}`, triggersDoc.internal.pageSize.getWidth() - 20, triggersDoc.internal.pageSize.getHeight() - 20, {
                    align: 'right'
                });
            }
            // Add text "Total Number of Files"
            triggersDoc.setFont('helvetica',);
            triggersDoc.setTextColor(63, 81, 181);
            triggersDoc.setFontSize(8);
            triggersDoc.text(`Total No of Files : ${totalFiles}`, 5, 48); // Adjust position as needed

          }
            triggersDoc.save('Trigger Report.pdf');
            this.gridColumnApi.refreshCells();
      }).catch((error) => {
          console.error('Error loading logo image:', error);
      });
     } else{

    const doc = new jsPDF();

    const selectedColumns = this.gridColumnApi.getAllDisplayedColumns()
      .map((column: any) => column.getColDef());

    const headersForOthers = selectedColumns.map((colDef: any) => {
      const { field, headerName } = colDef;
      const userLoginColumnDefs = this.userLoginColumnDefs?.find((Def: any) => Def.field === field);
      const fileTransferColumnDefs = this.fileTransferColumnDefs?.find((Def: any) => Def.field === field);
      const schedulersColumnDefs = this.schedulersColumnDefs?.find((Def: any) => Def.field === field);
      const TriggersAuditReport = this.TriggersAuditReport?.find((Def: any) => Def.field === field);
      const FaxReport = this.FaxReport?.find((Def: any) => Def.field === field);

      return (
        userLoginColumnDefs?.headerName ||
        fileTransferColumnDefs?.headerName ||
        schedulersColumnDefs?.headerName ||
        TriggersAuditReport?.headerName ||
        FaxReport?.headerName ||
        headerName || field
      );
    });

    const tableDataForOthers = selectedData.map((rowData: any) =>
      selectedColumns.map((colDef: any) => rowData[colDef.field])
    );


    (doc as any).autoTable({
      head: [headersForOthers],
      body: tableDataForOthers,
      margin: { top: 50, left: 5, right: 5, bottom: 20 },
      styles: {
        fontSize: 8,
        halign: 'center',
        textColor: [100, 100, 100] // Set text color to black
      },
      headStyles: { fillColor: [211, 211, 211] } // Change background color of header
    });


      const totalPages = doc.internal.pages.length;
      const selectedRowCount = selectedData.length

      // Function to load the logo image
      const loadLogoImage = (imageSrc: string): Promise<HTMLImageElement> => {
          return new Promise((resolve, reject) => {
              const logoImage = new Image();
              logoImage.src = imageSrc;
              logoImage.onload = () => resolve(logoImage);
              logoImage.onerror = (error) => reject(error);
          });
      };

      // Load the logo image
      loadLogoImage('/assets/images/Report.png').then((logoImage) => {
             let currentPageNumber = 1;
          for (let i = 1; i <= totalPages; i++) {
            doc.setPage(i);

            doc.setFillColor(255, 255, 255);
            doc.rect(0, 0, doc.internal.pageSize.getWidth(), 42, 'F');

            doc.setFillColor(255, 255, 255);
            doc.rect(10, 10, 30, 30, 'F');
              const imageData = logoImage.src;
              doc.addImage(imageData, 'PNG', 10, 10, 30, 30);
              doc.setFontSize(12);

              doc.setFont('helvetica', 'bold');
              doc.setTextColor(0, 0, 0);
              doc.setFontSize(23);
              doc.text('Hephzibah Technologies Inc', 50, 25);
              doc.setFontSize(16);
              doc.text('MultiProtocol File Transfer', 50, 35);

              doc.setTextColor(100, 100, 100);
              doc.setFontSize(14);
              doc.setFont('Roboto', 'sans-serif');
              doc.text('© Copyright 2024 - Hephzibah Technologies Inc - All Rights Reserved.', doc.internal.pageSize.getWidth() / 2, doc.internal.pageSize.getHeight() -15, {
                  align: 'center'
              });
          //     doc.setFontSize(12);
          //   doc.text(`Page ${i}`, doc.internal.pageSize.getWidth() - 20, doc.internal.pageSize.getHeight() - 15, {
          //     align: 'right'
          // });
          doc.setFontSize(12);
          if (i !== totalPages) {
            doc.text(`Page ${i}`, doc.internal.pageSize.getWidth() - 20, doc.internal.pageSize.getHeight() - 15, {
                  align: 'center'
              });
          }
               // Add text "Total Number of Files"
               doc.setFont('helvetica',);
               doc.setTextColor(73, 80, 87);
               doc.setFontSize(8);
              doc.text(`Total No of Files : ${totalFiles}`, 5, 48); // Adjust position as needed
          }
          currentPageNumber++; // Increment page number outside the loop
          if (this.fileTransferColumnDefs) {
            doc.save('FileTransfer Report.pdf');
            this.gridColumnApi.refreshCells();
          } else if (this.schedulersColumnDefs) {
            doc.save('Scheduler Report.pdf');
            this.gridColumnApi.refreshCells();
          } else if (this.TriggersAuditReport) {
            doc.save('Triggers Audit Report.pdf');
            this.gridColumnApi.refreshCells();
          } else if (this.FaxReport) {
            doc.save('Fax Audit Report.pdf');
            this.gridColumnApi.refreshCells();
          }else if (this.userLoginColumnDefs) {
            doc.save('User History.pdf');
            this.gridColumnApi.refreshCells();
          }
          this.fileTransferColumnDefs = null;
          this.schedulersColumnDefs = null;
          this.TriggersAuditReport = null;
          this.FaxReport = null;
          this.userLoginColumnDefs = null;
         }).catch((error) => {
          console.error('Error loading logo image:', error);
      });
  }
}

loadChangedReportWithDateFilter() {
  if (this.reportType == "User_Login_Logout_Report") {
    this.isButtonVisible = false;
    this.userLoginColumnDefs = [
      { headerName: 'User ID', field: 'user_id', sortable: true, filter: true, headerCheckboxSelection: true, checkboxSelection: true, resizable: true, minWidth: 130 },
      { headerName: 'User Name', field: 'user_name', sortable: true, filter: true, resizable: true, minWidth: 250 },
      { headerName: 'Login Date Time', field: 'user_loggedin_at', sortable: true, filter: true, resizable: true, minWidth: 300 },
      { headerName: 'Logoff Date Time', field: 'user_loggedoff_at', sortable: true, filter: true, resizable: true, minWidth: 300 },
      { headerName: 'Login Status', field: 'user_loggedin_status', sortable: true, filter: true, resizable: true, minWidth: 350 },
      { headerName: 'Remarks', field: 'remarks', sortable: true, filter: true, resizable: true, minWidth: 350 }
    ];
    this.gridApi.setColumnDefs(this.userLoginColumnDefs);
    this.gridApi.refreshHeader();

    const params = new HttpParams().set('client_pk', this.user.search_client_pk).set('show_limited_data', false);
    this.mftService.loadData("user_login_list", params).subscribe(
      (data: HttpResponse<any>) => {
        let filteredData = data.body;
        if (this.startDate && this.endDate) {
          filteredData = data.body.filter((record: { user_loggedin_at: Date; }) => {
            const loginDate = new Date(record.user_loggedin_at);
            const startDate = new Date(this.startDate);
            const endDate = new Date(this.endDate);

            startDate.setHours(0, 0, 0);
            endDate.setHours(23, 59, 59);

            return loginDate >= startDate && loginDate <= endDate;
        });
        }
        this.gridApi.setRowData(filteredData);
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

    else if (this.reportType == "Files_Transferred_List") {
      this.fileTransferColumnDefs = [
        // { headerName: 'File Audit PK', field: 'file_audit_pk', hide: true },
        // { headerName: 'File Name', field: 'file_name', sortable: true, resizable: true, headerCheckboxSelection: true, checkboxSelection: true, minWidth: 600, suppressMenu: true },
        // { headerName: 'File Size', field: 'file_size', sortable: true, resizable: true, minWidth: 150, suppressMenu: true },
        // { headerName: 'Transferred at', field: 'file_transfer_at', sortable: true, resizable: true, minWidth: 250, suppressMenu: true },
        // { headerName: 'Transfer Status', field: 'file_transfer_status', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
        // { headerName: 'Remarks', field: 'file_transfer_failure_reason', sortable: true, resizable: true, minWidth: 350, suppressMenu: true }

        { headerName: 'Testcase ID', field: 'file_audit_pk', hide: true },
        { headerName: 'Testcase Name', field: 'file_name', sortable: true, resizable: true, headerCheckboxSelection: true, checkboxSelection: true, minWidth: 600, suppressMenu: true },
        { headerName: 'Step', field: 'file_size', sortable: true, resizable: true, minWidth: 150, suppressMenu: true },
        { headerName: 'Step Description', field: 'file_transfer_at', sortable: true, resizable: true, minWidth: 250, suppressMenu: true },
        { headerName: 'Expected Result', field: 'file_transfer_status', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
        { headerName: 'Actual Result', field: 'file_transfer_failure_reason', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
        { headerName: 'Status', field: 'file_size', sortable: true, resizable: true, minWidth: 150, suppressMenu: true },
        { headerName: 'Executed By', field: 'file_transfer_at', sortable: true, resizable: true, minWidth: 250, suppressMenu: true },
        { headerName: 'Approved By', field: 'file_transfer_status', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
        { headerName: 'Date and Time', field: 'file_transfer_failure_reason', sortable: true, resizable: true, minWidth: 350, suppressMenu: true }


      ];
      this.gridApi.setColumnDefs(this.fileTransferColumnDefs);
      this.gridApi.refreshHeader();

      const params = new HttpParams().set('client_pk', this.user.search_client_pk).set('trigger_pk', this.user.search_trigger_pk);
      this.mftService.loadData("file_list", params).subscribe(
        (data: HttpResponse<any>) => {
            let filteredData = data.body;
            if (this.startDate && this.endDate) {
              filteredData = data.body.filter((record: { file_transfer_at: Date; }) => {
                const loginDate = new Date(record.file_transfer_at);
                const startDate = new Date(this.startDate);
                const endDate = new Date(this.endDate);

                startDate.setHours(0, 0, 0);
                endDate.setHours(23, 59, 59);

                return loginDate >= startDate && loginDate <= endDate;
            });
            }
            this.gridApi.setRowData(filteredData);
            this.gridApi.refreshCells();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
    else if (this.reportType == "Triggers_List") {
      this.isButtonVisible = false;
      this.triggersColumnDefs = [
        { headerName: 'Trigger ID', field: 'trigger_id', sortable: true, filter: true, headerCheckboxSelection: true, checkboxSelection: true, resizable: true, minWidth: 250},
        { headerName: 'Trigger Status', field: 'trigger_status', sortable: true, filter: true, resizable: true, minWidth: 150 },
        { headerName: 'Trigger Creation Date', field: 'trigger_creation_date', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Trigger Activation Date', field: 'trigger_activation_date', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Trigger Created By', field: 'created_by', sortable: true, filter: true, resizable: true, minWidth: 170, hide: true },
        { headerName: 'Source Address', field: 'source_address', sortable: true, filter: true, resizable: true, minWidth: 250 },
        { headerName: 'Destination Address', field: 'destination_address', sortable: true, filter: true, resizable: true, minWidth: 300 },
        { headerName: 'Source Location', field: 'source_location', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Destination Location', field: 'destination_location', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Source Transfer Type', field: 'source_transfer_type', sortable: true, filter: true, resizable: true, minWidth: 170, valueFormatter: this.sourceTransferTypeValueFormatter.bind(this) },
        { headerName: 'Destination Transfer Type', field: 'destination_transfer_type', sortable: true, filter: true, resizable: true, minWidth: 170, valueFormatter: this.destinationTransferTypeValueFormatter.bind(this) },
        { headerName: 'Source Username', field: 'source_username', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Destination Username', field: 'destination_username', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Allowed File Types', field: 'allowed_file_types', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Trigger Deactivation Date', field: 'trigger_deactivation_date', sortable: true, filter: true, resizable: true, minWidth: 170, hide: true },
        { headerName: 'File Transferred Count', field: 'mft_filetransferred_count', sortable: true, filter: true, resizable: true, minWidth: 170, hide: true },
        { headerName: 'Last Failure', field: 'mft_last_failure', sortable: true, filter: true, resizable: true, minWidth: 170, hide: true },
        { headerName: 'Next Trigger Date Time', field: 'mft_next_trigger_date_time', sortable: true, filter: true, resizable: true, minWidth: 170, hide: true },
        { headerName: 'Total Successful Trigger', field: 'mft_total_successful_trigger', sortable: true, filter: true, resizable: true, minWidth: 170, hide: true },
        { headerName: 'Destination API URL', field: 'destination_api_url', sortable: true, filter: true, resizable: true, minWidth: 170 }
      ];
      this.gridApi.setColumnDefs(this.triggersColumnDefs);
      this.gridApi.refreshHeader();

      const params = new HttpParams().set('client_pk', this.user.search_client_pk).set('trigger_pk', this.user.search_trigger_pk);
      this.mftService.loadData("trigger_list", params).subscribe(
        (data: HttpResponse<any>) => {
          let filteredData = data.body;

        if (this.startDate && this.endDate) {
          filteredData = data.body.filter((record: { trigger_creation_date: Date; }) => {
            const creationDate = new Date(record.trigger_creation_date);
            const startDate = new Date(this.startDate);
            const endDate = new Date(this.endDate);

            startDate.setHours(0, 0, 0);
            endDate.setHours(23, 59, 59);

            return creationDate >= startDate && creationDate <= endDate;
          });
          }
          this.gridApi.setRowData(filteredData);
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
    else if (this.reportType == "Schedulers_List") {
      this.isButtonVisible = false;
      this.schedulersColumnDefs = [
        { headerName: 'Scheduler ID', field: 'scheduler_id', sortable: true, filter: true, headerCheckboxSelection: true, checkboxSelection: true, resizable: true, minWidth: 200 },
        { headerName: 'Scheduler PK', field: 'scheduler_pk', sortable: true, filter: true, resizable: true, minWidth: 200, hide: true },
        { headerName: 'Trigger PK', field: 'trigger_pk', sortable: true, filter: true, resizable: true, minWidth: 200, hide: true },
        { headerName: 'Trigger ID', field: 'trigger_id', sortable: true, filter: true, resizable: true, minWidth: 200 },
        // { headerName: 'Scheduler Start Date', field: 'scheduler_start_date', sortable: true, filter: true, resizable: true, minWidth: 250 },
        { headerName: 'Schedule Status', field: 'scheduler_status', sortable: true, filter: true, minWidth: 150 },
        // { headerName: 'Schedule type', field: 'scheduler_type', sortable: true, filter: true, minWidth: 150 },
        { headerName: 'Scheduler Creation Date ', field: 'scheduler_creation_date', sortable: true, filter: true, resizable: true, minWidth: 300 },
        { headerName: 'Last Run', field: 'scheduler_last_run', sortable: true, filter: true, resizable: true, minWidth: 300 },
        { headerName: 'Next Run', field: 'scheduler_next_run', sortable: true, filter: true, resizable: true, minWidth: 350 },
        { headerName: 'Transfer Status', field: 'file_transfer_status', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
      ];
      this.gridApi.setColumnDefs(this.schedulersColumnDefs);
      this.gridApi.refreshHeader();

      const params = new HttpParams().set('client_pk', this.user.search_client_pk);
      this.mftService.loadData("scheduler_list", params).subscribe(
        (data: HttpResponse<any>) => {
          let filteredData = data.body;

          if (this.startDate && this.endDate) {
            filteredData = data.body.filter((record: { scheduler_creation_date: Date; }) => {
              const loginDate = new Date(record.scheduler_creation_date);
              const startDate = new Date(this.startDate);
              const endDate = new Date(this.endDate);

              startDate.setHours(0, 0, 0);
              endDate.setHours(23, 59, 59);

              return loginDate >= startDate && loginDate <= endDate;
          });
          }

          if (this.user.search_trigger_pk !== '%') {
            let finalData = filteredData.filter((record: { trigger_pk: number }) => {
              return record.trigger_pk === parseInt(this.user.search_trigger_pk)
            });
            this.gridApi.setRowData(finalData);
          } else {
            this.gridApi.setRowData(filteredData);
          }
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
else if (this.reportType == "Triggers_Audit_Report") {
  this.isButtonVisible = false;
  this.TriggersAuditReport = [
    { headerName: 'Trigger Audit PK', field: 'trigger_audit_pk', hide: true },
    { headerName: 'Job Id', field: 'trigger_audit_pk', sortable: true, filter: true, resizable: true, headerCheckboxSelection: true, checkboxSelection: true, minWidth: 150, comparator: (a: number, b: number) => a > b ? 1 : (a < b ? -1 : 0) },
    { headerName: 'Start Time', field: 'trigger_start_time', sortable: true, filter: true, resizable: true, minWidth: 200 },
    { headerName: 'End Time', field: 'trigger_end_time', sortable: true, filter: true, resizable: true, minWidth: 200 },
    { headerName: 'Trigger Type', field: 'trigger_type', sortable: true, filter: true, resizable: true, minWidth: 200},
    { headerName: 'Status', field: 'trigger_status', sortable: true, filter: true, resizable: true, minWidth: 200 },
    { headerName: 'Failure Reason', field: 'trigger_failure_reason', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'Success count', field: 'no_of_files_transferred', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'Failure count', field: 'no_of_files_failed', sortable: true, filter: true, minWidth: 150 },
    { headerName: 'Trigger ID', field: 'trigger_pk', sortable: true, filter: true, minWidth: 150}
  ];
  this.gridApi.setColumnDefs(this.TriggersAuditReport);
  this.gridApi.refreshHeader();

  const params = new HttpParams().set('client_pk', this.user.search_client_pk).set('show_all_jobs', 'true');
  this.mftService.loadData("dashboard_job_list", params).subscribe(
    (data: HttpResponse<any>) => {
      let filteredData = data.body;
      this.gridApi.setRowData(filteredData);
      this.assignCellRenderer();

    },
    (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
  );
} else if (this.reportType == "Fax_Report") {
  this.isButtonVisible = false;
  this.FaxReport = [
    { headerName: 'Fax PK', field: 'fax_pk', hide: true, suppressColumnsToolPanel: true },
    { headerName: 'Fax Id', field: 'fax_id', sortable: true, filter: true, resizable: true, minWidth: 100, headerCheckboxSelection: true, checkboxSelection: true },
    { headerName: 'Status Message', field: 'status_message', sortable: true, filter: true, resizable: true, minWidth: 125},
    { headerName: 'Fax Error', field: 'fax_error', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Direction', field: 'fax_direction', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Number Pages', field: 'fax_num_pages', sortable: true, filter: true, resizable: true, minWidth: 125},
    { headerName: 'Fax Is Test', field: 'fax_is_test', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Created At', field: 'fax_created_at', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Caller ID', field: 'fax_caller_id', sortable: true, filter: true, resizable: true, minWidth: 125},
    { headerName: 'Fax From Number', field: 'fax_from_number', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Cost', field: 'fax_cost', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Recipients Phone Number', field: 'fax_recipients_phone_number', sortable: true, filter: true, resizable: true, minWidth: 125},
    { headerName: 'Fax Recipients Status', field: 'fax_recipients_status', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Recipients Retry Count', field: 'fax_recipients_retry_count', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Recipients Completed At', field: 'fax_recipients_completed_at', sortable: true, filter: true, resizable: true, minWidth: 125},
    { headerName: 'Fax Recipients Bitrate', field: 'fax_recipients_bitrate', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Recipients Resolution', field: 'fax_recipients_resolution', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Recipients Error ID', field: 'fax_recipients_error_id', sortable: true, filter: true, resizable: true, minWidth: 230 },
    { headerName: 'Fax Recipients Error Message', field: 'fax_recipients_error_message', sortable: true, filter: true, resizable: true, minWidth: 125},
    { headerName: 'Client PK', field: 'client_pk', hide: true },
    { headerName: 'User PK', field: 'user_pk', hide: true },
    { headerName: 'Trigger PK', field: 'trigger_pk', hide: true },
  ];
  this.gridApi.setColumnDefs(this.FaxReport);
  this.gridApi.refreshHeader();

  const params = new HttpParams().set('client_pk', this.user.search_client_pk).set('trigger_pk', this.user.search_trigger_pk);
  this.mftService.loadData("fax_service_list", params).subscribe(
    (data: HttpResponse<any>) => {
      let filteredData = data.body;
      this.gridApi.setRowData(filteredData);
      this.assignCellRenderer();
    },
    // (data: HttpResponse<any>) => {
    //   let filteredData = data.body;
    //   if (this.startDate && this.endDate) {
    //     filteredData = data.body.filter((record: { fax_created_at: Date; }) => {
    //       const loginDate = new Date(record.fax_created_at);
    //       const startDate = new Date(this.startDate);
    //       const endDate = new Date(this.endDate);
    //       startDate.setHours(0, 0, 0);
    //       endDate.setHours(23, 59, 59);
    //       return loginDate >= startDate && loginDate <= endDate;
    //   });
    //   }
    // },

    (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
  );
}
this.export_disable = true;
  };

  getClientValue(params: any) {
    let client = this.mftService.loggedInUser.getUser().client_list.find((client: { client_pk: any; }) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  };

  assignCellRenderer() {
    const jobIdColumn = this.TriggersAuditReport?.find(column => column.headerName === 'Job Id');
    const TriggerTypeColumn = this.TriggersAuditReport?.find(column => column.headerName === 'Trigger Type');
    const TriggerIDColumn = this.TriggersAuditReport?.find(column => column.headerName === 'Trigger ID');
    if (jobIdColumn) {
      jobIdColumn.cellRenderer = this.createHyperLink.bind(this);
      this.gridApi.setColumnDefs(this.TriggersAuditReport);
      this.gridApi.refreshHeader();
    } else {
      console.error("Column with header name 'Job Id' not found.");
    }
    if (TriggerTypeColumn) {
      TriggerTypeColumn.cellRenderer = this.getTriggerType.bind(this);
      this.gridApi.setColumnDefs(this.TriggersAuditReport);
      this.gridApi.refreshHeader();
    } else {
      console.error("Column with header name 'Trigger Type' not found.");
    }
    if (TriggerIDColumn) {
      TriggerIDColumn.cellRenderer = this.getTriggerIDValue.bind(this);
      this.gridApi.setColumnDefs(this.TriggersAuditReport);
      this.gridApi.refreshHeader();
    } else {
      console.error("Column with header name 'Trigger ID' not found.");
    }
  }


  getTriggerType(params: any) {
    if (params.data.trigger_type) {
      if (params.data.trigger_type.includes('SCHEDULER')) {
        return 'SCHEDULER';
      } else {
        return 'MANUAL';
      }
    } else {
      return '-';
    }
  }

  getTriggerIDValue(params: any) {
    return 'MFT-' + '0'.repeat(4 - params.data.trigger_pk.toString().length) + params.data.trigger_pk;
  }

  createHyperLink(params: any) {

    if (!params.data) { return document.createElement('span'); }
    const spanElement = document.createElement('span');
    spanElement.innerHTML = `<a href="#"> ${'JOB-' + '0'.repeat(5 - params.data.trigger_audit_pk.toString().length) + params.data.trigger_audit_pk} </a> `;
    spanElement.addEventListener('click', ($event) => {
      $event.preventDefault();

      const httpParams = new HttpParams().set('trigger_audit_pk', params.data.trigger_audit_pk).set('show_limited_data', false);
      this.mftService.loadData("file_list_by_job_id", httpParams).subscribe(
        (data: HttpResponse<any[]>) => {
          const newTab = window.open();
          if (newTab) {
            if (data.body !== null && data.body !== undefined) {
              newTab.document.write('<html>');

              newTab.document.write('<head>');
              newTab.document.write('<title>MFT : ' + 'JOB-' + '0'.repeat(5 - params.data.trigger_audit_pk.toString().length) + params.data.trigger_audit_pk + '</title>');
              newTab.document.write('<style>');
              newTab.document.write('body { margin: 0; padding: 0; min-height: 100vh; display: flex; flex-direction: column; }');
              newTab.document.write('html, body { height: 100%; }');
              newTab.document.write('main { flex: 1; }');
              newTab.document.write('table { border-collapse: collapse; width: 100%; }');
              newTab.document.write('th, td { border: 1px solid #dddddd; text-align: left; font-family: Roboto,sans-serif; padding: 8px; }');
              newTab.document.write('th { background-color: #f2f2f2; }');
              newTab.document.write('</style>');
              newTab.document.write('</head>');

              newTab.document.write('<body>');
              newTab.document.write('<div style="display: flex">');
              newTab.document.write('<div style="width: 30%; margin: 2px 2px 2px 10px;">');
              newTab.document.write('<img src="/assets/images/HephzibahTechnologiesLogo.png" style="width: 75px">');
              newTab.document.write('</div>');
              newTab.document.write('</div>');
              newTab.document.write('<h2 style="color: #ffffff;font-size: 18px; background-color: #4c6fbf;font-family: Roboto,sans-serif; padding: 10px;margin-top:5px; text-align: left;">MFT-Files Transferred for : ' + 'JOB-' + '0'.repeat(5 - params.data.trigger_audit_pk.toString().length) + params.data.trigger_audit_pk + '</h2>');

              newTab.document.write('<main>');
              newTab.document.write('<table>');
              newTab.document.write('<thead><tr>');
              this.filesColumnDefs?.forEach((colDef: any) => {
                newTab.document.write('<th>' + colDef.headerName + '</th>');
              });
              newTab.document.write('</tr></thead><tbody>');

              data.body.forEach((obj: any) => {
                newTab.document.write('<tr>');
                this.filesColumnDefs?.forEach((colDef: any) => {
                  newTab.document.write(`<td>${obj[colDef.field]}</td>`);
                });
                newTab.document.write('</tr>');
              });

              newTab.document.write('</tbody></table>');
              newTab.document.write('</main>');

              newTab.document.write('<footer style="text-align: center; width: 100%; color: black; background-color: #f2f2f2;font-family: Roboto,sans-serif; display: initial;">');
              newTab.document.write('<p>&copy; Copyright 2024 - Hephzibah Technologies Inc - All Rights Reserved.</p>');
              newTab.document.write('</footer>');
              newTab.document.write('</body></html>');
            } else {
              console.error('Data body is null or undefined.');
            }
            newTab.document.close();
          } else {
            console.error('Failed to open a new tab. Please check your popup settings.');
          }
        },
        (httpError: HttpErrorResponse) => {
          console.error('HTTP error:', httpError);
        }
      );
    });
    return spanElement;
  }

  onSelectionChanged(event: SelectionChangedEvent) {
    const selectedData = this.gridApi.getSelectedRows();

    this.download_disable = true;
    this.export_disable = true;

    if (selectedData.length > 0) {
      const Amazons3 = selectedData.some((item: { source_transfer_type: string, destination_transfer_type: string }) =>
        item.destination_transfer_type === '10' || item.source_transfer_type === '15'
      );

      if (Amazons3) {
        this.download_disable = false;
      } else {
        this.download_disable = true;
      }
    }
    if (selectedData.length > 0) {
      this.export_disable = false;
    } else {
      this.export_disable = true;
    }

  }
  sourceTransferTypeValueFormatter(params:any) {
    let sourceTransferType = this.sourceTransferTypeOptions.find(sourceTransfer => sourceTransfer.transfer_type_pk == params.data.source_transfer_type);
    return sourceTransferType?sourceTransferType.transfer_type_name:"";
  }

  destinationTransferTypeValueFormatter(params:any) {
    let destinationTransferType = this.destinationTransferTypeOptions.find(destinationTransfer => destinationTransfer.transfer_type_pk == params.data.destination_transfer_type);
    return destinationTransferType?destinationTransferType.transfer_type_name:"";
  }
}
