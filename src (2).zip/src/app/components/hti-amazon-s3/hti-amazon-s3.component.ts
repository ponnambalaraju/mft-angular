import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { PopupService } from 'src/app/services/popup.service';
import { BaseComponent } from 'src/app/components/base/base.component';

@Component({
  selector: 'app-hti-amazon-s3',
  templateUrl: './hti-amazon-s3.component.html',
  styleUrls: ['./hti-amazon-s3.component.css']
})
export class HtiAmazonS3Component extends BaseComponent implements OnInit {

  constructor(public override modalService: NgbModal, private mftServices: MftService, private formBuilder: FormBuilder, private popupService: PopupService) {
      super(modalService);
    }

  amazonS3Form = this.formBuilder.group({
    aws_access_key_id: new FormControl('',[Validators.required, Validators.maxLength(200),Validators.pattern(/^[A-Z 0-9 ]+$/)]),
    aws_secret_access_key: new FormControl('', [Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-zA-Z 0-9+ ]+$/)]),
    aws_s3_bucket_name: new FormControl('',[Validators.required, Validators.maxLength(30),Validators.pattern(/^[a-zA-Z0-9./-]+$/)])
  });


  ngOnInit() {
    const httpParams = new HttpParams();
    this.mftServices.loadData("load_hti_aws_s3", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.amazonS3Form.patchValue({
          aws_access_key_id: data.body.aws_access_key_id, aws_secret_access_key: data.body.aws_secret_access_key, aws_s3_bucket_name: data.body.aws_s3_bucket_name
        });
      }, 
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  save_amazon_s3() {
    this.submitted = true;
    if (this.amazonS3Form.invalid) {
      return;
    }
    
    var formData: any = new FormData();
    formData.append('aws_access_key_id', this.amazonS3Form.value['aws_access_key_id']),
    formData.append('aws_secret_access_key', this.amazonS3Form.value['aws_secret_access_key']),
    formData.append('aws_s3_bucket_name', this.amazonS3Form.value['aws_s3_bucket_name'])

    this.mftServices.postData("save_hti_aws_s3", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.mftServices.updatedAlert(data.body.result);
      },
      (httpError: HttpErrorResponse) => { 
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          this.popupService.timeoutModal();
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
    );
  }

}
