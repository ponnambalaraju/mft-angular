import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataPrePostProcessingComponent } from './data-pre-post-processing.component';

describe('DataPrePostProcessingComponent', () => {
  let component: DataPrePostProcessingComponent;
  let fixture: ComponentFixture<DataPrePostProcessingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DataPrePostProcessingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DataPrePostProcessingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
