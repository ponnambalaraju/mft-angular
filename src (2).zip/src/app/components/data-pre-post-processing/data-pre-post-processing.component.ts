import { Component } from '@angular/core';

@Component({
  selector: 'app-data-pre-post-processing',
  templateUrl: './data-pre-post-processing.component.html',
  styleUrls: ['./data-pre-post-processing.component.css'],
})
export class DataPrePostProcessingComponent {


}
