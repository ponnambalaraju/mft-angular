import { Component, TemplateRef, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BaseComponent } from 'src/app/components/base/base.component';
import { MftService } from 'src/app/services/mft.service';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { Users } from 'src/app/models/users';
import { Router } from '@angular/router';

interface FileData {
  content: string;
  mimetype: string;
}

@Component({
  selector: 'app-data-sets',
  templateUrl: './data-sets.component.html',
  styleUrls: ['./data-sets.component.css']
})
export class DataSetsComponent  extends BaseComponent {

  @ViewChild('uploadpopupmodal', { static: true }) uploadpopupmodal!: TemplateRef<any>;

  constructor(public override modalService: NgbModal, private mftServices: MftService, private loggedInUser: Users, private router: Router) {
    super(modalService);
  }

  isPopupOpen = false;
  userData: any;
  user_pk: string;

  folderOptions: any[] = [];
  acceptedFileTypes = '.csv,.tsv,.clf,.elf,.xlsx,.json';
  selectedFiles: File[] = [];
  fileUploadProgress: { [key: string]: number } = {};
  otherfolder: string = '';
  public user = { user_pk: '', client_pk: '', search_client_pk: '', role_pk: '', user_id: '', user_name: '', user_status: '', user_locked: '' }
  gridApi: any;

  openUploadPopup() {
    this.isPopupOpen = true;
  }

  closeUploadPopup() {
    this.isPopupOpen = false;
  }

  ngOnInit(): void {
    this.loadActiveFolders();
    this.loadDataSets();

    this.mftService.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      this.user_pk = this.loggedInUser.getUser().user_pk;
    });

  }


  selectFolder(dataintegration: any): void {
    if (dataintegration.dataintegration_pk === 1) {
      this.openUploadPopup();
      this.modalService.open(this.uploadpopupmodal);
    }
    console.log('Selected folder:', dataintegration);
  }

  loadActiveFolders(): void {
    const httpParams = new HttpParams();
    this.mftService.loadData("load_active_folder", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.otherfolder.includes(obj.dataintegration_pk.toString())) {
            obj.dataintegration_status = true;
          } else {
            obj.dataintegration_status = false;
          }
        });
        this.folderOptions = data.body;
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          console.error('Popup model', httpError.message);
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
      );
  }

  onFileChange(event: any): void {
    event.preventDefault();
    const files: FileList = event.target.files || event.dataTransfer.files;
    if (files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        const file: File = files[i];

        const validTypes = ['.csv', '.tsv', '.clf', '.elf', '.xlsx', '.json'];
        const fileExtension = file.name.slice(((file.name.lastIndexOf(".") - 1) >>> 0) + 2);
        if (!validTypes.includes('.' + fileExtension)) {
          alert('Invalid file type. Please select a file with one of the following extensions: .csv, .tsv, .clf, .elf, .xlsx, .json');
          continue;
        }

        this.selectedFiles.push(file);

        let progress = 0;
        const progressInterval = setInterval(() => {
          progress += Math.random() * 10;
          progress = Math.min(progress, 100);
          this.fileUploadProgress[file.name] = Math.round(progress);
          if (progress === 100) {
            clearInterval(progressInterval);
            setTimeout(() => {
              delete this.fileUploadProgress[file.name];
            }, 1000);
          }
        }, 500);
      }
    }
  }

  allowDrop(event: any): void {
    event.preventDefault();
  }

  removeFile(file: File): void {
    this.selectedFiles = this.selectedFiles.filter(f => f !== file);
  }

  uploadFile(): void {
    if (!this.selectedFiles || this.selectedFiles.length <= 0) {
      alert('Please select a file to upload!');
      return;
    } else {
      const formData: any = new FormData();
      formData.append('user_pk', this.mftService.loggedInUser.getUser().user_pk);
      formData.append('client_pk', this.mftService.loggedInUser.getUser().client_pk);

      const file = this.selectedFiles[0];
      const fileName = file.name;
      const fileSize = file.size;
      const fileType = fileName.substring(fileName.lastIndexOf('.') + 1);

      formData.append('file', file);
      formData.append('file_name', fileName);
      formData.append('file_size', fileSize);
      formData.append('file_type', fileType);

      this.mftService.postData("upload_data", formData).subscribe(
        response => {
          if (response.body && (response.body as any)['message'].includes('SUCCESS')) {
            this.mftService.updatedAlert("Upload Success.");
            window.location.reload()
          } else {
            this.mftService.updatedAlert("Failed to Upload File");

          }
          this.modalService.dismissAll('Update User');
        },
        error => { console.error(error); }
      );
    }
  }

  paramKey: string;
  paramValue: string;
  files: { [key: string]: FileData } = {};
  loadDataSets() {
    if (this.mftService.loggedInUser.getUser() !== undefined) {
      const user = this.mftService.loggedInUser.getUser();

      if (user.role_id === 'SYS_ADMIN') {
        this.paramKey = 'client_pk';
        this.paramValue = "%";
      } else if (user.role_id === 'ORG_ADMIN') {
        this.paramKey = 'client_pk';
        this.paramValue = user.client_pk;
      } else {
        this.paramKey = 'user_pk';
        this.paramValue = user.user_pk;
      }
    }

    const params = new HttpParams().set(this.paramKey, this.paramValue);
    this.mftService.loadData("load_datasets", params).subscribe(
      (data: HttpResponse<any>) => {
        this.files = data.body;

      },
      (httpError: HttpErrorResponse) => {
        super.httpErrorHandler(httpError);
      }
    );
  }

  getFileIcon(fileType: string): string {
    switch (fileType) {
      case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
        return 'assets/images/xlsx.png';
      case 'text/tab-separated-values':
        return 'assets/images/tsv.png';
      case 'application/json':
        return 'assets/images/json.png';
      case 'text/csv':
        return 'assets/images/csv.png';
      default:
        return 'assets/images/default.png';
    }
  }

  downloadFile(fileName: string, content: string, mimetype: string): void {
    const byteCharacters = atob(content);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: mimetype });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(url);
  }

  openFileInNewTab(fileName: string, content: string, mimetype: string): void {
    this.router.navigate(['/etl/wizard/fileviewer'], {
      queryParams: {
        fileName,
        content: encodeURIComponent(content),
        mimetype
      }
    });
  }





}
