import { AfterViewChecked, Component, ChangeDetectorRef } from '@angular/core';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { BaseComponent } from '../base/base.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-rolemanagement',
  templateUrl: './rolemanagement.component.html',
  styleUrls: ['./rolemanagement.component.css']
})
export class RolemanagementComponent extends BaseComponent implements AfterViewChecked {
  isCheckboxChecked: boolean = false;
  isActionsVisible: boolean = true;
    roleName: string = '';
  roles_list: any[] = [];
  functional_privileges_list: any[] = [];
  app_modules_list: any[] = [];
  selectedPrivileges: string[] = [];
  updatePrivileges:string[] = [];
  Checkedfunctional_privileges:number[]=[];
  selectedPrimaryKeys: number[] = [1, 2, 3, 4];
  http: any;
  SYSTEM: any;
  selectedModules: number[] = [];
  isIndeterminate: { [key: string]: boolean } = {};

  constructor(public override modalService: NgbModal, private formBuilder: FormBuilder, 
    private cdr: ChangeDetectorRef) { 
    super(modalService);
  }

  roleForm:FormGroup;
  showInput: boolean = false;
  selected_role_name: string = '';
  selectedFunctionalPrivileges = [];
  cloneRolePk:any;
  storedRolePk: string;
  storeRoleName:string;
  title:string='';
  clonedRoleName:string= "";
  selectionMade: boolean = false;
  colIndex: number = 1;
  specific_app_module_fun_privileges_list: string[] = [];
  module_checked_count: boolean = false
  check_mark_disable = true;

  ngOnInit() {
    this.mftService.loadData("load_functional_privileges", new HttpParams().set('client_pk', this.mftService.loggedInUser.getUser().client_pk)).subscribe(
      (data: HttpResponse<any>) => {
        this.app_modules_list = data.body.app_modules_list;
        this.functional_privileges_list = data.body.functional_privileges_list;
        this.roles_list = data.body.roles_list;
        //this.specific_app_module_fun_privileges_list = this.functional_privileges_list.filter(item => item['app_modules_pk'] === 1).map(item => item['functional_privileges_pk']);

        if (this.mftService.loggedInUser.getUser().role_id !== 'SYS_ADMIN') {
          this.app_modules_list = this.app_modules_list.filter((app_modules: { app_modules_pk: string; }) => app_modules.app_modules_pk !== '1');
        }
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
    this.updateRole(this.mftService.loggedInUser.getUser().role_pk);
    this.storeRolePk(this.mftService.loggedInUser.getUser().role_pk,this.mftService.loggedInUser.getUser().role_name)
  }

  isMooduleChecked: { [key: string]: boolean } = {};

  ngAfterViewChecked(): void {
    for (const app_module of this.app_modules_list) {
      this.specific_app_module_fun_privileges_list = this.functional_privileges_list.filter(item => item['app_modules_pk'] === app_module.app_modules_pk).map(item => item['functional_privileges_pk']);
      //const allValuesPresent = this.specific_app_module_fun_privileges_list.every(value => this.Checkedfunctional_privileges.includes(+value));

      const checked_count = this.functional_privileges_list.filter(item => item['app_modules_pk'] === app_module.app_modules_pk).map(item => item['functional_privileges_pk']).filter(value => this.Checkedfunctional_privileges.includes(+value)).length;
      if (checked_count === 0) {
        this.isMooduleChecked['checkbox'+ app_module.app_modules_pk] = false;
        this.isIndeterminate['checkbox'+ app_module.app_modules_pk] = false;
      } else if (checked_count === this.specific_app_module_fun_privileges_list.length) {
        this.isMooduleChecked['checkbox'+ app_module.app_modules_pk] = true;
        this.isIndeterminate['checkbox'+ app_module.app_modules_pk] = false;
      } else if (checked_count !== 0 && checked_count < this.specific_app_module_fun_privileges_list.length) {
        this.isIndeterminate['checkbox'+ app_module.app_modules_pk] = true;
        this.isMooduleChecked['checkbox'+ app_module.app_modules_pk] = false;
      } else {
        console.log('Issue in checking the checkbox');
      }
    }
  }

  updateCheckedState(app_modules_pk: number): void {
    for (const functional_privileges of this.functional_privileges_list.filter(item => item.app_modules_pk === app_modules_pk)) {
      console.log(functional_privileges.functional_privileges_pk);
      //this.isMooduleChecked['functional_privileges_checkbox'+ functional_privileges.functional_privileges_pk] = allValuesPresent;
    }
  }
  
  toggleInput() {
    this.showInput = !this.showInput;
    if (!this.showInput) {
      this.roleName = '';
    }
  }

  calculateModulus(value: number, modulus: number): number {
    return value % modulus;
  }
 
  cancel() {
    this.toggleInput();
  }
  save() {
    const client_pk = this.mftService.loggedInUser.getUser().client_pk;
    /* const data = {
      role_name: this.roleName,
      client_pk: client_pk
    }; */

    var formData: any = new FormData();
    formData.append('role_name', this.roleName);
    formData.append('client_pk', client_pk);

    this.mftService.postData("save_role", formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body[0].message === 'SUCCESS') {
          this.mftService.updatedAlert("The role has been saved successfully");
        } else {
          if (data.body[0].status === 'FAILURE' && data.body[0].data !== '') {
            this.mftService.updatedAlert(data.body[0].data);
          } else {
            this.mftService.updatedAlert("Failed to update the status");
          }
        }
        this.ngOnInit();
      }, (error) => { console.error('There was an error!', error.message); }
    );
    
    /* this.mftServices.saveRoleName(data).subscribe(
      (response: HttpResponse<any>) => {
        const firstElement = response.body[0];
        if (firstElement && firstElement.message === 'SUCCESS') {
          this.mftServices.updatedAlert("The role has been saved successfully");
        } else {
          this.mftServices.updatedAlert("Some Issue");
        }
        this.ngOnInit();
      },
      (error) => {
        console.error('There was an error!', error.message);
      }
    ); */
    this.toggleInput();
  }

  updateRole(rolePk:any): void {
    const clientPk = this.mftService.loggedInUser.getUser().client_pk;
    const params = new HttpParams()
      .set('client_pk', clientPk)
      .set('role_pk', rolePk);

    this.mftService.loadData("load_Checkedfunctional_privileges", params)
      .subscribe(
        (data: HttpResponse<any>) => {
          const stringArray: string[] = data.body.functional_privileges_pk.split('|');
          this.Checkedfunctional_privileges = stringArray.map(Number);                
        },
        (error: any) => {
          console.error('Error loading functional privileges:', error);
        }
      );
  }

  storeRolePk(rolePk: string, roleName:string): void {
    this.storedRolePk = rolePk;
    this.storeRoleName = roleName;
  }

  // toggleCheckbox(functionalPrivilegePk: number): void {
  //   if (this.Checkedfunctional_privileges) {
  //     if (this.Checkedfunctional_privileges.includes(functionalPrivilegePk)) {
  //       this.Checkedfunctional_privileges = this.Checkedfunctional_privileges.filter(pk => pk !== functionalPrivilegePk);
  //     } else {
  //       this.Checkedfunctional_privileges.push(functionalPrivilegePk);
  //     }
  //   }  
  // }
  toggleCheckbox(privilegePk: number) {
    // Add or remove the privilegePk from Checkedfunctional_privileges array
    if (this.Checkedfunctional_privileges.includes(privilegePk)) {
      this.Checkedfunctional_privileges = this.Checkedfunctional_privileges.filter(pk => pk !== privilegePk);
    } else {
      this.Checkedfunctional_privileges.push(privilegePk);
    }
    // Manually trigger a change detection cycle
    this.cdr.detectChanges();
  }

  isChecked(privilegePk: number): boolean {
    // Check if the privilegePk is in Checkedfunctional_privileges array
    return this.Checkedfunctional_privileges.includes(privilegePk);
  }

  toggleModuleCheckbox(app_modules_pk: any) {
    // Add or remove the module's app_modules_pk from selectedModules array
    /* if (this.isModuleSelected(module)) {
      this.selectedModules = this.selectedModules.filter(pk => pk !== module.app_modules_pk);
    } else {
      this.selectedModules.push(module.app_modules_pk);
    }

    // If module is selected, select all functional privileges within that module
    if (this.isModuleSelected(module)) {
      this.functional_privileges_list
        .filter(privilege => privilege.app_modules_pk === module.app_modules_pk)
        .forEach(privilege => {
          if (!this.isChecked(privilege.functional_privileges_pk)) {
            this.toggleCheckbox(privilege.functional_privileges_pk);
          }
        });
    } else { // If module is unselected, unselect all functional privileges within that module
      this.functional_privileges_list
        .filter(privilege => privilege.app_modules_pk === module.app_modules_pk)
        .forEach(privilege => {
          if (this.isChecked(privilege.functional_privileges_pk)) {
            this.toggleCheckbox(privilege.functional_privileges_pk);
          }
        });
    } */

    this.isMooduleChecked['checkbox'+ app_modules_pk] = !this.isMooduleChecked['checkbox'+ app_modules_pk];

    if (this.isMooduleChecked['checkbox'+ app_modules_pk]) {
      this.functional_privileges_list
        .filter(privilege => privilege.app_modules_pk === app_modules_pk)
        .forEach(privilege => {
          if (!this.isChecked(privilege.functional_privileges_pk)) {
            this.toggleCheckbox(privilege.functional_privileges_pk);
          }
        });
    } else {
      this.functional_privileges_list
        .filter(privilege => privilege.app_modules_pk === app_modules_pk)
        .forEach(privilege => {
          if (this.isChecked(privilege.functional_privileges_pk)) {
            this.toggleCheckbox(privilege.functional_privileges_pk);
          }
        });
    }

  }

  isModuleSelected(module: any): boolean {
    // Check if the module's app_modules_pk is in selectedModules array
    return this.selectedModules.includes(module.app_modules_pk);
  }

  getFunctionalPrivileges(selectedModule: any): any[] {
    if (this.isModuleSelected(selectedModule)) {
      return this.functional_privileges_list.filter(
        functional_privileges =>
          functional_privileges.app_modules_pk === selectedModule.app_modules_pk
      );
    } else {
      return [];
    }
  }

  SaveRoledata() {
    const client_pk = this.mftService.loggedInUser.getUser().client_pk;
    const formData:any = new FormData();
    formData.append('client_pk', client_pk);
    formData.append('role_pk',this.storedRolePk);
    formData.append('functional_privileges_pk', this.Checkedfunctional_privileges);
    this.mftService.postData("save_role_data",formData).subscribe(
      (response: HttpResponse<any>) => {
        const firstElement = response.body[0];
  
        if (firstElement && firstElement.message === 'SUCCESS') {
          this.mftService.updatedAlert("The role privileges have been saved successfully");
        } else {
          this.mftService.updatedAlert("Failed to save or update role privileges");
        }
  
        this.updateRole(this.storedRolePk);
      },
      (error: HttpErrorResponse) => {
        console.error('Error saving or updating role privileges:', error);
        this.mftService.updatedAlert("Failed to save or update role privileges");
      }
    );
  }

  modifyStatusRole(rolePk: any, title:string) {
    if (confirm(`Are you sure you want to "${title}"?`)) {
      const client_pk = this.mftService.loggedInUser.getUser().client_pk;
      const formData:any = new FormData();
      formData.append('role_status', title);
      formData.append('role_pk', rolePk);
      formData.append('client_pk', client_pk);
      this.mftService.postData("role_status",formData).subscribe(
        (response: HttpResponse<any>) => {
          const firstElement = response.body[0];
          if (firstElement && firstElement.message === 'SUCCESS') {
            this.mftService.updatedAlert("The role status updated successfully");
          } else {
            if (firstElement.status === 'FAILURE' && firstElement.data !== '') {
              this.mftService.updatedAlert(firstElement.data);
            } else {
              this.mftService.updatedAlert("Failed to update the status");
            }
          }
          this.ngOnInit();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
  }

  onEditRoleName(roleName: string) {
    const newName = prompt('Enter New Role name:',roleName);
    const client_pk = this.mftService.loggedInUser.getUser().client_pk;
  
    if (newName) {
      const formData:any = new FormData();
      formData.append('role_name', roleName);
      formData.append('new_role_name', newName);
      formData.append('client_pk', client_pk);
      this.mftService.postData("rename_role",formData).subscribe(
        (response: HttpResponse<any>) => {
          const firstElement = response.body[0];
          if (firstElement && firstElement.message === 'SUCCESS') {
            this.mftService.updatedAlert("The Role Name update successfully");
          } else {
            this.mftService.updatedAlert("Failed to update the Role Name");
          }
          this.ngOnInit();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
  }
  
  clonePopup (rolePk: any, content:any ,) {
    this.cloneRolePk = rolePk;
    this.openPopup(content);
    this.roleForm = this.formBuilder.group({
      clonedRoleName: ['', [Validators.required, Validators.minLength(5)]]
    });
  }

  cloneRole() {
    let clonedRoleNameValue = this.roleForm.get('clonedRoleName')?.value;

    if (this.clone_disable_validation(clonedRoleNameValue)) {
      return;
    }

    if (this.roleForm.valid) {
      const client_pk = this.mftService.loggedInUser.getUser().client_pk;
      const formData:any = new FormData();
      formData.append('role_pk', this.cloneRolePk);
      formData.append('clone_name', clonedRoleNameValue);
      formData.append('client_pk', client_pk);
      this.mftService.postData("clone_role", formData).subscribe(
        (response: HttpResponse<any>) => {
          const firstElement = response.body[0];

          if (firstElement && firstElement.message === 'SUCCESS') {
            this.mftService.updatedAlert("The Role cloned successfully");
          } else if (firstElement && firstElement.message === 'error') {
            this.mftService.updatedAlert("Role already exists with the specified name");
          } else if (firstElement && firstElement.message === 'failed') {
            this.mftService.updatedAlert("Role not found");
          }

          this.modalService.dismissAll('Update User');
          this.ngOnInit();
          // this.modalService.dismissAll();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }

  }
  
  check_mark_disable_validation() {
    if (this.roleName === '' || this.roles_list.filter((role: any) => role.role_name === this.roleName).length >= 1) {
      this.check_mark_disable = true;
    } else {
      this.check_mark_disable = false;
    }
  }

  clone_disable_validation(clonedRoleNameValue: string): boolean {
    if (clonedRoleNameValue === '' || this.roles_list.filter((role: any) => role.role_name === clonedRoleNameValue).length >= 1) {
      return true;
    } else {
      return false;
    }
  }
  
}
  

  
