import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function mobileNumberValidator(): ValidatorFn {
    // Regular expression to validate a 10-digit mobile number
    const mobileNumberPattern = /^[0-9]{10}$/;

    return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (value && value !== "" && !mobileNumberPattern.test(value)) {
      return { invalidMobileNumber: true }; // Return an error object if the format is invalid
    }

    return null; // Return null if the format is valid
  };
}