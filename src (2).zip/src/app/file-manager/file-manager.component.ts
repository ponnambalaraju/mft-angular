import { Component, Input, OnChanges, SimpleChanges, Output, EventEmitter, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { FileElement } from './model/element';
import { MatMenuTrigger } from '@angular/material/menu';
import { MatDialog } from '@angular/material/dialog';
import { NewFolderDialogComponent } from './modals/newFolderDialog/newFolderDialog.component';
import { RenameDialogComponent } from './modals/renameDialog/renameDialog.component';
import { MftService } from 'src/app/services/mft.service';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { Users } from 'src/app/models/users';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { v4 as uuidv4 } from 'uuid';
import { EncryptionService } from '../services/encryption.service';


@Component({
  selector: 'file-manager',
  templateUrl: './file-manager.component.html',
  styleUrls: ['./file-manager.component.css']
})
export class FileManagerComponent implements OnChanges {


  constructor(public dialog: MatDialog, public modalService: NgbModal, private mftServices: MftService, private loggedInUser: Users, private router: Router, private encryptionService: EncryptionService) {
  }
  @Input() fileElements: FileElement[];
  @Input() canNavigateUp: string;
  @Input() path: string;

  @Output() folderAdded = new EventEmitter<{ name: string }>();
  @Output() elementRemoved = new EventEmitter<FileElement>();
  @Output() elementRenamed = new EventEmitter<FileElement>();
  @Output() navigatedDown = new EventEmitter<FileElement>();
  @Output() elementMoved = new EventEmitter<{ element: FileElement; moveTo: FileElement }>();
  @Output() navigatedUp = new EventEmitter();

  @ViewChild('uploadpopupmodal', { static: true }) uploadpopupmodal!: TemplateRef<any>;
  @ViewChild('fileInput') fileInput!: ElementRef;

  isPopupOpen = false;
  userData: any;
  user_pk: string;
  public user = { user_pk: '', client_pk: '', search_client_pk: ''}
  selectedFiles: any;
  files: any[] = [];
  fileUploadProgress: { [key: string]: number } = {};
  folderOptions: any[] = [];
  acceptedFileTypes = '.csv,.tsv,.clf,.elf,.xlsx,.json';
  otherfolder: string = '';

  ngOnInit(): void {
    this.loadActiveFolders();
    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      this.user_pk = this.loggedInUser.getUser().user_pk;
    });
  }

  ngOnChanges(changes: SimpleChanges): void {}

  deleteElement(element: FileElement) {
    this.elementRemoved.emit(element);
  }
  public wizard = { wizard_pk: '', wizard_id: ''}
  navigate(element: FileElement) {
    this.wizard.wizard_pk = element.wizard_pk ?? '';
    this.wizard.wizard_id = element.wizard_id ?? '';
    if (element.isFolder) {
      this.navigatedDown.emit(element);
    }
  }

  navigateUp() {
    this.navigatedUp.emit();
  }

  moveElement(element: FileElement, moveTo: FileElement) {
    this.elementMoved.emit({ element: element, moveTo: moveTo });
  }

  openNewFolderDialog() {
    let dialogRef = this.dialog.open(NewFolderDialogComponent);
    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        this.folderAdded.emit({ name: res });
      }
    });
  }

  openRenameDialog(element: FileElement) {
    let dialogRef = this.dialog.open(RenameDialogComponent);
    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        element.folder_name = res;
        this.elementRenamed.emit(element);
      }
    });
  }

  openMenu(event: MouseEvent, element: FileElement, viewChild: MatMenuTrigger) {
    event.preventDefault();
    viewChild.openMenu();
  }

  // openFile(element: FileElement) {
  //   this.router.navigate(['/etl/wizard/fileviewer'], {
  //     queryParams: {
  //       folder_name: element.folder_name,
  //       content: encodeURIComponent(element.content || ''),
  //       mimetype: element.mimetype
  //     }
  //   });
  // }

  openFile(element: FileElement) {
    this.router.navigate(['/etl/wizard/fileviewer'], {
      state: { fileElement: element }
    });
  }




  openUploadPopup() {
    this.isPopupOpen = true;
  }

  closeUploadPopup() {
    this.isPopupOpen = false;
  }

  onFileChange(event: any): void {

    this.selectedFiles= event.target.files;
    if (!this.selectedFiles || this.selectedFiles.length <= 0) {
      alert('Please select a file to upload!');
      return;
    } else {
      const formData: any = new FormData();

      const file = this.selectedFiles[0];
      console.log('files:',file);

      const uploadDatasets = {
        dataset_pk : '',
        parent_folder_id : this.wizard.wizard_id,
        dataset_id : uuidv4(),
        user_pk : this.mftServices.loggedInUser.getUser().user_pk,
        client_pk : this.mftServices.loggedInUser.getUser().client_pk,
        wizard_pk : this.wizard.wizard_pk,
        file_name: file.name,
        file_size: file.size,
        file_type: file.name.substring(file.name.lastIndexOf('.') + 1),
        created_at : ''
      };
      let Data = this.encryptionService.encrypt(JSON.stringify(uploadDatasets));
      formData.append('file', file);
      formData.append('datasets_Data', Data);
      this.mftServices.postData("upload_datasets", formData).subscribe(
        response => {
          if (response.body && (response.body as any)['message'].includes('SUCCESS')) {
            this.mftServices.updatedAlert("Upload Success.");
            this.isPopupOpen = false;
          } else {
            this.mftServices.updatedAlert("Failed to Upload Datasets.");

          }
          this.modalService.dismissAll('Update User');
        },
        error => { console.error(error); }
      );
    }

}

getFileIcon(mimetype: string): string {
  switch (mimetype) {
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
      return 'assets/images/xlsx.png';
    case 'text/tab-separated-values':
      return 'assets/images/tsv.png';
    case 'application/json':
      return 'assets/images/json.png';
    case 'text/csv':
      return 'assets/images/csv.png';
    default:
      return 'assets/images/default.png';
  }
}



downloadFile(fileName: string, content: string, mimetype: string): void {
  const byteCharacters = atob(content);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  const blob = new Blob([byteArray], { type: mimetype });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  window.URL.revokeObjectURL(url);
}

openFileInNewTab(fileName: string, content: string, mimetype: string): void {
  this.router.navigate(['/etl/wizard/fileviewer'], {
    queryParams: {
      fileName,
      content: encodeURIComponent(content),
      mimetype
    }
  });
}


  selectFolder(dataintegration: any): void {
    if (dataintegration.dataintegration_pk === 1) {
      this.openUploadPopup();
      this.modalService.open(this.uploadpopupmodal);
    }
    console.log('Selected folder:', dataintegration);
  }


  loadActiveFolders(): void {
    const httpParams = new HttpParams();
    this.mftServices.loadData("load_active_folder", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.otherfolder.includes(obj.dataintegration_pk.toString())) {
            obj.dataintegration_status = true;
          } else {
            obj.dataintegration_status = false;
          }
        });
        this.folderOptions = data.body;
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          console.error('Popup model', httpError.message);
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
      );
  }

removeFile(file: File): void {
  this.selectedFiles = this.selectedFiles.filter((f: File) => f !== file);
}


  allowDrop(event: any): void {
    event.preventDefault();
  }


  uploadFile(): void {
    if (!this.selectedFiles || this.selectedFiles.length <= 0) {
      alert('Please select a file to upload!');
      return;
    } else {
      const formData: any = new FormData();
      formData.append('user_pk', this.mftServices.loggedInUser.getUser().user_pk);
      formData.append('client_pk', this.mftServices.loggedInUser.getUser().client_pk);

      const file = this.selectedFiles[0];
      const fileName = file.name;
      const fileSize = file.size;
      const fileType = fileName.substring(fileName.lastIndexOf('.') + 1);

      formData.append('file', file);
      formData.append('file_name', fileName);
      formData.append('file_size', fileSize);
      formData.append('file_type', fileType);

      this.mftServices.postData("upload_data", formData).subscribe(
        response => {
          if (response.body && (response.body as any)['message'].includes('SUCCESS')) {
            this.mftServices.updatedAlert("Upload Success.");
            window.location.reload()
          } else {
            this.mftServices.updatedAlert("Failed to Upload File");

          }
          this.modalService.dismissAll('Update User');
        },
        error => { console.error(error); }
      );
    }
  }




}
