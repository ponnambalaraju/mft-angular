import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class Users {
  private user: any;
  client_pk: any;
  passwordPattern: string = '';

  setUser(user: any): void {
    this.user = user;
    this.client_pk = user.client_pk; // Extract and store the client_pk
  }

  getClientPK(): any {
    return this.client_pk;
  }

  setPasswordPattern(pattern: string): void {
    this.passwordPattern = pattern;    
  }

  getPasswordPattern(): string {
    return this.passwordPattern;
  }

  getUser(): any {
    return this.user;
  }
}
