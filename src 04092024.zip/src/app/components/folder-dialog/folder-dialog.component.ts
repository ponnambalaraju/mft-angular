import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-folder-dialog',
  templateUrl: './folder-dialog.component.html',
  styleUrls: ['./folder-dialog.component.css']
})
export class FolderDialogComponent {
  selectedOption: string = '';
  fileToUpload: File | null = null;

  constructor(public dialogRef: MatDialogRef<FolderDialogComponent>) {}


  folders = [
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' },
    { icon: 'folder', label: 'Salesforce' }
  ];


  onOptionChange(option: string): void {
    this.selectedOption = option;
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.fileToUpload = file;
    }
  }

  uploadFile(): void {
    if (this.fileToUpload && this.selectedOption) {
      console.log('Uploading file to', this.selectedOption);
      console.log('File:', this.fileToUpload.name);
    }
    this.dialogRef.close();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
