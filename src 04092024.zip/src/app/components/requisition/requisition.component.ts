import { HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MftService } from 'src/app/services/mft.service';

@Component({
  selector: 'app-requisition',
  templateUrl: './requisition.component.html',
  styleUrls: ['./requisition.component.css']
})
export class RequisitionComponent implements OnInit {

  requisitionform: FormGroup;
  fileSelected: boolean = false;
  fileOutput: " ";
  constructor(private fb: FormBuilder,private mftServices: MftService,) {}

  ngOnInit() {

    this.requisitionform = this.fb.group({

      patient_first_name: new FormControl('',[Validators.required]),
      patient_middle_name: new FormControl(''),
      patient_last_name: new FormControl(''),
      patient_dob: new FormControl(''),
      patient_address: new FormControl(''),
      patient_city: new FormControl(''),
      patient_state: new FormControl(''),
      patient_zip_code: new FormControl(''),
      patient_phone_number: new FormControl(''),
      patient_sex: new FormControl(''),
      patient_race: new FormControl(''),
      patient_ethnicity: new FormControl(''),
      
      billing_first_name: new FormControl(''),
      billing_last_name: new FormControl(''),
      billing_patient: new FormControl(''),
      billing_address: new FormControl(''),
      billing_city: new FormControl(''),
      billing_state: new FormControl(''),
      billing_zip_code: new FormControl(''),
      billing_phone_number: new FormControl(''),

      billing_primary_insurance: new FormControl(''),
      billing_insurance_carrier: new FormControl(''),
      billing_policy_holder: new FormControl(''),
      billing_dob: new FormControl(''),
      billing_insurance_id: new FormControl(''),
      billing_group: new FormControl(''),
      billing_authorization: new FormControl(''),
      billing_secondary_insurance_carrier: new FormControl(''),
      billing_policy_holder_name: new FormControl(''),
      billing_secondary_insurance_id: new FormControl(''),
      billing_Relationship_to_Insured: new FormControl(''),

      billing_account_number: new FormControl(''),
      billing_institution_name: new FormControl(''),
      billing_institution_address: new FormControl(''),

      provider_first_name: new FormControl(''),
      provider_last_name: new FormControl(''),
      provider_facility_name: new FormControl(''),
      provider_address: new FormControl(''),
      provider_city: new FormControl(''),
      provider_state: new FormControl(''),
      provider_zip_code: new FormControl(''),
      provider_phone_number: new FormControl(''),
      provider_npi: new FormControl(''),

      patient_icd_code: new FormControl(''),
      patient_medical_record_number: new FormControl(''),
      billing_Relationship_to_Insured_other: new FormControl(''),

      specimen_date: new FormControl(''),
      specimen_time: new FormControl(''),

      sign: new FormControl(''),
      sign_date: new FormControl(''),
      Printed_name: new FormControl(''),
      sign_provider: new FormControl(''),
      provider_date: new FormControl(''),



      self_pay: new FormControl(''),
      responsible_party_patient: new FormControl(''),
      responsible_party_other: new FormControl(''),
      insurance: new FormControl(''),
      insurance_commercial: new FormControl(''),
      insurance_medicare: new FormControl(''),
      insurance_abn: new FormControl(''),
      insurance_medicare_advantage: new FormControl(''),
      insurance_other: new FormControl(''),
      institution_client: new FormControl(''),
      precivity_ad2: new FormControl(''),
      precivity_adr: new FormControl(''),
      precivity_apoe: new FormControl(''),
      precivity_ad2_precivity_apoe: new FormControl(''),
      precivity_ad2reflex_preciivity_apoe: new FormControl(''),
      yes: new FormControl(''),
      no: new FormControl(''),
      patient_not_applicable: new FormControl(''),
      printed_not_applicable: new FormControl(''),
      self: new FormControl(''),
      spouse: new FormControl(''),
      other_RtoPatient: new FormControl(''),
    });
  }

  save_form() {
    const formData = this.requisitionform.value;
    console.log(formData);
    // this.mftServices.postData("save_form", formData).subscribe(
    //   (data: HttpResponse<any>) => {
    //   }, (error) => { console.error('There was an error!', error.message); }
    // );
  }
  
  results : any = {};
  results2: any = {};
  valueArray:{ [key: string]: string }[] = [];
  onChange(event: Event) {
    var fileInput = event.target as HTMLInputElement;
    if (fileInput.files && fileInput.files.length > 0) {
      var file = fileInput.files[0];
      var reader = new FileReader();
      reader.onload = (e: any) => {
        this.fileOutput = e.target.result;
        const regex = /\/T\((.*?)\)\/V\((.*?)\)>/g;
        let match;
        while ((match = regex.exec(this.fileOutput)) !== null) {
            const token = match[1];
            const value = match[2];
            console.log(`Token: ${token}`);
            console.log(`Value: ${value}`);
            this.results[token] = value;
          }
          console.log(this.results);
        if (!match) {
            console.log('No matches found');
        }
        this.resultscheckbox();
      };
      reader.readAsText(file);
    }
  }

  resultscheckbox(){
    const regex = /\/T\(([^)]*)\)(\/V\/([^>]*)>>)?/g;
    let match;
    while ((match = regex.exec(this.fileOutput)) !== null) {
      const token = match[1];
      const value = match[3] || 'false' || 'true';
      console.log(`Token: ${token}`);
      console.log(`Value: ${value}`);
      this.results2[token] = value;
      
      const booleanResultObject: { [key: string]: boolean } = {};
        for (const key in this.results2) {
          booleanResultObject[key] = this.results2[key] === 'true';
        }
        console.log(this.results);
        console.log(this.results2);

      this.requisitionform.patchValue({
        patient_first_name: this.results.patient_first_name,
        patient_middle_name:this.results.patient_middle_name,
        patient_last_name:this.results.patient_last_name,
        patient_dob:this.results.patient_dob,
        patient_address:this.results.patient_address,
        patient_city:this.results.patient_city,
        patient_state:this.results.patient_state,
        patient_zip_code:this.results.patient_zip_code,
        patient_phone_number:this.results.patient_phone_number,

        patient_race:this.results.patient_race,
        patient_ethnicity:this.results.patient_ethnicity,
        patient_sex:this.results.patient_sex,
        patient_icd_code:this.results.patient_icd_code,

  
        billing_first_name:this.results.billing_first_name,
        billing_last_name:this.results.billing_last_name,
        billing_patient:this.results.billing_patient,
        billing_address:this.results.billing_address,
        billing_city:this.results.billing_city,
        billing_state:this.results.billing_state,
        billing_zip_code:this.results.billing_zip_code,
        billing_phone_number:this.results.billing_phone_number,
  
        billing_primary_insurance:this.results.billing_primary_insurance,
        billing_insurance_carrier:this.results.billing_insurance_carrier,
        billing_policy_holder:this.results.billing_policy_holder,
        billing_dob:this.results.billing_dob,
        billing_insurance_id:this.results.billing_insurance_id,
        billing_group:this.results.billing_group,
        billing_authorization:this.results.billing_authorization,
        billing_secondary_insurance_carrier:this.results.billing_secondary_insurance_carrier,
        billing_policy_holder_name:this.results.billing_policy_holder_name,
        billing_secondary_insurance_id:this.results.billing_secondary_insurance_id,
        billing_Relationship_to_Insured_other:this.results.billing_Relationship_to_Insured_other,
  
        billing_account_number:this.results.billing_account_number,
        billing_institution_name:this.results.billing_institution_name,
        billing_institution_address:this.results.billing_institution_address,
  
        provider_first_name:this.results.provider_first_name,
        provider_last_name:this.results.provider_last_name,
        provider_facility_name:this.results.provider_facility_name,
        provider_address:this.results.provider_address,
        provider_city:this.results.provider_city,
        provider_state:this.results.provider_state,
        provider_zip_code:this.results.provider_zip_code,
        provider_phone_number:this.results.provider_phone_number,
        provider_npi:this.results.provider_npi,

        patient_medical_record_number:this.results.patient_medical_record_number,
  
        specimen_date:this.results.specimen_date,
        specimen_time:this.results.specimen_time,
  
        sign:this.results.sign,
        sign_date:this.results.sign_date,
        Printed_name:this.results.Printed_name,
        sign_provider:this.results.sign_provider,
        provider_date:this.results.provider_date,

        self_pay: booleanResultObject['checkbox_Self_Pay'],
        insurance: booleanResultObject['checkbox_Insurance'],
        institution_client: booleanResultObject['checkbox_Institution_Client'],

        responsible_party_patient: booleanResultObject['checkbox_Patient_RP'],
        responsible_party_other: booleanResultObject['checkbox_Other_RP'],
        insurance_commercial: booleanResultObject['checkbox_Commercial_Insurance'],
        insurance_medicare: booleanResultObject['checkbox_Medicare'],
        insurance_abn: booleanResultObject['checkbox_ABN'],
        insurance_medicare_advantage: booleanResultObject['checkbox_Medicare_adv'],
        insurance_other: booleanResultObject['checkbox_Other_Insurance'],
        precivity_ad2: booleanResultObject['checkbox_PrecivityAD2TM'],
        precivity_adr: booleanResultObject['checkbox_PrecivityAD2R'],
        precivity_apoe: booleanResultObject['checkbox_PrecivityAPOETM'],
        precivity_ad2_precivity_apoe: booleanResultObject['checkbox_PrecivityAD2-PrecivityAPOETM'],
        precivity_ad2reflex_preciivity_apoe: booleanResultObject['checkbox_PrecivityAD2_reflex-PrecivityAPOETM'],
        yes: booleanResultObject['checkbox_Yes'],
        no: booleanResultObject['checkbox_No'],
        patient_not_applicable: booleanResultObject['checkbox_Not_Applicable_Patient'],
        printed_not_applicable: booleanResultObject['checkbox_Not_Applicable_Printed_Name'],
        self: booleanResultObject['checkbox_Self'],
        spouse: booleanResultObject['checkbox_Spouse'],
        other_RtoPatient: booleanResultObject['checkbox_Other_RtoPatient'],
        });  
    }
  } 
}
