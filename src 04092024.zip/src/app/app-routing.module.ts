import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from 'src/app/components/dashboard/dashboard.component';
import { TriggersComponent } from 'src/app/components/triggers/triggers.component';
import { SchedulersComponent } from 'src/app/components/schedulers/schedulers.component';
import { ReportsComponent } from 'src/app/components/reports/reports.component';
import { UsercreationComponent } from 'src/app/components/usercreation/usercreation.component';
import { ClientsetupComponent } from 'src/app/components/clientsetup/clientsetup.component';
import { LoginComponent } from 'src/app/components/login/login.component';
import { DepartmentComponent } from 'src/app/components/department/department.component';
import { PasswordresetComponent } from 'src/app/components/passwordreset/passwordreset.component';
import { AuthenticationpolicyComponent } from 'src/app/components/authenticationpolicy/authenticationpolicy.component';
import { AWSS3Component } from 'src/app/components/aws-s3/aws-s3.component';
import { RolemanagementComponent } from 'src/app/components/rolemanagement/rolemanagement.component';
import { RequisitionComponent } from 'src/app/components/requisition/requisition.component';
import { Hl7Component } from 'src/app/components/hl7/hl7.component';
import { AwsS3ReportsComponent } from 'src/app/components/aws-s3-reports/aws-s3-reports.component';
import { MailtemplateComponent } from './mailtemplate/mailtemplate.component';
import { ProfileComponent } from './profile/profile.component';
import { FaxprofileComponent } from './faxprofile/faxprofile.component';
import { FaxserviceComponent } from './faxservice/faxservice.component';
import { PreprocessingComponent } from './components/preprocessing/preprocessing.component';
import { WizardComponent } from './components/wizard/wizard.component';
import { FileViewerComponent } from './components/file-viewer/file-viewer.component';
import { WorkflowDesignerComponent } from './components/workflow-designer/workflow-designer.component';
import { RecordsComponent } from './components/records/records.component';





const routes: Routes = [
  { path: '', component: LoginComponent, title: 'MFT - Login' },
  { path: 'dashboard', component: DashboardComponent, title: 'MFT - Dashboard' },
  { path: 'triggers', component: TriggersComponent, title: 'MFT - Triggers' },
  { path: 'schedulers', component: SchedulersComponent, title: 'MFT - Schedulers' },
  { path: 'reports', component: ReportsComponent, title: 'MFT - Reports' },
  { path: 'admin/clientsetup', component: ClientsetupComponent, title: 'MFT - Client Setup' },
  { path: 'admin/groupsprojects', component: DepartmentComponent, title: 'MFT - Groups & Projects' },
  { path: 'admin/usermanagement', component: UsercreationComponent, title: 'MFT - User Management' },
  { path: 'admin/logmanagement', component: ClientsetupComponent, title: 'MFT - Log Management' },
  { path: 'admin/authenticationpolicy', component: AuthenticationpolicyComponent, title: 'MFT - Authentication Policy'},
  { path: 'admin/passwordreset', component: PasswordresetComponent, title: 'MFT - Password Reset' },
  { path: 'admin/hti-amazons3', component: AWSS3Component, title: 'MFT - (HTI) - Amazon S3' },
  { path: 'admin/rolemanagement', component: RolemanagementComponent, title: 'MFT - Role Management' },
  { path: 'requisition', component: RequisitionComponent, title: 'MFT - Requisition' },
  { path: 'hl7', component: Hl7Component, title: 'MFT - HL7 Messages' },
  { path: 'aws_s3_reports', component: AwsS3ReportsComponent, title: 'MFT - AWS S3 Reports' },
  { path: 'mailtemplate', component: MailtemplateComponent, title: 'MFT - Mail Template' },
  { path: 'profile', component: ProfileComponent, title: 'MFT - My Profile' },
  { path: 'faxprofile', component: FaxprofileComponent, title: 'MFT - Fax Profile ' },
  { path: 'faxservice', component: FaxserviceComponent, title: 'MFT - Fax Service ' },
  { path: 'etl/records', component: RecordsComponent, title: 'ETL - Record ' },
  { path: 'etl/wizard', component: WizardComponent, title: 'ETL - wizard ' },
  { path: 'etl/logic', component: PreprocessingComponent, title: 'ETL - Conditional Logic ' },
  { path: 'etl/wizard/fileviewer', component: FileViewerComponent, title: 'ETL - File Viewer ' },
  { path: 'etl/workflowdesigner', component: WorkflowDesignerComponent, title: 'ETL - Workflow designer '},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
