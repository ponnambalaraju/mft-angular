import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'stripambersend'
})
export class StripambersendPipe implements PipeTransform {

  transform(input: string): string {
    return input.replace(/&/g, "");;
  }

}
