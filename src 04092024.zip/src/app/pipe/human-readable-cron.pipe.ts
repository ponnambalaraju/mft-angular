import { Pipe, PipeTransform } from '@angular/core';
import cronstrue from 'cronstrue';

@Pipe({
  name: 'humanReadableCron'
})
export class HumanReadableCronPipe implements PipeTransform {
  private timeRegex = /(\d+:\d+ [AP]M),/gi

  transform(cronString: string, selection?: string): any {
    const humanReadableString = cronstrue.toString(cronString)
    if (selection === 'time') {
      const matches = this.timeRegex.exec(humanReadableString)
      if(matches && matches.length > 1) {
        return matches.slice(1).join(', ')
      }
      console.error('no matches!')
    }
    return humanReadableString;
  }

}