import { Injectable } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PopupTemplateComponent } from '../components/popup-template/popup-template.component';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class PopupService {

  constructor(public dialog: MatDialog, private router: Router) { }

  popupOpen = false;

  openModal(title:string, message:string, yes:Function, no:Function, isNoVisible: boolean, yesButtonText: string) {

    if (!this.popupOpen) {
      this.popupOpen = true;

      const dialogConfig = new MatDialogConfig();

      // dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.data = {
          title: title,
          message: message,
          isNoVisible: isNoVisible,
          yesButtonText: yesButtonText
      };
      dialogConfig.minWidth = 400;

      const dialogRef = this.dialog.open(PopupTemplateComponent, dialogConfig);

      dialogRef.afterClosed().subscribe(result => {
        this.popupOpen = false;
        if(result){
          if(yes){
            yes();
          }
        }else{
          if(no){
            no();
          }
        }
          
      });
    }
  }

  timeoutModal() {
    if (!this.popupOpen) {
      this.popupOpen = true;

      const dialogConfig = new MatDialogConfig();

      // dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.data = {
          title: 'Session Expired',
          message: 'Your session has expired. Please Login again',
          isNoVisible: false,
          yesButtonText: 'OK'
      };
      dialogConfig.minWidth = 400;
      const dialogRef = this.dialog.open(PopupTemplateComponent, dialogConfig);

      dialogRef.afterClosed().subscribe(result => {
        this.popupOpen = false;
        this.router.navigate(['']);
      });
    }
  }

}
