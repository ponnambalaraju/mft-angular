import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { v4 as uuidv4 } from 'uuid';
import { FileElement } from '../file-manager/model/element';

export interface IFileService {
  add(fileElement: FileElement): FileElement;
  delete(id: string): void;
  update(id: string, update: Partial<FileElement>): void;
  queryInFolder(folderId: string): Observable<FileElement[]>;
  get(id: string): FileElement | undefined;
}

@Injectable({
  providedIn: 'root',
})
export class FileService implements IFileService {
  private map = new Map<string, FileElement>();
  private querySubject: BehaviorSubject<FileElement[]>;

  constructor() {
    this.querySubject = new BehaviorSubject<FileElement[]>([]);
  }

  add(fileElement: FileElement) {
    if (!fileElement.wizard_id) {
      fileElement.wizard_id = uuidv4();
    }
    this.map.set(fileElement.wizard_id!, this.clone(fileElement));
    return fileElement;
  }

  delete(wizard_id: string): void {
    this.map.delete(wizard_id);
  }

  update(wizard_id: string, update: Partial<FileElement>): void {
    let element = this.map.get(wizard_id);
    if (element) {
      element = Object.assign(element, update);
      this.map.set(element.wizard_id!, element);
    }
  }

  queryInFolder(folderId: string): Observable<FileElement[]> {
    const result: FileElement[] = [];
    this.map.forEach(element => {
      if (element.parent_id === folderId) {
        result.push(this.clone(element));
      }
    });
    this.querySubject.next(result);
    return this.querySubject.asObservable();
  }


  get(id: string): FileElement | undefined {
    return this.map.get(id);
  }

  private clone(element: FileElement): FileElement {
    return JSON.parse(JSON.stringify(element));
  }
}
