export interface ColumnDefs {
    headerName: string,
    field: string,
    hide: boolean,
    minWidth: number,
    maxWidth: number,
    sortable: boolean,
    filter: boolean,
    resizable: boolean,
    suppressColumnsToolPanel: boolean,
    headerCheckboxSelection: boolean,
    checkboxSelection: boolean,
    valueGetter: any,
    table_headers_pk: number
}