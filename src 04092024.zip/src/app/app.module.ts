import { Injector, Injectable, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { MatExpansionModule } from '@angular/material/expansion';
import { AgGridModule } from 'ag-grid-angular';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbdDatepickerPopup } from 'src/app/components/common/datepicker/datepicker-popup';
import { NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { MftService } from './services/mft.service';
import { BaseComponent } from 'src/app/components/base/base.component';
import { UsercreationComponent } from 'src/app/components/usercreation/usercreation.component';
import { ClientsetupComponent } from 'src/app/components/clientsetup/clientsetup.component';
import { LoginComponent } from 'src/app/components/login/login.component';
import { NgChartsModule } from 'ng2-charts';
import { SpinnerComponent } from 'src/app/components/common/spinner/spinner.component';
import { LoadingInterceptor } from 'src/app/interceptors/loading.interceptor';
import { DepartmentComponent } from 'src/app/components/department/department.component';
import { DashboardComponent } from 'src/app/components/dashboard/dashboard.component';
import { TriggersComponent } from 'src/app/components/triggers/triggers.component';
import { SchedulersComponent } from 'src/app/components/schedulers/schedulers.component';
import { ReportsComponent } from 'src/app/components/reports/reports.component';
import { MyaccountComponent } from 'src/app/components/myaccount/myaccount.component';
import { StripambersendPipe } from 'src/app/pipe/stripambersend.pipe';
import { ReplacePipe } from 'src/app/pipe/replace.pipe';
import { PasswordresetComponent } from 'src/app/components/passwordreset/passwordreset.component';
import { PasswordInputComponent } from 'src/app/components/password-input/password-input.component';
import { PopupTemplateComponent } from 'src/app/components/popup-template/popup-template.component';
import { AuthenticationpolicyComponent } from 'src/app/components/authenticationpolicy/authenticationpolicy.component';
import { Bs5UnixCronModule } from '@sbzen/ng-cron';
import { HumanReadableCronPipe } from 'src/app/pipe/human-readable-cron.pipe';
import { AWSS3Component } from 'src/app/components/aws-s3/aws-s3.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { RolemanagementComponent } from 'src/app/components/rolemanagement/rolemanagement.component';
//import { IntlInputPhoneModule } from 'intl-input-phone';
import { NgxIntlTelInputModule } from 'ngx-intl-tel-input';
import "ag-grid-enterprise";
import { HashLocationStrategy, Location, LocationStrategy } from '@angular/common';
import { PopupModalComponent } from 'src/app/components/popup-modal/popup-modal.component';
import { RequisitionComponent } from 'src/app/components/requisition/requisition.component';
import { Hl7Component } from 'src/app/components/hl7/hl7.component';
import { AwsS3ReportsComponent } from 'src/app/components/aws-s3-reports/aws-s3-reports.component';
import { MailtemplateComponent } from './mailtemplate/mailtemplate.component';
import { ProfileComponent } from './profile/profile.component';
import { FaxprofileComponent } from './faxprofile/faxprofile.component';
import { FaxserviceComponent } from './faxservice/faxservice.component';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { MatTableModule } from '@angular/material/table';
import { PreprocessingComponent } from './components/preprocessing/preprocessing.component';
import { WizardComponent } from './components/wizard/wizard.component';
import { MatCardModule } from '@angular/material/card';
import { FileManagerModule } from './file-manager/file-manager.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FileService } from './services/file.service';
import { FileViewerComponent } from './components/file-viewer/file-viewer.component';
import { WorkflowDesignerComponent } from './components/workflow-designer/workflow-designer.component';
import { RecordsComponent } from './components/records/records.component';
import { MatOptionModule } from '@angular/material/core';




/**
 * This Service handles how the date is rendered and parsed from keyboard i.e. in the bound input field.
 */
@Injectable()
export class CustomDateParserFormatter extends NgbDateParserFormatter {
  readonly DELIMITER = '/';

  parse(value: string): NgbDateStruct | null {
    if (value) {
      const date = value.split(this.DELIMITER);
      return {
        day: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        year: parseInt(date[2], 10),
      };
    }
    return null;
  }

  format(date: NgbDateStruct | null): string {
    return date
      ? date.month + this.DELIMITER + date.day + this.DELIMITER + date.year
      : '';
  }
}

export let AppInjector: Injector;

@NgModule({
  declarations: [
    NgbdDatepickerPopup,
    AppComponent,
    BaseComponent,
    DashboardComponent,
    TriggersComponent,
    HumanReadableCronPipe,
    MyaccountComponent,
    SchedulersComponent,
    ReportsComponent,
    UsercreationComponent,
    ClientsetupComponent,
    LoginComponent,
    SpinnerComponent,
    DepartmentComponent,
    StripambersendPipe,
    ReplacePipe,
    PasswordresetComponent,
    PasswordInputComponent,
    PopupTemplateComponent,
    AWSS3Component,
    RolemanagementComponent,
    AuthenticationpolicyComponent,
    PopupModalComponent,
    RequisitionComponent,
    Hl7Component,
    AwsS3ReportsComponent,
    MailtemplateComponent,
    ProfileComponent,
    FaxprofileComponent,
    FaxserviceComponent,
    PreprocessingComponent,
    WizardComponent,
    FileViewerComponent,
    WorkflowDesignerComponent,
    RecordsComponent,
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AgGridModule,
    NgbModule,
    HttpClientModule,
    NgChartsModule,
    MatExpansionModule,
    MatCardModule,
    NgMultiSelectDropDownModule.forRoot(),
    Bs5UnixCronModule,
    NgApexchartsModule,
    NgxIntlTelInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    MatDialogModule,
    MatInputModule,
    MatListModule,
    MatRadioModule,
    MatToolbarModule,
    MatMenuModule,
    MatTableModule,
    FileManagerModule,
    FlexLayoutModule,
    MatOptionModule,
  ],
  providers: [
    { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },Location, {provide: LocationStrategy, useClass: HashLocationStrategy}, MftService, FileService, { provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true }
  ],
  bootstrap: [AppComponent],
  entryComponents: [ PopupTemplateComponent ],
})

export class AppModule {
  constructor(private injector: Injector) {
    AppInjector = this.injector;
  }
}

platformBrowserDynamic().bootstrapModule(AppModule);
