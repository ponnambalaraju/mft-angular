import { Component , VERSION } from '@angular/core';
import { MftService } from '../services/mft.service';
import { Users } from '../models/users';
import { BaseComponent } from '../components/base/base.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent extends BaseComponent {

  userData: any;
  url: any;
  gridApi: any;
  userForm: FormGroup;
  previewImage: any;
  uploadedImage: string | ArrayBuffer | null = null;
  allowedFileTypes = ['jpg', 'jpeg', 'png'];
  maxFileSize = 500000; 

  constructor(public override modalService: NgbModal,private mftServices: MftService, private loggedInUser: Users,private formBuilder: FormBuilder ) { 
    super(modalService);
  }
  ngOnInit() {
    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      if(this.userData.profile_logo )
      this.uploadedImage = 'data:image/png;base64,' + this.userData.profile_logo;
    });
    
    this.popupModalService.showMessageAlertPopupModal.subscribe((result :{ show: boolean }) => {
      if (!result.show) {
      }
    });
  }
  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    
    if (file) {
      const fileType = file.name.split('.').pop()?.toLowerCase();
      if (fileType && this.allowedFileTypes.includes(fileType)) {
        if (file.size <= this.maxFileSize) {    
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = () => {
            this.uploadedImage = reader.result;
          };
        } else {
          this.showFileSizeError();
          return;
        }
        var formData: any = new FormData();
        formData.append('profile_logo',file), 
        formData.append('user_pk',this.userData.user_pk)     
        this.mftServices.postData("save_logo", formData).subscribe(
          (data: HttpResponse<any>) => {
            if (data.body.result === 'SUCCESS') { 
              window.location.reload()
            }            
            },
            (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
          );
      }
      } else {
        this.showFileTypeError();
        return;
      }      
    }

    removeUserProfile(){
      var formData: any = new FormData();
      formData.append('user_pk',this.userData.user_pk)
      this.mftServices.postData("remove_logo", formData).subscribe(
        (data: HttpResponse<any>) => {
          if (data.body.result === 'SUCCESS') {
            window.location.reload()
          }
          },
          (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
        );
    }

  showFileTypeError() {
    const popup_data = { process: 'Failure', modalMessage: 'Invalid file type. Please upload a JPG or PNG file.', yesButtonText: 'OK', isNoVisible: false };
    this.popupModalService.openMessageAlertPopupModal(popup_data);
  }

  showFileSizeError() {
    const popup_data = { process: 'Failure', modalMessage: 'File size exceeds the allowed limit. Please upload a file less than 500KB.', yesButtonText: 'OK', isNoVisible: false };
    this.popupModalService.openMessageAlertPopupModal(popup_data);
  }
}