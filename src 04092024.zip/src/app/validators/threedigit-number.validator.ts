import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

// Define a custom validator for a 3-digit number
export function threeDigitNumberValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {

    const value = control.value;

    if (value === null || value === '') {
      // Allow empty input
      return null;
    }

    if (isNaN(value) || value < 0 || value > 999 || value % 1 !== 0) {
      return { invalidNumber: true };
    }
    return null;
  };
}