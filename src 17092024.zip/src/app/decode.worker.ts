
self.onmessage = (event) => {
    const { content } = event.data;
    const binaryString = atob(content);
    const byteLength = binaryString.length;
    const uint8Array = new Uint8Array(byteLength);
  
    for (let i = 0; i < byteLength; i++) {
      uint8Array[i] = binaryString.charCodeAt(i);
    }
  
    self.postMessage(uint8Array);
  };