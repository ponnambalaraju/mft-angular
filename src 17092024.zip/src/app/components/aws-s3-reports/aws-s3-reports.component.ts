import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AppInjector } from 'src/app/app.module';
import { Users } from 'src/app/models/users';
import { MftService } from 'src/app/services/mft.service';
import { PopupModalService } from 'src/app/services/popup-modal.service';
import { SelectionChangedEvent } from 'ag-grid-community';

@Component({
  selector: 'app-aws-s3-reports',
  templateUrl: './aws-s3-reports.component.html',
  styleUrls: ['./aws-s3-reports.component.css']
})
export class AwsS3ReportsComponent implements OnInit {
  
  gridApi: any;
  columnDefs: any;
  search_client_pk: any;
  popupModalService = AppInjector.get(PopupModalService);

  constructor(public mftService: MftService) { }

  ngOnInit() {

    this.search_client_pk = '%';

    this.columnDefs = [
      { headerName: 'ID', valueGetter: "node.rowIndex + 1", headerCheckboxSelection: true, checkboxSelection: true,sortable: true, filter: true,  resizable: true, minWidth: 350 },
      { headerName: 'ETag', field: 'ETag', hide: true },
      { headerName: 'client_pk', field: 'client_pk', hide: true },
      { headerName: 'File Name', field: 'file_name', sortable: true, filter: true, resizable: true, minWidth: 360 },
      { headerName: 'File Size', field: 'file_size', sortable: true, filter: true, resizable: true, minWidth: 360 },
      { headerName: 'Last Modified', field: 'last_modified', sortable: true, filter: true,  resizable: true, minWidth: 770 }
    ];
  }

  awsS3ReportsDataBind(params: any) {  
    this.gridApi = params.api;
    this.gridApi.setRowData([]);
    this.gridApi.refreshCells();
  }

  load_aws_s3_reports_list() {
    if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      if (this.search_client_pk === undefined) {
        this.search_client_pk = '%';
      }
    } else {
      this.search_client_pk = this.mftService.loggedInUser.getUser().client_pk;
    }

    let params = new HttpParams().set('client_pk', this.search_client_pk);
    this.mftService.loadData("load_aws_s3_reports_list", params).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.result === 'SUCCESS') {
          this.mftService.updatedAlert(data.body.result);
          this.gridApi.setRowData(data.body.data);
          this.gridApi.refreshCells();
        } else {
          let popup_data = { modalTitle: 'Failure', modalMessage: data.body.result, yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
        }
      },
      (httpError: HttpErrorResponse) => { 
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          this.popupModalService.openTimeoutModal();
        } else {
          console.error('There was an error!', httpError.message);
        }
       }
    );
  }

  download_files() {
    let selectedData = this.gridApi.getSelectedRows();

    if (selectedData.length <= 0) {
      const errorMessage = "No rows selected! Please select only Amazon s3 Files.";
      this.mftService.updatedAlert(errorMessage);
      return ;
    } else {
      let file_list: string = selectedData.map((row: any) => row.file_name).join('|');

      this.mftService.aws_s3_download_files(file_list, selectedData[0].client_pk).subscribe((response) => {
        if (response) {
          let blob = new Blob([response.body as BlobPart], {
            type: response.headers.get('Content-Type') || 'application/octet-stream',
          });

          let link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = file_list.split('|')[0].split('/')[0] + '.zip';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      });
    };
  }

}
