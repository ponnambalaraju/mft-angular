import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientsetupComponent } from './clientsetup.component';

describe('ClientsetupComponent', () => {
  let component: ClientsetupComponent;
  let fixture: ComponentFixture<ClientsetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientsetupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClientsetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
