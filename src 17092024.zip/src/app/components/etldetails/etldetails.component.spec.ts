import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EtldetailsComponent } from './etldetails.component';

describe('EtldetailsComponent', () => {
  let component: EtldetailsComponent;
  let fixture: ComponentFixture<EtldetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EtldetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EtldetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
