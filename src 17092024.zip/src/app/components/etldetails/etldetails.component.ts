import { Component } from '@angular/core';

@Component({
  selector: 'app-etldetails',
  templateUrl: './etldetails.component.html',
  styleUrls: ['./etldetails.component.css']
})
export class EtldetailsComponent {

}
