import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { PopupModalService } from 'src/app/services/popup-modal.service';

@Component({
  selector: 'app-authenticationpolicy',
  templateUrl: './authenticationpolicy.component.html',
  styleUrls: ['./authenticationpolicy.component.css']
})
export class AuthenticationpolicyComponent {

  default_authentication: any = '';
  allowed_authentication: string = '';
  selectedAuthenticationPolicyPK: number;
  activeAuthenticationPolicyPK: number;
  selectedAuthenticationPolicyName: string | null;
  alphabetic_character: number = 0;
  lowercase_character: number = 0;
  uppercase_character: number = 0;
  number_character: number = 0;
  special_character: number = 0;
  consecutive_character: number = 0;
  loginname_consecutive_character: number = 0;
  number_consecutive_character: number = 0;
  email_consecutive_character: number = 0;
  min_length_character: number = 0;
  max_length_character: number = 8;
  reset_char: number = 0;
  pass_case_char: number = 0;
  morethan_char: number = 0;
  time_char: number = 0;
  unsuccessful_attempts: number = 0;
  lock_duration: number = 0;
  lock_minutes: number = 0;
  reset_password_link_expiry: number = 0;
  
  alphabetic_character_isChecked: boolean = true;
  lower_character_isChecked: boolean = true;
  upper_character_isChecked: boolean = true;
  numeric_character_isChecked: boolean = true;
  special_character_isChecked: boolean = true;
  consecutive_character_isChecked: boolean = false;
  user_id_consecutive_isChecked: boolean = false;
  phone_num_consecutive_isChecked: boolean = false;
  userEmail_consecutive_isChecked: boolean = false;
  min_max_isChecked: boolean = false;
  password_identical_isChecked: boolean = false;
  reset_password_isChecked: boolean = false;
  case_insensitive_isChecked: boolean = false;
  Users_cannot_change_password_isChecked: boolean = false;
  unsuccessful_login_attempts_isChecked: boolean = false;
  reset_password_link_expiry_isChecked: boolean = false;

  // In your component class
  saveButtonClicked = false;
  check_mark_disable = true;
  isLoading: boolean = true;
  showInput: boolean = false;
  policyName: string = '';
  activeClient: any;
  isActiveClients: string[] = [];
  isProcessing: boolean = false;
  isActivationProcessing: boolean = false;
  userData: any;
  policyNames: string[] = [];
  activeAuthenticationTypes: any[] = [];
  authentication_polices: any[] = [];

  constructor(private mftService: MftService, private modalService: NgbModal, private popupModalService: PopupModalService) {}
  
  ngOnInit() {
    const params = new HttpParams().set('client_pk', this.mftService.loggedInUser.getUser().client_pk);
    this.mftService.loadData("load_client_polices", params).subscribe(
      (data: HttpResponse<any>) => {
        this.authentication_polices = data.body;
        this.activeAuthenticationPolicyPK = this.selectedAuthenticationPolicyPK = data.body.filter((authentication_policy: { policy_status: string }) => authentication_policy.policy_status === 'ACTIVE').map((authentication_policy: { authentication_policy_pk: number }) => authentication_policy.authentication_policy_pk)[0];
        this.selectedAuthenticationPolicyName = data.body.filter((authentication_policy: { policy_status: string }) => authentication_policy.policy_status === 'ACTIVE').map((authentication_policy: { policy_name: string }) => authentication_policy.policy_name)[0];
        this.fetchPolicyData(this.selectedAuthenticationPolicyPK);
      },
      (httpError: HttpErrorResponse) => { 
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          this.popupModalService.openTimeoutModal();
        } else {
          console.error('There was an error!', httpError.message);
        }
       }
    );

    const httpParams = new HttpParams();
    this.mftService.loadData("load_active_authentication_types", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        //this.activeAuthenticationTypes = data.body;
        data.body.forEach((obj: any) => {
          if (this.allowed_authentication !== '' && this.allowed_authentication.includes(obj.authentication_type_pk.toString())) {
            obj.authentication_type_status = 'ACTIVE';
          } else {
            obj.authentication_type_status = 'INACTIVE';
          }
        });

        this.activeAuthenticationTypes = data.body;
        //this.activeAuthenticationTypes = data.body.filter((item: any) => item.authentication_type_status === 'ACTIVE' && this.otherAuthentications.includes(item.authentication_type_pk.toString()))
      },
      (httpError: HttpErrorResponse) => { 
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          this.popupModalService.openTimeoutModal();
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
    );
  }
  
  toggleInput() {
    this.showInput = !this.showInput;
    if (!this.showInput) {
      this.policyName = '';
    }
  }

  check_mark_disable_validation() {
    if (this.policyName === '' || this.authentication_polices.filter((policy: any) => policy.policy_name === this.policyName).length >= 1) {
      this.check_mark_disable = true;
    } else {
      this.check_mark_disable = false;
    }
  }

  save() {
    var formData: any = new FormData();
    formData.append('policy_name', this.policyName);
    formData.append('client_pk', this.mftService.loggedInUser.getUser().client_pk);

    this.mftService.postData('save_policy', formData).subscribe(
      (response: any) => {
        this.mftService.updatedAlert(response.body.message);
        this.policyNames.push(this.policyName);          
        this.authentication_polices.push({ authentication_policy_pk: response.body.pkValue, client_pk: this.mftService.loggedInUser.getUser().client_pk, policy_name: this.policyName, policy_status: 'INACTIVE' });
        this.toggleInput();
      }, (error: any) => { console.error('Error saving client name:', error); }
    );
  }

  fetchPolicyData(authentication_policy_pk: number): void {
    this.selectedAuthenticationPolicyPK = authentication_policy_pk;

    const params = new HttpParams().set('authentication_policy_pk', authentication_policy_pk);
    this.mftService.loadData("load_policy_data", params).subscribe((response: HttpResponse<any>) => {
      const data = response.body;
      
      this.alphabetic_character = data.alphabetic_character;
      this.lowercase_character = data.lowercase_character;
      this.uppercase_character = data.uppercase_character;
      this.number_character = data.number_character;
      this.special_character = data.special_character;
      this.consecutive_character = data.consecutive_character;
      this.loginname_consecutive_character = data.loginname_consecutive_character;
      this.number_consecutive_character = data.number_consecutive_character;
      this.email_consecutive_character = data.email_consecutive_character;
      this.min_length_character = data.min_length_character;
      this.max_length_character = data.max_length_character;
      this.reset_char = data.reset_char;
      this.pass_case_char = data.pass_case_char;
      this.morethan_char = data.morethan_char;
      this.time_char = data.time_char;
      this.unsuccessful_attempts = data.unsuccessful_attempts;
      this.lock_duration = data.lock_duration;
      this.lock_minutes = data.lock_minutes;
      this.default_authentication = data.login_pagetype !== null ? parseInt(data.login_pagetype.toString()) : '';
      this.allowed_authentication = data.dual_authentication_type;
      this.alphabetic_character_isChecked = data.alphabetic_character_isChecked = true;
      this.lower_character_isChecked = data.lower_character_isChecked = true;
      this.upper_character_isChecked = data.upper_character_isChecked = true;
      this.numeric_character_isChecked = data.numeric_character_isChecked = true;
      this.special_character_isChecked = data.special_character_isChecked = true;
      this.consecutive_character_isChecked = data.consecutive_character_isChecked;
      this.user_id_consecutive_isChecked = data.user_id_consecutive_isChecked;
      this.phone_num_consecutive_isChecked = data.phone_num_consecutive_isChecked;
      this.userEmail_consecutive_isChecked = data.userEmail_consecutive_isChecked;
      this.min_max_isChecked = data.min_max_isChecked;
      this.password_identical_isChecked = data.password_identical_isChecked;
      this.reset_password_isChecked = data.reset_password_isChecked;
      this.case_insensitive_isChecked = data.case_insensitive_isChecked;
      this.Users_cannot_change_password_isChecked = data.Users_cannot_change_password_isChecked;
      this.unsuccessful_login_attempts_isChecked = data.unsuccessful_login_attempts_isChecked;
      this.reset_password_link_expiry_isChecked = data.reset_password_link_expiry_isChecked;
      this.reset_password_link_expiry = data.reset_password_link_expiry;
      this.isProcessing = false;

      this.activeAuthenticationTypes.forEach((obj: any) => {
        if (this.allowed_authentication  !== null && this.allowed_authentication !== '' && this.allowed_authentication.includes(obj.authentication_type_pk.toString())) {
          obj.authentication_type_status = 'ACTIVE';
        } else {
          obj.authentication_type_status = 'INACTIVE';
        }
      });

    });
  }

  /* allowed_authenticationupdate(authentication_type: number) {
    this.activeAuthenticationTypes.forEach((obj: any) => {
      if (obj.authentication_type_pk === authentication_type) {
        if (obj.authentication_type_status === false) {
          obj.authentication_type_status = true;
        } else {
          obj.authentication_type_status = false;
        }
      }
    });
  } */

  selectedAuthentications(selected_authentication_type: string) {
    if (this.allowed_authentication === null) {
      this.allowed_authentication = '';
    }
    if (this.allowed_authentication === '') {
      this.allowed_authentication = selected_authentication_type.toString();
    } else {
      if (this.allowed_authentication.includes(selected_authentication_type)) {
        this.allowed_authentication = this.allowed_authentication.replace(new RegExp(selected_authentication_type, 'g'), '');
      } else {
        this.allowed_authentication += '|' + selected_authentication_type;
      }
    }
    if (this.allowed_authentication.startsWith("|")) {
      this.allowed_authentication = this.allowed_authentication.substring(1);
    }
  }

  onSaveClick() {

    this.saveButtonClicked = true;

    if (this.activate_save_validation()) {
      var formData: any = new FormData();
      formData.append('policy_name', this.selectedAuthenticationPolicyName),
      formData.append('alphabetic_character', this.alphabetic_character),
      formData.append('lowercase_character', this.lowercase_character),
      formData.append('uppercase_character', this.uppercase_character),
      formData.append('number_character', this.number_character),
      formData.append('special_character', this.special_character),
      formData.append('consecutive_character', this.consecutive_character),
      formData.append('loginname_consecutive_character', this.loginname_consecutive_character),
      formData.append('number_consecutive_character', this.number_consecutive_character),
      formData.append('email_consecutive_character', this.email_consecutive_character),
      formData.append('min_length_character', this.min_length_character),
      formData.append('max_length_character', this.max_length_character),
      formData.append('reset_char', this.reset_char),
      formData.append('pass_case_char', this.pass_case_char),
      formData.append('morethan_char', this.morethan_char),
      formData.append('time_char', this.time_char),
      formData.append('unsuccessful_attempts', this.unsuccessful_attempts),
      formData.append('lock_duration', this.lock_duration),
      formData.append('lock_minutes', this.lock_minutes),
      formData.append('default_authentication', this.default_authentication),
      formData.append('otherAuthentications', this.allowed_authentication),
      formData.append('alphabetic_character_isChecked', this.alphabetic_character_isChecked),
      formData.append('lower_character_isChecked', this.lower_character_isChecked),
      formData.append('upper_character_isChecked', this.upper_character_isChecked),
      formData.append('numeric_character_isChecked', this.numeric_character_isChecked),
      formData.append('special_character_isChecked', this.special_character_isChecked),
      formData.append('consecutive_character_isChecked', this.consecutive_character_isChecked),
      formData.append('user_id_consecutive_isChecked', this.user_id_consecutive_isChecked),
      formData.append('phone_num_consecutive_isChecked', this.phone_num_consecutive_isChecked),
      formData.append('userEmail_consecutive_isChecked', this.userEmail_consecutive_isChecked),
      formData.append('min_max_isChecked', this.min_max_isChecked),
      formData.append('password_identical_isChecked', this.password_identical_isChecked),
      formData.append('reset_password_isChecked', this.reset_password_isChecked),
      formData.append('case_insensitive_isChecked', this.case_insensitive_isChecked),
      formData.append('Users_cannot_change_password_isChecked', this.Users_cannot_change_password_isChecked),
      formData.append('unsuccessful_login_attempts_isChecked', this.unsuccessful_login_attempts_isChecked),
      formData.append('client_pk', this.mftService.loggedInUser.getUser().client_pk), // Include client_pk in the data object
      formData.append('reset_password_link_expiry', this.reset_password_link_expiry),
      formData.append('reset_password_link_expiry_isChecked', this.reset_password_link_expiry_isChecked),
      formData.append('authentication_policy_pk', this.selectedAuthenticationPolicyPK);
    
      this.mftService.postData("save_policy_data", formData).subscribe(
        (response) => {
          this.mftService.updatedAlert("SUCCESS");

          this.authentication_polices = this.authentication_polices.map(authentication_policy => {
            if (authentication_policy.authentication_policy_pk === this.selectedAuthenticationPolicyPK) {
                // Create a new object with the updated name
                return { ...authentication_policy, saved: true };
            }
            // Return the original object for other ids
            return authentication_policy;
          });

        },
        (error) => { console.error('Error saving data:', error); }
      );
    }

  }

  delete_policy(authentication_policy_pk: number, policyName: string, policy_status: String) {

    if (policy_status === 'ACTIVE') {
      let popup_data = { process: 'Failure', modalMessage: 'Please activate another policy before deleting active policy', yesButtonText: 'Yes' };
      this.popupModalService.openMessageAlertPopupModal(popup_data); return;
    }

    if (confirm(`Are you sure you want to delete ${policyName}?`)) {

      var formData: any = new FormData();
      formData.append('authentication_policy_pk', authentication_policy_pk);

      this.mftService.postData("delete_policy", formData).subscribe(
        (data: HttpResponse<any>) => {
          if (data.body.result === 'SUCCESS') {
            //this.modalService.dismissAll('Save Client');
            this.mftService.updatedAlert(data.body.result);

            let authenticationPolicyIndex = this.authentication_polices.findIndex(authentication_policy => authentication_policy.authentication_policy_pk === authentication_policy_pk )
            if (authenticationPolicyIndex !== -1) {
              // Remove the object from the array if found
              this.authentication_polices.splice(authenticationPolicyIndex, 1);
            }
          }
        },
        (httpError: HttpErrorResponse) => { this.mftService.updatedAlert('FAILURE'); }
      );
    }
  }

  activate_save_validation(): boolean {
    if ( !this.alphabetic_character_isChecked && !this.lower_character_isChecked && !this.upper_character_isChecked && !this.numeric_character_isChecked && !this.special_character_isChecked && !this.min_max_isChecked ) {
      this.mftService.updatedAlert("Please select at least one character type");
      return false;
    }
    if (this.consecutive_character_isChecked && (this.consecutive_character <= 0 || this.consecutive_character === null)) {
      this.mftService.updatedAlert("There was an error! Consecutive character");      
      return false;
    }
    if (this.user_id_consecutive_isChecked && (this.loginname_consecutive_character <= 0 || this.loginname_consecutive_character === null)) {
      this.mftService.updatedAlert("There was an error! User ID consecutive character");      
      return false;
    }
    if (this.phone_num_consecutive_isChecked && (this.number_consecutive_character <= 0 || this.number_consecutive_character === null)) {
      this.mftService.updatedAlert("There was an error! Phone number consecutive character");      
      return false;
    }
    if (this.userEmail_consecutive_isChecked && (this.email_consecutive_character <= 0 || this.email_consecutive_character === null)) {
      this.mftService.updatedAlert("There was an error! Email consecutive character");      
      return false;
    }

    /* if (this.min_max_isChecked && this.min_length_character <= 0 || this.max_length_character === null || this.max_length_character <= 0 || this.max_length_character === null) {
      this.mftService.updatedAlert("There was an error! Minimun and Maximum character");      
      return
    } */
    if (this.password_identical_isChecked && (this.reset_char <= 0 || this.reset_char === null)) {
      this.mftService.updatedAlert("There was an error! Password Identical character");      
      return false;
    }
    if (this.reset_password_isChecked && (this.pass_case_char <= 0 || this.pass_case_char === null)) {
      this.mftService.updatedAlert("There was an error! Pasword Reset ");      
      return false;
    }
    if (this.reset_password_link_expiry_isChecked && (this.reset_password_link_expiry <= 0 || this.reset_password_link_expiry === null)) {
      this.mftService.updatedAlert("There was an error! Password Reset Expiry link");      
      return false;
    }
    if (this.Users_cannot_change_password_isChecked && (this.morethan_char <= 0 || this.morethan_char === null || this.time_char <= 0 || this.time_char === null)) {
      this.mftService.updatedAlert("There was an error! Users Cannot Change Pasword ");      
      return false;
    }
    if (this.unsuccessful_login_attempts_isChecked && (this.unsuccessful_attempts <= 0 || this.unsuccessful_attempts === null || this.lock_duration <= 0 || this.lock_duration === null || this.lock_minutes <= 0 || this.lock_minutes === null)) {
      this.mftService.updatedAlert("There was an error! Login Unsuccessful");      
      return false;
    }
    if (this.alphabetic_character_isChecked && (this.alphabetic_character <= 0 || this.alphabetic_character === null)) {
      this.mftService.updatedAlert("There was an error! Alphabetic character");      
      return false;
    }
    
    if (this.lower_character_isChecked && (this.lowercase_character <= 0 || this.lowercase_character === null)) {
      this.mftService.updatedAlert("There was an error! Lowercase character");      
      return false;
    }
    if (this.upper_character_isChecked && (this.uppercase_character <= 0 || this.uppercase_character === null)) {
      this.mftService.updatedAlert("There was an error! Uppercase character ");      
      return false;
    }
    if (this.numeric_character_isChecked && (this.number_character <= 0 || this.number_character === null)) {
      this.mftService.updatedAlert("There was an error! Numeric character");      
      return false;
    }
    if (this.special_character_isChecked && (this.special_character <= 0 || this.special_character === null)) {
      this.mftService.updatedAlert("There was an error! Special character");      
      return false;
    }
    if (this.default_authentication === '') {
      this.mftService.updatedAlert("Please select the default authentication type.");      
      return false;
    }
    return true;
  }

  rename_policy(authentication_policy_pk: number, policy_name: string) {
    const newPolicyName = prompt('Enter new policy name:', policy_name);    
    if (newPolicyName) {
      var formData: any = new FormData();
      formData.append('new_policy_name', newPolicyName),
      formData.append('authentication_policy_pk', authentication_policy_pk)
      formData.append('client_pk', this.mftService.loggedInUser.getUser().client_pk)

      this.mftService.postData("rename_policy", formData).subscribe(
        (data: HttpResponse<any>) => {
          if (data.body.status === 'SUCCESS') {

            // Update the name of the object with id 2 to 'Alice'
            this.authentication_polices = this.authentication_polices.map(authentication_policy => {
              if (authentication_policy.authentication_policy_pk === authentication_policy_pk) {
                  // Create a new object with the updated name
                  return { ...authentication_policy, policy_name: newPolicyName };
              }
              // Return the original object for other ids
              return authentication_policy;
            });

          }
          this.mftService.updatedAlert(data.body.message);
        },
        (error) => {
          console.error('Error renaming client:', error);
        }
      );
    }
  }
  
  updatePolicyStatus(authentication_policy_pk: number, policy_saved: boolean): void {

    if (policy_saved === null || policy_saved === undefined || !policy_saved) {
      this.mftService.updatedAlert('Please update the policy information before activating.'); return;
    }

    if (this.activate_save_validation()) {
      var formData: any = new FormData();
      formData.append('authentication_policy_pk', authentication_policy_pk);
      formData.append('client_pk', this.mftService.loggedInUser.getUser().client_pk)
  
      this.mftService.postData("update_policy_status", formData).subscribe(
        (data: HttpResponse<any>) => {
          this.mftService.updatedAlert(data.body.message);
          this.activeAuthenticationPolicyPK = authentication_policy_pk;
          this.ngOnInit();
        }
      );
    }
  }

  onKeyDown(event: KeyboardEvent): void {
    // Allow arrow keys (37-40) and backspace (8)
    if (!((event.keyCode >= 37 && event.keyCode <= 40) || event.keyCode === 8)) {
      event.preventDefault();
    }
  }

}
