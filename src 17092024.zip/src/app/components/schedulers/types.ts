export type CronJobFields = 'hours' | 'minutes' | 'daysofmonths' | 'month' | 'daysofweek';

export type CronJobValues = Record<CronJobFields, string>;

export const cronJobValues: CronJobValues = {
  hours: '0',
  minutes: '0',
  daysofmonths: '*',
  month: '*',
  daysofweek: '*',
};

export {}