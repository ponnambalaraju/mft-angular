import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { BaseComponent } from 'src/app/components/base/base.component';
import { Users } from 'src/app/models/users';
import { SelectionChangedEvent } from 'ag-grid-community';

@Component({
  selector: 'app-aws-s3',
  templateUrl: './aws-s3.component.html',
  styleUrls: ['./aws-s3.component.css']
})
export class AWSS3Component extends BaseComponent implements OnInit {

  userData: any;
  gridApi: any;
  currentEvent: string;
  awsS3ColumnDefs: any;
  clientOptions: any[] = [];
  
  constructor(public override modalService: NgbModal, private mftServices: MftService, private formBuilder: FormBuilder, private loggedInUser: Users) {
    super(modalService);
  }

  awsS3Form = this.formBuilder.group({
    aws_access_key_id: new FormControl('', [Validators.required, Validators.maxLength(200),Validators.pattern(/^[A-Z 0-9 ]+$/)]),
    aws_secret_access_key: new FormControl('', [Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-zA-Z 0-9+/_-]+$/)]),
    aws_s3_bucket_name: new FormControl('', [Validators.required, Validators.maxLength(30),Validators.pattern(/^[a-zA-Z0-9./-]+$/)]),
    client_pk: new FormControl('', [Validators.required]),
    aws_s3_pk: new FormControl('', []),
  });
  
  ngOnInit() {

    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      
      this.awsS3ColumnDefs = [
        { headerName: 'AWS S3 PK', field: 'aws_s3_pk', hide: true, suppressColumnsToolPanel: true },
        { headerName: 'AWS Access Key ID', field: 'aws_access_key_id', sortable: true, filter: true, resizable: true, minWidth: 250, headerCheckboxSelection: true, checkboxSelection: true },
        { headerName: 'AWS Secret Access Key', field: 'aws_secret_access_key', sortable: true, filter: true,  resizable: true, minWidth: 350 },
        { headerName: 'AWS S3 Bucket Name', field: 'aws_s3_bucket_name', sortable: true, filter: true,  resizable: true, minWidth: 200 },
        { headerName: 'Client Name', field: 'client_name', sortable: true, filter: true, resizable: true, minWidth: 200, valueGetter: this.getClientName.bind(this) },
        { headerName: 'Client PK', field: 'client_pk', hide: true },
        { headerName: 'AWS S3 Status', field: 'aws_s3_status', sortable: true, filter: true, resizable: true, minWidth: 150 },  
        { headerName: 'AWS S3 Creation Date', field: 'aws_s3_creation_date', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'AWS S3 Activation Date', field: 'aws_s3_activation_date', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'AWS S3 Deactivation Date (Last)', field: 'aws_s3_deactivation_date', sortable: true, filter: true, resizable: true, minWidth: 170 }
      ];
    });

    this.popupModalService.showMessageAlertPopupModal.subscribe((result :{ show: boolean }) => {
      if (!result.show) {
        this.load_aws_s3_list();
      }
    });

  }

  onSelectionChanged(event: SelectionChangedEvent) {
    const selectedData = this.gridApi.getSelectedRows();
  
    this.active_disable = true;
    this.deactive_disable = true;
    this.edit_disable = true;

    if (selectedData.length > 0) {
      const hasActive = selectedData.some((item: { aws_s3_status: string }) => item.aws_s3_status === "ACTIVE");
      const hasDeactive = selectedData.some((item: { aws_s3_status: string }) => item.aws_s3_status === "INACTIVE");

      super.disableActiveDeactive(selectedData, hasActive, hasDeactive);
    }
  }

  save_aws_s3() {
    this.submitted = true;
    if (this.awsS3Form.invalid) {
      return;
    }

    const selectedData = this.gridApi.getSelectedRows();
    var formData: any = new FormData();
    formData.append('aws_access_key_id', this.awsS3Form.value['aws_access_key_id']),
    formData.append('aws_secret_access_key', this.awsS3Form.value['aws_secret_access_key']),
    formData.append('aws_s3_bucket_name', this.awsS3Form.value['aws_s3_bucket_name']),
    formData.append('client_pk', this.awsS3Form.value['client_pk']),
    formData.append('aws_s3_pk', this.awsS3Form.value['aws_s3_pk'] === '' || this.awsS3Form.value['aws_s3_pk'] === null ? null : this.awsS3Form.value['aws_s3_pk']),
    formData.append('aws_s3_status', 'ACTIVE'),
    formData.append('aws_s3_creation_date', this.awsS3Form.value['aws_s3_pk'] === '' || this.awsS3Form.value['aws_s3_pk'] === null ? null : selectedData[0].aws_s3_creation_date),
    formData.append('aws_s3_activation_date', this.awsS3Form.value['aws_s3_pk'] === '' || this.awsS3Form.value['aws_s3_pk'] === null ? null : selectedData[0].aws_s3_activation_date)

    this.mftServices.postData("save_aws_s3", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.mftServices.updatedAlert('SUCCESS');
        this.gridApi.setRowData(data.body);
        this.gridApi.refreshCells();
        this.modalService.dismissAll('Submit click');
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  awsS3DataBind(params: any) {  
    this.gridApi = params.api;  
    this.load_aws_s3_list();
  }

  load_aws_s3_list() {
    const httpParams = new HttpParams();
    this.mftServices.loadData("load_aws_s3_list", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.gridApi.setRowData(data.body);
        this.gridApi.refreshCells();
        this.active_disable = true;
        this.deactive_disable = true;
        this.edit_disable = true;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  open(content:any, clickEvent: string) {
    this.submitted = false;
    this.currentEvent = clickEvent;

    var availableClientPKs : number[] = [];
    this.gridApi.forEachNode((rowNode: any) => {
      availableClientPKs.push(rowNode.data.client_pk);
    });

    this.clientOptions = [];
    this.userData.client_list.forEach((client: {client_pk: number, allow_fax: number}) => {
      if (!availableClientPKs.includes(client.client_pk) && client.allow_fax === 1) {
        this.clientOptions.push(client);
      }
    });

    if (clickEvent === "NEW") {
      this.awsS3Form.patchValue({ aws_s3_pk: null, client_pk: '', aws_access_key_id: '', aws_secret_access_key: '', aws_s3_bucket_name: '' });
    }
    
    if (clickEvent === "EDIT") {
      const selectedData = this.gridApi.getSelectedRows();

      this.awsS3Form.patchValue({
        aws_s3_pk: selectedData[0]["aws_s3_pk"], client_pk: selectedData[0]["client_pk"], aws_access_key_id: selectedData[0]["aws_access_key_id"], 
        aws_secret_access_key: selectedData[0]["aws_secret_access_key"], aws_s3_bucket_name: selectedData[0]["aws_s3_bucket_name"] 
      });
    }
    const modalRef = this.modalService.open(content, {backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title'});
    modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  getClientName(params: any) {
    let client = this.userData.client_list.find((client: { client_pk: number; }) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  };

}
