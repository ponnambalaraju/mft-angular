import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Users } from 'src/app/models/users';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { BaseComponent } from 'src/app/components/base/base.component';
import { SelectionChangedEvent } from 'ag-grid-community';

@Component({
  selector: 'app-faxprofile',
  templateUrl: './faxprofile.component.html',
  styleUrls: ['./faxprofile.component.css']
})

export class FaxprofileComponent  extends BaseComponent {

  userData: any;
  faxColumnDefs: any;
  templateList: any;
  RowData: any;  
  gridApi: any;
  user_pk: string;
  faxForm: FormGroup;
  temp_fax_user_password: string = '';
  clientOptions: any[] = [];
  public user = { user_pk: '', client_pk: '', search_client_pk: ''}
  public client = { client_pk: '' };
  faxactiveclient: any;
  faxTypeOptions: any[] = [];
  othernotificationType: string = '';

  
  constructor(public override modalService: NgbModal, private mftServices: MftService, private loggedInUser: Users, private formBuilder: FormBuilder) {
    super(modalService);
  }
   
  ngOnInit() {  
    this.loadTemplateList();
    this.faxColumnDefs = [
      { headerName: 'Fax Profile PK', field: 'fax_profile_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Fax Profile Id', field: 'fax_user_id', sortable: true, filter: true, resizable: true, minWidth: 100, headerCheckboxSelection: true, checkboxSelection: true },
      { headerName: 'Client Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getClientValue.bind(this) },
      { headerName: 'Fax Number', field: 'fax_number', sortable: true, filter: true, resizable: true, minWidth: 125},
      { headerName: 'Fax Resolution', field: 'resolution', sortable: true, filter: true, resizable: true, minWidth: 230 },
      { headerName: 'Fax Profile Name', field: 'fax_service_name', sortable: true, filter: true, resizable: true, minWidth: 230 },
      { headerName: 'Client PK', field: 'client_pk', hide: true },
    ];

    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      this.user_pk = this.loggedInUser.getUser().user_pk;
    });

    this.faxForm = this.formBuilder.group({
      fax_profile_pk: ['', []],
      fax_user_id: [],
      fax_number: ['', []],
      resolution: ['', []],
      fax_service_name: ['', []],
      client_pk: ['', []],
    });
  
    this.loadactiveclients();
    this.load_fax();

    this.mftServices.data$.subscribe((value) => {
      this.loadactiveclients();
      this.loadTemplateList();
      this.load_fax();
    });
  }

    faxDataBind(params: any) {
      this.gridApi = params.api;
      this.loadTemplateList();
    };

    loadTemplateList() {
      const httpParams = new HttpParams().set('client_pk', (this.user.search_client_pk !== "" && this.user.search_client_pk == "All" ? this.user.search_client_pk : '%'));
      this.mftServices.loadData("fax_profile_list", httpParams).subscribe(
        (data: HttpResponse<any>) => {  
          this.templateList = data.body  
          this.templateList.forEach((template: { fax_service_pk: any; fax_service_name: any; }) => {
            this.faxTypeOptions.forEach((option: { fax_service_pk: any; fax_service_name: any; }) => {
                if (option.fax_service_pk.toString() === template.fax_service_name) {
                    template.fax_service_name = option.fax_service_name;
                }
            });
        });        
          this.gridApi.setRowData(data.body);
          this.gridApi.refreshCells();
          this.edit_disable = true;
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }

    onSelectionChanged(event: SelectionChangedEvent) {
      const selectedData = this.gridApi.getSelectedRows();
      this.edit_disable = true;
      if (selectedData.length > 0) {
        this.edit_disable = false;
      }
      else{
        this.edit_disable = true;
      }
    }

  currentEvent: string;
  open(content:any, clickEvent: string) {
    this.submitted = false;
    this.currentEvent = clickEvent;

    var availableClientPKs : number[] = [];
    this.gridApi.forEachNode((rowNode: any) => {
      availableClientPKs.push(rowNode.data.client_pk);
    });

    this.clientOptions = [];
    this.userData.client_list.forEach((client: {client_pk: number, allow_fax: number}) => {
      if (!availableClientPKs.includes(client.client_pk) && client.allow_fax === 1) {
        this.clientOptions.push(client);
      }
    });

    if (clickEvent === "NEW") {
      this.faxForm.patchValue({
        fax_profile_pk: 'None', fax_user_id: '', client_name:'', fax_number: '', resolution:'',fax_service_name: '',client_pk:'', });
    }
    if (clickEvent === "EDIT") {
      const selectedData = this.gridApi.getSelectedRows();

      this.faxForm.patchValue({
        fax_profile_pk: selectedData[0]["fax_profile_pk"], client_pk: selectedData[0]["client_pk"], fax_user_id: selectedData[0]["fax_user_id"], client_name: selectedData[0]["client_name"],
        fax_service_name: selectedData[0]["fax_service_name"], resolution: selectedData[0]["resolution"],fax_number: selectedData[0]["fax_number"],
      });
    }

    const modalRef = this.modalService.open(content, {backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title'});
    modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  };


  load_fax(){
    const httpParams = new HttpParams();
    this.mftServices.loadData("load_active_fax_types", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.othernotificationType.includes(obj.fax_service_pk.toString())) {
            obj.fax_status = true;
          } else {
            obj.fax_status = false;
          }
        });
        this.faxTypeOptions = data.body;
      },
      (httpError: HttpErrorResponse) => { 
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          this.popupModalService.openTimeoutModal();
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
      );
  }

  getClientName(params: any) {
    let client = this.userData.client_list.find((client: { client_pk: number; }) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  };

  passwordValue(eventValue: any, fieldName: string) {
    if (fieldName === "fax_user_password") {
      this.faxForm.patchValue({
        fax_user_password: eventValue.target.value,
      });
    }
  };

  loadactiveclients() {
    const params = new HttpParams().set('client_pk', '%');
    this.mftServices.loadData("active_client_list", params).subscribe(
      (data: HttpResponse<any>) => { 
        this.faxactiveclient = data.body.filter((client: { allow_fax: boolean; }) => client.allow_fax === true);
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  getClientValue(params: any) {
    let client = this.mftService.loggedInUser.getUser().client_list.find((client: { client_pk: any; }) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  };

  save_fax() {
    console.log("save fax click");
    this.submitted = true;
    if (this.faxForm.invalid) {
      const invalid = [];
      const controls = this.faxForm.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
    }
    var formData: any = new FormData();
    formData.append('fax_profile_pk', this.faxForm.value['fax_profile_pk']),
    formData.append('fax_user_id', this.faxForm.value['fax_user_id']),
    formData.append('fax_number', this.faxForm.value['fax_number']),
    formData.append('resolution', this.faxForm.value['resolution']),
    formData.append('fax_service_name', this.faxForm.value['fax_service_name']),
    formData.append('client_pk', this.faxForm.value['client_pk']),
  
    
    this.mftServices.postData("save_fax_profile", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.gridApi.refreshCells();
        this.modalService.dismissAll('Submit click');
        if (data.body.result === 'SUCCESS') {
          if (this.faxForm.value['fax_profile_pk'] !== "") {
            this.mftServices.updatedAlert("The fax details has been saved successfully");
          } 
          else {
            this.mftServices.updatedAlert("The fax details has been updated successfully");
          }
        } else {
          this.mftServices.updatedAlert(data.body.data);
        }
        this.loadTemplateList();
      }, 
      (error) => { console.error('There was an error!', error.message); }
    );
  };
}