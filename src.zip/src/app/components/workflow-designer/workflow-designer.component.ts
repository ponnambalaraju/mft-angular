import { AfterViewInit, Component, OnInit } from '@angular/core';
import { jsPlumb } from 'jsplumb';

interface File {
  isOpen?: boolean;
  subfolders?: Folder[];
  client_pk: number;
  content: string;
  created_at: string;
  dataset_pk: number;
  datasets_status: string;
  file_size: number;
  file_type: string;
  file_name: string;
  isFolder: boolean;
  wizard_create_at: string;wizard_modify_at?: string | null;
  mimetype: string;
  parent_id: string;
  user_pk: number;
  wizard_id: string;
  wizard_pk: number;
}

interface Folder {
  client_pk: number;
  folder_name: string;
  isFolder: boolean;
  parent_id: string;
  user_pk: number;
  wizard_create_at: string;
  wizard_modify_at?: string | null;
  wizard_id: string;
  
  wizard_pk: number;
  subfolders?: Folder[];
  files?: File[];
  isOpen?: boolean;
}

@Component({
  selector: 'app-workflow-designer',
  templateUrl: './workflow-designer.component.html',
  styleUrls: ['./workflow-designer.component.css']
})
export class WorkflowDesignerComponent implements OnInit, AfterViewInit {
  folderStructure: Folder[] = [];
  workflowTasks: any[] = [];
  foldersFile: File[] = [];
  instance: any;

  tasks = [
    { name: 'Start Task', icon: 'assets/icons/caret-right.svg' },
    { name: 'Files', icon: 'assets/icons/file-earmark.svg' },
    { name: 'Formula', icon: 'assets/icons/calculator.svg' },
    { name: 'End Task', icon: 'assets/icons/x.svg' },
  ];

  data: Folder[] = [
    {
      client_pk: 1,
      folder_name: "New Folder",
      isFolder: true,
      parent_id: "root",
      user_pk: 1,
      wizard_create_at: "Tue, 13 Aug 2024 16:58:50 GMT",
      wizard_id: "b74f5151-2fff-4e51-9956-5ad8e1f4050f",
      wizard_modify_at: null,
      wizard_pk: 1,
      subfolders: [
        {
          client_pk: 1,
          folder_name: "Sub Folder",
          isFolder: true,
          parent_id: "b74f5151-2fff-4e51-9956-5ad8e1f4050f",
          user_pk: 1,
          wizard_create_at: "Tue, 13 Aug 2024 17:27:34 GMT",
          wizard_id: "d2f259e3-c569-4d8d-92e4-1a8c8cc8c7db",
          wizard_modify_at: null,
          wizard_pk: 3,
          subfolders: [
            {
              client_pk: 1,
              folder_name: "Abeta",
              isFolder: true,
              parent_id: "d2f259e3-c569-4d8d-92e4-1a8c8cc8c7db",
              user_pk: 1,
              wizard_create_at: "Tue, 13 Aug 2024 18:33:20 GMT",
              wizard_id: "f3c00cab-7607-4f69-86a9-32434c2c1476",
              wizard_modify_at: null,
              wizard_pk: 4
            }
          ]
        },
        {
          client_pk: 1,
          folder_name: "Demo",
          isFolder: true,
          parent_id: "b74f5151-2fff-4e51-9956-5ad8e1f4050f",
          user_pk: 1,
          wizard_create_at: "Wed, 14 Aug 2024 00:22:50 GMT",
          wizard_id: "93c514c1-e966-4308-9f89-648d1074e573",
          wizard_modify_at: null,
          wizard_pk: 6
        }
      ]
    },
    {
      client_pk: 1,
      folder_name: "Augus",
      isFolder: true,
      parent_id: "root",
      user_pk: 1,
      wizard_create_at: "Tue, 13 Aug 2024 17:03:26 GMT",
      wizard_id: "8473cce6-cc94-47e8-8ca4-6955e03d7f8d",
      wizard_modify_at: null,
      wizard_pk: 2
    },
    {
      client_pk: 1,
      folder_name: "Kabil",
      isFolder: true,
      parent_id: "root",
      user_pk: 1,
      wizard_create_at: "Tue, 13 Aug 2024 18:51:00 GMT",
      wizard_id: "cbb88255-54f4-42db-aefb-2ba2872dccc1",
      wizard_modify_at: null,
      wizard_pk: 5
    },
    {
      client_pk: 1,
      folder_name: "Paul",
      isFolder: true,
      parent_id: "root",
      user_pk: 1,
      wizard_create_at: "Wed, 14 Aug 2024 11:43:46 GMT",
      wizard_id: "71b231df-65aa-4838-bdb1-329d1fcd8a86",
      wizard_modify_at: null,
      wizard_pk: 7,
      files: [
        {
          client_pk: 1,
          content: "c3RhdG",
          created_at: "Wed, 14 Aug 2024 17:11:25 GMT",
          dataset_pk: 1,
          datasets_status: "ACTIVE",
          file_size: 24165,
          file_type: "csv",
          file_name: "state ziptable.csv",
          isFolder: false,
          mimetype: "text/csv",
          parent_id: "71b231df-65aa-4838-bdb1-329d1fcd8a86",
          user_pk: 1,
          wizard_id: "b2681434-1be5-41fc-bce6-69e262db1448",
          wizard_pk: 7,
          wizard_create_at: ''
        },
        {
          client_pk: 1,
          content: "aWQsbmFtZSxkZ",
          created_at: "Wed, 14 Aug 2024 17:57:20 GMT",
          dataset_pk: 2,
          datasets_status: "ACTIVE",
          file_size: 372,
          file_type: "csv",
          file_name: "updated_data-1722343677889.csv",
          isFolder: false,
          mimetype: "text/csv",
          parent_id: "71b231df-65aa-4838-bdb1-329d1fcd8a86",
          user_pk: 1,
          wizard_id: "ceb8dbb7-cd61-423a-855a-305690109b9b",
          wizard_pk: 7,
          wizard_create_at: ''
        }
      ]
    },
    {
      client_pk: 1,
      folder_name: "Demo",
      isFolder: true,
      parent_id: "root",
      user_pk: 1,
      wizard_create_at: "Wed, 14 Aug 2024 18:07:54 GMT",
      wizard_id: "2770a814-7732-4029-ac90-87543d170da7",
      wizard_modify_at: null,
      wizard_pk: 8,
      files: [
        {
          client_pk: 1,
          content: "UEsDBBQAAAAI",
          created_at: "Wed, 14 Aug 2024 20:56:29 GMT",
          dataset_pk: 3,
          datasets_status: "ACTIVE",
          file_size: 9200,
          file_type: "xlsx",
          file_name: "Table 2.xlsx",
          isFolder: false,
          mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          parent_id: "2770a814-7732-4029-ac90-87543d170da7",
          user_pk: 1,
          wizard_id: "61255662-b695-4e1c-9312-89bba5e23437",
          wizard_pk: 8,
          wizard_create_at: ''
        }
      ]
    }
  ];

  ngOnInit() {
    this.folderStructure = this.data;
  }

  ngAfterViewInit() {
    this.instance = jsPlumb.getInstance({
      Container: 'canvas'
    });

    this.instance.bind('connection', (info: any) => {
      console.log('Connection established:', info);
    });

    this.initializeJsPlumb();
  }

  initializeJsPlumb() {
    setTimeout(() => {
      this.workflowTasks.forEach(task => {
        this.initializeTask(task.id, task.name);
      });
    }, 500);
  }

  initializeTask(taskId: string, taskName: string) {
    this.instance.draggable(taskId);

    const commonEndpointOptions = {
      connector: ['Flowchart', { curviness: 50 }],
      endpoint: ['Dot', { radius: 7 }],
      paintStyle: { fill: '#77E4C8', strokeWidth: 2 },
      connectorStyle: { stroke: '#478CCF', strokeWidth: 3 },
      connectorOverlays: [
        ['Arrow', { width: 12, length: 12, location: 1 }],
        ['Label', { label: taskName, location: 0.5, cssClass: 'connector-label' }]
      ]
    };

    if (taskName === 'Files' || taskName === 'Formula') {
      this.instance.addEndpoint(taskId, {
        anchor: 'Left',
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        ...commonEndpointOptions
      });

      this.instance.addEndpoint(taskId, {
        anchor: 'Right',
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        ...commonEndpointOptions
      });
    } else {
      this.instance.addEndpoint(taskId, {
        anchors: ['Top', 'Bottom', 'Left', 'Right'],
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        ...commonEndpointOptions
      });
    }
  }

  onDragStart(event: DragEvent, task: any) {
    event.dataTransfer?.setData('task', JSON.stringify(task));
  }

  allowDrop(event: DragEvent) {
    event.preventDefault();
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    const data = event.dataTransfer?.getData('task');
    if (data) {
      const task = JSON.parse(data);
      this.addTaskToCanvas(task, event.clientX, event.clientY);
    }
  }

  addTaskToCanvas(task: any, x: number, y: number) {
    const canvas = document.getElementById('canvas');
    if (canvas) {
      const rect = canvas.getBoundingClientRect();
      const style = {
        top: `${y - rect.top}px`,
        left: `${x - rect.left}px`
      };
      const id = 'task-' + new Date().getTime();

      this.workflowTasks.push({
        ...task,
        id,
        style,
        files: []  // Initialize files array
      });

      setTimeout(() => {
        this.initializeTask(id, task.name);
      }, 0);
    }
  }

  onFileDrop(event: DragEvent, task: any): void {
    event.preventDefault();
    const draggedItem = JSON.parse(event.dataTransfer?.getData('draggedItem') || '{}');
  
    if (draggedItem.isFile) {
      task.files.push({ ...draggedItem }); // Copy the file object
    }
  }

  getFileIcon(file: File): string {
    return '📄';  // Use a generic file icon
  }

  getFolderIcon(folder: Folder): string {
    return folder.isFolder ? '📂' : '📄';
  }

  onFileDragStart(event: DragEvent, item: any): void {
    event.dataTransfer?.setData('draggedItem', JSON.stringify(item));
    event.dataTransfer!.effectAllowed = 'copy'; // Allow only copy operation
  }
  toggleFolder(folder: Folder) {
    folder.isOpen = !folder.isOpen;
  }
}
