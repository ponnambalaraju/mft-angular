import { Component, ElementRef, ViewChild } from '@angular/core';
import { NgbModal, NgbNav } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectionChangedEvent } from 'ag-grid-community';
import { PasswordInputComponent } from '../password-input/password-input.component';
import { ColumnDefs } from 'src/app/column-def';

@Component({
  selector: 'app-triggers',
  templateUrl: './triggers.component.html',
  styleUrls: [ './triggers.component.css' ],
})
export class TriggersComponent extends PasswordInputComponent {

  constructor(public override  modalService: NgbModal, private mftServices: MftService, public override el: ElementRef, private formBuilder: FormBuilder) { 
    super(modalService, el);  
  }

  temp_trigger_fax: any;
  triggerForm: FormGroup;
  columnDefs: ColumnDefs[] = [];
  AgLoad: boolean = true;
  gridApi: any;
  source_password: string = '';
  destination_password: string = '';
  button_disable: boolean = true;
  trigger_disable: boolean = true;
  clientOptions: any[] = [];
  temp_source_password: string = '';
  temp_destination_password: any = {};
  currentEvent: string;
  hti_amazon_s3_source_trigger: any;
  hti_amazon_s3_destination_trigger: any;
  destination_trigger_validation: FormArray;
  multiple_trigger_destination_list: FormArray;
  responseEntries: [string, any][];
  public user = { user_pk: '', client_pk: '', search_client_pk: '', role_pk: '', user_id: '', user_name: '', user_status: '', user_locked: '' }
  public client = { client_pk: '' };
  source_validation: string[] = ['source_transfer_type', 'source_username', 'source_password', 'source_location', 'source_nas_share', 'source_aws_access_key_id', 'source_aws_secret_access_key', 'source_aws_s3_bucket_name'];
  destination_validation: string[] = ['multiple_trigger_destination' ];
  notification_validation: string[] = ['source_transfer_type', 'source_username'];
  upload_disable: boolean = true;

  div2Visibility: boolean[] = []; 
  divVisibility: boolean[] = [];
  accesskeyid_error: string = "";
  accesskey_error: string = "";
  // bucketname_error: string = "";

  new_trigger_destination(): FormGroup {
    return this.formBuilder.group({
      destination_transfer_type: new FormControl('', [Validators.required]),
      destination_address: new FormControl ('',[Validators.maxLength(100)]),
      destination_login_type: new FormControl ('',[Validators.pattern(/^[a-zA-Z]+$/)]),
      destination_username: new FormControl ('',[]),
      destination_password: new FormControl ('',[]),
      destination_location: new FormControl ('',[]),
      destination_api_token: new FormControl ('',[Validators.maxLength(150)]),
      destination_api_url: new FormControl ('',[Validators.pattern(/^(ftp|http|https):\/\/[^ "]+$/)]),
      destination_login_parameters: new FormControl ('',[ Validators.pattern(/^[A-Za-z0-9\s]+$/) ]),
      destination_login_parameters_values: new FormControl ('',[Validators.minLength(30)]),
      destination_upload_headers: new FormControl ('',[Validators.maxLength(45)]),
      destination_upload_headers_values: new FormControl ('',[Validators.maxLength(45)]),
      destination_upload_parameters: new FormControl ('',[Validators.pattern(/^[a-zA-Z][a-zA-Z0-9_-]*$/)]),
      destination_upload_parameters_values: new FormControl ('',[Validators.pattern(/^[a-zA-Z0-9]*$/)]),
      destination_nas_share: new FormControl ('',[]),
      microsoft_login_authority_url: new FormControl ('',[Validators.pattern(/^(ftp|http|https):\/\/[^ "]+$/)]),
      application_id: new FormControl ('',[Validators.maxLength(30)]),
      client_secret: new FormControl ('',[Validators.pattern(/^[a-zA-Z0-9.-]+$/)]),
      tenant_id: new FormControl ('',[Validators.maxLength(30),Validators.pattern(/^[a-z0-9.-0-9]*$/)]),
      aws_access_key_id: new FormControl ('',[Validators.maxLength(45)]),
      aws_secret_access_key: new FormControl ('',[Validators.maxLength(45),Validators.pattern(/^[a-zA-Z0-9+/_-]*$/)]),
      aws_s3_bucket_name: new FormControl ('',[Validators.maxLength(45)]),
      dest_fax_clientPk: new FormControl('', []),
    });
  }

  add_trigger_destination() {
    this.multiple_trigger_destination().push(this.new_trigger_destination());
    this.div2Visibility.push(false); 
  }
 
  remove_trigger_destination(triggerDestinationIndex: number) {
    this.multiple_trigger_destination().removeAt(triggerDestinationIndex);
  }

  multiple_trigger_destination(): FormArray {
    return this.triggerForm?.get('multiple_trigger_destination') as FormArray;
  }
  ngOnInit() {
    this.triggerForm = this.formBuilder.group({
      trigger_id: new FormControl('',[Validators.maxLength(15),Validators.pattern(/^[A-Z0-9-]*$/)]),
      trigger_pk: new FormControl('', []),
      trigger_status: new FormControl('',[]),
      trigger_creation_date: new FormControl('',Validators.pattern(/^[a-zA-Z 0-9/-_. ,:]*$/)),
      trigger_activation_date: new FormControl('',Validators.pattern(/^[a-zA-Z 0-9/-_. ,:]*$/)),
      source_transfer_type: new FormControl('', [Validators.required,Validators.maxLength(50)]),
      source_address: new FormControl('',[Validators.required,Validators.maxLength(250),Validators.pattern(/^[a-zA-Z 0-9+:/-_ .]+$/)]), 
      source_description: new FormControl('',[Validators.maxLength(30)]),
      select_client_pk: new FormControl('', [Validators.required]),
      source_username: new FormControl('', [Validators.required,Validators.maxLength(50), Validators.pattern(/^[a-zA-Z0-9/-@#_.]+$/)]),
      source_password:new FormControl ('',[Validators.required]),
      source_nas_share: new FormControl ('',[Validators.required]),
      source_aws_access_key_id: new FormControl ('',[Validators.maxLength(45)]),
      source_aws_secret_access_key: new FormControl ('',[Validators.maxLength(45),Validators.pattern(/^[a-zA-Z0-9+/_-]*$/)]),
      source_aws_s3_bucket_name: new FormControl ('',[Validators.maxLength(45)]),
      source_location:new FormControl('', [Validators.required,Validators.maxLength(200)]),
      allowed_file_types:new FormControl('', [Validators.required,Validators.maxLength(45)]),
      destination_description: new FormControl ('',[Validators.maxLength(30)]),

      multiple_trigger_destination: this.formBuilder.array([]),
      
      trigger_notification: new FormControl('', [Validators.required,Validators.maxLength(300), Validators.pattern('^([a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,},\\s*){0,9}[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$')]),
      notification_type: new FormControl('', [Validators.required]),
    });

    this.triggerForm.get('source_transfer_type')?.valueChanges.subscribe((selected_source_transfer_type: string) => {
      this.triggerForm.get('source_address')?.clearValidators();
      this.triggerForm.get('source_description')?.clearValidators();
      this.triggerForm.get('source_username')?.clearValidators();
      this.triggerForm.get('source_password')?.clearValidators();
      this.triggerForm.get('source_location')?.clearValidators();
      this.triggerForm.get('source_nas_share')?.clearValidators();
      this.triggerForm.get('source_aws_access_key_id')?.clearValidators();
      this.triggerForm.get('source_aws_secret_access_key')?.clearValidators();
      this.triggerForm.get('source_aws_s3_bucket_name')?.clearValidators();

      if (selected_source_transfer_type === '2' || selected_source_transfer_type === '11') {
        this.triggerForm.get('source_address')?.setValidators([Validators.required,Validators.maxLength(250),Validators.pattern(/^[a-zA-Z 0-9/-_.]+$/)]);
        this.triggerForm.get('source_description')?.setValidators([Validators.maxLength(30)]);
        this.triggerForm.get('source_username')?.setValidators([Validators.required,Validators.maxLength(50), Validators.pattern(/^[a-zA-Z0-9/-@#_.]+$/)]);
        this.triggerForm.get('source_password')?.setValidators([Validators.required]);
        this.triggerForm.get('source_location')?.setValidators([Validators.required,Validators.maxLength(200)]);
        if (selected_source_transfer_type === '11') {
          this.triggerForm.get('source_nas_share')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-zA-Z 0-9_/ ]+$/)]);
        }
      }

      if (selected_source_transfer_type === '12') {
        //Nothing to disable on selection of HTI - Amazon S3
      }

      if (selected_source_transfer_type === '15') {
        this.triggerForm.get('source_aws_access_key_id')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[A-Z 0-9 ]+$/)]);
        this.triggerForm.get('source_aws_secret_access_key')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-zA-Z 0-9+/_-]+$/)]);
        this.triggerForm.get('source_aws_s3_bucket_name')?.setValidators([Validators.required, Validators.maxLength(30)]);
      }

      this.triggerForm.get('source_address')?.updateValueAndValidity();
      this.triggerForm.get('source_description')?.updateValueAndValidity();
      this.triggerForm.get('source_username')?.updateValueAndValidity();
      this.triggerForm.get('source_password')?.updateValueAndValidity();
      this.triggerForm.get('source_location')?.updateValueAndValidity();
      this.triggerForm.get('source_nas_share')?.updateValueAndValidity();
      this.triggerForm.get('source_aws_access_key_id')?.updateValueAndValidity();
      this.triggerForm.get('source_aws_secret_access_key')?.updateValueAndValidity();
      this.triggerForm.get('source_aws_s3_bucket_name')?.updateValueAndValidity();
    });

    this.mftServices.data$.subscribe((value) => {      
      if (this.mftService.loggedInUser.getUser() !== undefined) {
        if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
          this.user.search_client_pk = "%";
        } else {
          this.user.search_client_pk = this.mftService.loggedInUser.getUser().client_pk;
        }
        this.customizedHeaderView(4 , 'trigger_id', this.columnDefs);
      }

      const params = new HttpParams().set('client_pk', this.user.search_client_pk);
      this.mftServices.loadData("active_client_list", params).subscribe(
        (data: HttpResponse<any>) => {
          this.add_trigger_destination();
          this.clientOptions = data.body;
          if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
            this.user.search_client_pk = "%";
          }
          if (this.clientOptions.length === 1) {
            this.triggerForm.get('select_client_pk')?.setValue(this.clientOptions[0].client_pk);
          }
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    });

    this.mftServices.loadData("get_transfer_type_list", new HttpParams()).subscribe(
      (data: HttpResponse<any>) => {
        this.transferTypeOptions = data.body
        this.hti_amazon_s3_source_trigger = data.body.find((aws_s3: { transfer_type_pk: Number }) => aws_s3.transfer_type_pk === 12);
        this.hti_amazon_s3_destination_trigger = data.body.find((aws_s3: { transfer_type_pk: Number }) => aws_s3.transfer_type_pk === 14);
      }, 
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );

    this.popupModalService.showMessageAlertPopupModal.subscribe((result :{ show: boolean }) => {
      if (!result.show) {
        this.loadTriggerList();
      }
    });
  } 

toggleDivVisibility(triggerDestinationIndex: number) {
  this.divVisibility[triggerDestinationIndex] = !this.divVisibility[triggerDestinationIndex];
  console.log("Toggle clicked for index: ", triggerDestinationIndex);
  console.log("Visibility state for index: ", this.divVisibility[triggerDestinationIndex]);
}

// Function to check if the div is visible /paul
isDivVisible(triggerDestinationIndex: number): boolean {
  // Return the visibility state for the specified index
  return this.divVisibility[triggerDestinationIndex];
}

  selectedFiles: File[] = [];
  fileUploadProgress: { [key: string]: number } = {};

  onFileChange(event: any): void {
    event.preventDefault();
  
    const files: FileList = event.target.files || event.dataTransfer.files;
  
    if (files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        const file: File = files[i];
        this.selectedFiles.push(file);

        let progress = 0;
        const progressInterval = setInterval(() => {
          progress += Math.random() * 10;
          progress = Math.min(progress, 100);
          this.fileUploadProgress[file.name] = Math.round(progress);
          if (progress === 100) {
            clearInterval(progressInterval);
            setTimeout(() => {
              delete this.fileUploadProgress[file.name];
            }, 1000);
          }
        }, 500);
      }
    }
  }
  
  allowDrop(event: any): void {
    event.preventDefault();
  }

  removeFile(file: File): void {
    this.selectedFiles = this.selectedFiles.filter(f => f !== file);
  }

  uploadPopup(content:any){
    this.selectedFiles = [];
    this.openPopup(content);
  }

  uploadFile(): void {
    if (this.selectedFiles.length <= 0) {
      alert('Please select a file to upload! ');
      return
    } else {
      const formData:any = new FormData();
      formData.append('user_pk', this.mftService.loggedInUser.getUser().user_pk);
      formData.append('trigger_pk', this.gridApi.getSelectedRows()[0]['trigger_pk']);
      for (let i = 0; i < this.selectedFiles.length; i++) {
        formData.append('upload_file', this.selectedFiles[i]);
      }
      this.mftServices.postData("upload_file",formData).subscribe(
        response => {
          if (response.body && (response.body as any)['message'] === 'SUCCESS') {
            this.mftServices.updatedAlert("File Upload Success.");
          } else {
            this.mftServices.updatedAlert("Failed to Upload File");
          }
          this.modalService.dismissAll('Update User');
        },
        error => { console.error(error); }
      );
    }
  }

  triggersDataBind(params: any) {
    this.gridApi = params.api;
    this.loadTriggerList();
  };

  loadTriggerList() {
    const httpParams = new HttpParams().set('client_pk', (this.user.search_client_pk !== "" && this.user.search_client_pk !== "All" ? this.user.search_client_pk : '%'));
    this.mftServices.loadData("trigger_list", httpParams).subscribe(
      (response: HttpResponse<any>) => {
        const data = response.body;
        this.gridApi.setRowData(data.map((row: {created_by: any; dest_fax_clientPk: any; }) => {
          const client = this.clientOptions.find(option => option.client_pk === row.dest_fax_clientPk);
          const createdByClient = this.clientOptions.find(option => option.client_pk === row.created_by);
          if (client) {
            return { ...row, dest_fax_client_name: client.client_name };
          } else if (createdByClient) {
            return { ...row, created_by: createdByClient.client_name };
          } else {
            return { ...row, dest_fax_client_name: 'Unknown' }; 
          }
        }));
      this.gridApi.refreshCells();
        this.active_disable = true;
        this.deactive_disable = true;
        this.edit_disable = true;
        this.trigger_disable = false;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  test_connection(content:any) {
    this.submitted = true;
    if (this.triggerForm.invalid) {
      return;
    }

    var formData: any = new FormData();
    formData.append('source_transfer_type', this.triggerForm.value['source_transfer_type']);
    formData.append('source_address', this.triggerForm.value['source_address']);
    formData.append('source_username', this.triggerForm.value['source_username']);
    formData.append('source_password', this.triggerForm.value['source_password']);
    formData.append('source_location', this.triggerForm.value['source_location']);
    formData.append('allowed_file_types', this.triggerForm.value['allowed_file_types']);
    formData.append('trigger_notification', this.triggerForm.value['trigger_notification']);
    formData.append('notification_type', this.triggerForm.value['notification_type']);
    formData.append('source_nas_share', this.triggerForm.value['source_nas_share']);
    formData.append('destination_nas_share', this.triggerForm.value['destination_nas_share']);
    formData.append('source_aws_access_key_id', this.triggerForm.value['source_aws_access_key_id']);
    formData.append('source_aws_secret_access_key', this.triggerForm.value['source_aws_secret_access_key']);
    formData.append('source_aws_s3_bucket_name', this.triggerForm.value['source_aws_s3_bucket_name']);

    let formGroupLength = this.multiple_trigger_destination().controls.length;
    let trigger_destination_values: [number, string][] = Array.from({ length: formGroupLength }, () => [0, '']);

    this.multiple_trigger_destination().getRawValue().forEach((destination_controls, index) => {
      Object.keys(destination_controls).forEach(key => {
        trigger_destination_values[index][Object.keys(this.multiple_trigger_destination().controls[0].getRawValue()).findIndex(item => item === key)] = destination_controls[key];
      });
    });
    formData.append('trigger_destination_values', trigger_destination_values);
    formData.append('trigger_destination_names', Object.keys(this.multiple_trigger_destination().controls[0].getRawValue()));

    this.mftServices.postData("test_connection", formData).subscribe(
      (data: HttpResponse<any>) => {
         this.responseEntries = Object.entries(data.body);
         this.openPopup(content);
      },
      (error) => {
         console.error('There was an error!', error.message);
      }
   );
  }

  success_count:string;
  failure_count:string;
  last_trigger:string = '-';

  loadTriggerInfo(trigger_pk: any) {
    const httpParams = new HttpParams().set('trigger_pk', trigger_pk);
    this.mftServices.loadData("trigger_info", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.success_count = data.body.success_count;
        this.failure_count = data.body.failure_count;
        this.last_trigger = data.body.last_trigger;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  onSelectionChanged(event: SelectionChangedEvent) {
    const selectedData = this.gridApi.getSelectedRows();

    this.trigger_disable = true;
    this.upload_disable = true;
    this.active_disable = true;
    this.deactive_disable = true;
    this.edit_disable = true;

    if (selectedData.length > 0) {
      const hasActive = selectedData.some((item: { trigger_status: string }) => item.trigger_status === "ACTIVE");
      const hasDeactive = selectedData.some((item: { trigger_status: string }) => item.trigger_status === "INACTIVE");
      
      this.disableActiveDeactive(selectedData, hasActive, hasDeactive);

      if (hasActive && hasDeactive) {
        this.trigger_disable = true;
        this.upload_disable = true;
      } else if (hasActive) {
        if (selectedData.length > 1) {
          this.trigger_disable = true;
          this.upload_disable = true;
        } else {
          this.trigger_disable = false;
          this.upload_disable = false;
        }
      } else if (hasDeactive) {
        this.trigger_disable = true;
        this.upload_disable = true;
      } else {
        this.trigger_disable = false;
        this.upload_disable = false;
      }
    }
  }

  setGridOptionValue() {
    const selectedData = this.gridApi.getSelectedRows()

    this.triggerForm.patchValue({
      trigger_pk: selectedData[0]["trigger_pk"], trigger_id: selectedData[0]["trigger_id"], trigger_status: selectedData[0]["trigger_status"],
      trigger_activation_date: selectedData[0]["trigger_activation_date"], trigger_creation_date: selectedData[0]["trigger_creation_date"], 
      source_transfer_type: selectedData[0]["source_transfer_type"], source_address: selectedData[0]["source_address"], source_username: selectedData[0]["source_username"], 
      source_password: selectedData[0]["source_password"], source_location: selectedData[0]["source_location"], allowed_file_types: selectedData[0]["allowed_file_types"], 
      source_aws_access_key_id: selectedData[0]["source_aws_access_key_id"], source_aws_secret_access_key: selectedData[0]["source_aws_secret_access_key"], 
      source_aws_s3_bucket_name: selectedData[0]["source_aws_s3_bucket_name"], aws_access_key_id: selectedData[0]["aws_access_key_id"], aws_secret_access_key: selectedData[0]["aws_secret_access_key"], 
      aws_s3_bucket_name: selectedData[0]["aws_s3_bucket_name"], source_description: selectedData[0]["source_description"], destination_description: selectedData[0]["destination_description"], 
      trigger_notification: selectedData[0]["trigger_notification"], notification_type: selectedData[0]["notification_type"], select_client_pk: selectedData[0]["client_pk"],
    });

    this.destination_trigger_validation = this.triggerForm.get('multiple_trigger_destination') as FormArray;
    for (let i = 0; i < selectedData[0]["destination_transfer_type"].split('|').length; i++) {
      this.add_trigger_destination();
      Object.keys(this.multiple_trigger_destination().controls[0].getRawValue()).forEach(key => {
        if (selectedData[0][key] !== undefined && typeof selectedData[0][key] === 'string') {
          try {
            const valueToSet = selectedData[0][key].split('|')[i] || '';
            this.destination_trigger_validation.controls[i].get(key)?.setValue(valueToSet);
            if (key === 'destination_password') {
              this.temp_destination_password[i] = valueToSet;
            }
          } catch (error) {
            console.error(`Error setting value for key: ${key}, index: ${i}. Error message: ${error}`);
          }
        } else {
          this.destination_trigger_validation.controls[i].get(key)?.setValue('');
        }
      });
    }
    this.temp_source_password = selectedData[0]["source_password"];
}

  open(content: any, clickEvent: string) {
    this.submitted = false;
    this.currentEvent = clickEvent;

    let source_aws_s3_index = this.transferTypeOptions.findIndex(hti_amazon_s3 => hti_amazon_s3.transfer_type_pk === 12);
    let destination_aws_s3_index = this.transferTypeOptions.findIndex(hti_amazon_s3 => hti_amazon_s3.transfer_type_pk === 14);
    
    if (source_aws_s3_index !== -1) {
      this.transferTypeOptions.splice(destination_aws_s3_index, 1);
      this.transferTypeOptions.splice(source_aws_s3_index, 1);
    }

    let client = this.clientOptions.find(client => client.client_pk === this.user.search_client_pk)
    if (client?.allow_hti_amazon_s3 || this.user.search_client_pk === '%') {
      this.transferTypeOptions.push(this.hti_amazon_s3_source_trigger);
      this.transferTypeOptions.push(this.hti_amazon_s3_destination_trigger);
    }

    for (let i = 0; i < this.multiple_trigger_destination().controls.length;) {
      this.remove_trigger_destination(0);
    }
    if (clickEvent === "NEW") {
      this.add_trigger_destination();
      this.triggerForm.patchValue({
        trigger_pk: '', trigger_id: '', trigger_status: '', trigger_activation_date: '', trigger_creation_date: '', source_transfer_type: '',
        source_address: '', source_username: '', source_password: '', source_location: '', allowed_file_types: '*', source_aws_s3_bucket_name: '', source_aws_access_key_id: '', 
        source_aws_secret_access_key: '', source_description: '', destination_description: '', trigger_notification: '',notification_type:'',
      });
    }
    if (clickEvent === "EDIT") {
      this.setGridOptionValue();
      this.openVisibilityDiv();
    }
    this.openPopup(content);
  }

  passwordValue(eventValue: any, fieldName: string, triggerDestinationIndex: number) {
    if (fieldName === "source_password") {
      this.triggerForm.patchValue({
        source_password: eventValue.target.value,
      });
    } else if (fieldName === "destination_password") {
      this.destination_trigger_validation = this.triggerForm.get('multiple_trigger_destination') as FormArray;
      let destination_trigger_controls = this.destination_trigger_validation.controls[triggerDestinationIndex]
      destination_trigger_controls.get('destination_password')?.setValue(eventValue.target.value);
    }
  };
  
  hasErrorsInVisibilityDiv(): boolean {

    const destinations = this.multiple_trigger_destination();
    for (let i = 0; i < destinations.length; i++) {
      const destinationGroup = destinations.at(i);
      if (destinationGroup instanceof FormGroup) {
        if (destinationGroup.status !== 'VALID') {
          return true;
        }
      }
    }
    return false;
  }
  
  openVisibilityDiv() {
    const destinations = this.multiple_trigger_destination();
    for (let i = 0; i < destinations.length; i++) {
      this.divVisibility[i] = true;
    }
  }

  submitTrigger(source: HTMLButtonElement, destination: HTMLButtonElement) {
    this.submitted = true;

    if (this.triggerForm.invalid) {
      const invalid = [];
      const controls = this.triggerForm.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
      console.log(invalid);
      if (invalid.includes(this.destination_validation[0])) {
        if (this.hasErrorsInVisibilityDiv()) {
          this.openVisibilityDiv();
        }
      }
      if (this.source_validation.includes(invalid[0])) {
        source.click();
      } else {
        destination.click();
      }
      return;
    }

    let trigger_creation: any = "";
    let trigger_activation: any = "";

    if (this.triggerForm.value['trigger_id'] !== '') {
      trigger_creation = this.gridApi.getSelectedRows()[0]["trigger_creation_date"];
      trigger_activation = this.gridApi.getSelectedRows()[0]["trigger_activation_date"];
    }

    var formData: any = new FormData();
    formData.append('user_pk', this.mftService.loggedInUser.getUser().user_pk);
    formData.append('client_pk', this.triggerForm.value['select_client_pk']);
    formData.append('trigger_pk', this.triggerForm.value['trigger_id'] === '' ? '' : this.triggerForm.value['trigger_pk']);
    formData.append('trigger_id', this.triggerForm.value['trigger_id']);
    formData.append('trigger_status', this.triggerForm.value['trigger_status']);
    formData.append('trigger_creation_date', trigger_creation);
    formData.append('trigger_activation_date', trigger_activation);
    formData.append('source_transfer_type', this.triggerForm.value['source_transfer_type']);
    formData.append('source_address', this.triggerForm.value['source_address']);
    formData.append('source_username', this.triggerForm.value['source_username']);
    formData.append('source_password', this.triggerForm.value['source_password']);
    formData.append('source_location', this.triggerForm.value['source_location']);
    formData.append('allowed_file_types', this.triggerForm.value['allowed_file_types']);
    formData.append('source_aws_access_key_id', this.triggerForm.value['source_aws_access_key_id']);
    formData.append('source_aws_secret_access_key', this.triggerForm.value['source_aws_secret_access_key']);
    formData.append('source_aws_s3_bucket_name', this.triggerForm.value['source_aws_s3_bucket_name']);
    formData.append('source_nas_share', this.triggerForm.value['source_nas_share']);
    formData.append('source_description', this.triggerForm.value['source_description']);
    formData.append('destination_description', this.triggerForm.value['destination_description']);
    formData.append('trigger_notification', this.triggerForm.value['trigger_notification']);
    formData.append('notification_type', this.triggerForm.value['notification_type']);
    formData.append('created_by', this.triggerForm.value['select_client_pk']);

    let formGroupLength = this.multiple_trigger_destination().controls.length;
    let trigger_destination_values: [number, string][] = Array.from({ length: formGroupLength }, () => [0, '']);

    this.multiple_trigger_destination().getRawValue().forEach((destination_controls, index) => {
      Object.keys(destination_controls).forEach(key => {
        trigger_destination_values[index][Object.keys(this.multiple_trigger_destination().controls[0].getRawValue()).findIndex(item => item === key)] = destination_controls[key];
      });
    });
    formData.append('trigger_destination_values', trigger_destination_values);
    formData.append('trigger_destination_names', Object.keys(this.multiple_trigger_destination().controls[0].getRawValue()));

    this.mftServices.postData("save_trigger", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.modalService.dismissAll('Submit click');
        if (data.body.result === 'SUCCESS') {
          if (this.triggerForm.value['trigger_pk'] !== "") {
            this.mftServices.updatedAlert("The trigger details has been saved successfully");
          } else {
            this.mftServices.updatedAlert("The trigger details has been updated successfully");
          }
        } else {
          this.mftServices.updatedAlert(data.body.data);
        }
        this.loadTriggerList();
      }, (error) => { console.error('There was an error!', error.message); }
    );
  }

  triggerNow() {
    if (this.gridApi.getSelectedRows().length === 1) {
      if (this.gridApi.getSelectedRows()[0].trigger_status !== 'ACTIVE') {
        this.mftServices.updatedAlert("Trigger is not active"); return;
      }

      let temp_client = this.mftService.loggedInUser.getUser().client_list.find((client: { client_pk: number, client_status: string }) => client.client_pk === this.gridApi.getSelectedRows()[0].client_pk );

      if (temp_client.client_status !== 'ACTIVE') {
        this.mftServices.updatedAlert("Client is not active"); return;
      }
      if (this.gridApi.getSelectedRows()[0].user_department_status === 'INACTIVE') {
        this.mftServices.updatedAlert("Department is not active"); return;
      }
      if (this.gridApi.getSelectedRows()[0].user_project_status === 'INACTIVE') {
        this.mftServices.updatedAlert("Project is not active"); return;
      }
    } else {
      this.edit_disable = true;
    }

    const params = new HttpParams().set('user_pk', this.mftService.loggedInUser.getUser().user_pk).set('trigger_pk', this.gridApi.getSelectedRows()[0]["trigger_pk"]);
    this.mftServices.loadData("trigger_now", params).subscribe(
    (data: HttpResponse<any>) => {
      console.log(data);
      if (data.body.result === "SUCCESS") {
        this.mftServices.updatedAlert("SUCCESS");
      } else {
        this.mftServices.updatedAlert(data.body.data);
      }
      this.loadTriggerInfo(this.gridApi.getSelectedRows()[0]["trigger_pk"]);
    },
    (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
  );
};

  //   const params = new HttpParams().set('user_pk', this.mftService.loggedInUser.getUser().user_pk).set('trigger_pk', this.gridApi.getSelectedRows()[0]["trigger_pk"]);
  //   this.mftServices.loadData("trigger_now", params).subscribe(
  //     (data: HttpResponse<any>) => {
  //       this.mftServices.updatedAlert(data.body.data);
  //       this.loadTriggerInfo(this.gridApi.getSelectedRows()[0]["trigger_pk"]);
  //       this.mftServices.updatedAlert("SUCCESS");
  //     },
  //     (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
  //   );
  // };

  destTransferTypeChange(triggerDestinationIndex: number) {
    this.destination_trigger_validation = this.triggerForm.get('multiple_trigger_destination') as FormArray;
    let destination_trigger_controls = this.destination_trigger_validation.controls[triggerDestinationIndex];
    let selected_destination_transfer_type = this.destination_trigger_validation?.controls[triggerDestinationIndex].get('destination_transfer_type')?.value;
    this.divVisibility[triggerDestinationIndex] = true; 
    Object.keys(this.multiple_trigger_destination().controls[0].getRawValue()).forEach(key => {
      destination_trigger_controls.get(key)?.clearValidators();
    });

    if (selected_destination_transfer_type !== '8') {
      destination_trigger_controls.get('destination_login_type')?.setValue('');
    }
    
    if (selected_destination_transfer_type === '5' || selected_destination_transfer_type === '13' ) {
      destination_trigger_controls.get('destination_address')?.setValidators([Validators.required, Validators.maxLength(250),Validators.pattern(/^[a-zA-Z 0-9+:/-_ .]+$/)]);
      destination_trigger_controls.get('destination_login_type')?.clearValidators();
      destination_trigger_controls.get('destination_username')?.setValidators([Validators.required, Validators.maxLength(20),Validators.pattern(/^[a-zA-Z 0-9@#/.]+$/)]);
      //destination_trigger_controls.get('destination_password')?.setValidators([Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!#%^&*()])[A-Za-z\d@$!#%^&*()]{6,}$/)]);
      destination_trigger_controls.get('destination_password')?.setValidators([Validators.required]);
      destination_trigger_controls.get('destination_location')?.setValidators([Validators.required, Validators.maxLength(300)]);
      
      if (selected_destination_transfer_type === '13') {
        destination_trigger_controls.get('destination_nas_share')?.setValidators([Validators.required, Validators.maxLength(30),Validators.pattern(/^[a-zA-Z 0-9]+$/)]);
      }
    }

    if (selected_destination_transfer_type === '8') {
      destination_trigger_controls.get('destination_address')?.setValidators([Validators.required, Validators.maxLength(250),Validators.pattern(/^[a-zA-Z 0-9+ ]+$/)]);
      destination_trigger_controls.get('destination_login_type')?.setValidators([Validators.required]);
      destination_trigger_controls.get('destination_location')?.setValidators([Validators.required, Validators.maxLength(300)]);
      destination_trigger_controls.get('destination_api_url')?.setValidators([Validators.required, Validators.maxLength(150),Validators.pattern(/^[a-zA-Z0-9.-_ ]+$/)]);
      destination_trigger_controls.get('destination_login_parameters')?.setValidators([Validators.required, Validators.maxLength(150),Validators.pattern(/^[a-zA-Z 0-9|.-_ ]+$/)]);
      destination_trigger_controls.get('destination_login_parameters_values')?.setValidators([Validators.required, Validators.maxLength(150),Validators.pattern(/^[a-zA-Z 0-9|.-_ ]+$/)]);
      destination_trigger_controls.get('destination_upload_headers')?.setValidators([Validators.required, Validators.maxLength(150),Validators.pattern(/^[a-zA-Z0-9|.-_]+$/)]);
      destination_trigger_controls.get('destination_upload_headers_values')?.setValidators([Validators.required, Validators.maxLength(150),Validators.pattern(/^[a-zA-Z 0-9|.-_' + ]+$/)]);
      destination_trigger_controls.get('destination_upload_parameters')?.setValidators([Validators.required, Validators.maxLength(150),Validators.pattern(/^[a-zA-Z0-9|.-_' + ]+$/)]);
      destination_trigger_controls.get('destination_upload_parameters_values')?.setValidators([Validators.required, Validators.maxLength(150),Validators.pattern(/^[a-zA-Z 0-9|.-_' ]+$/)]);
    }

    if (selected_destination_transfer_type === '9') {
      destination_trigger_controls.get('destination_api_url')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-zA-Z 0-9.-_ ]+$/)]);
      destination_trigger_controls.get('destination_location')?.setValidators([Validators.required, Validators.maxLength(300)]);
      destination_trigger_controls.get('microsoft_login_authority_url')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-zA-Z 0-9.-_ ]+$/)]);
      destination_trigger_controls.get('application_id')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-z0-9- ]+$/)]);
      destination_trigger_controls.get('client_secret')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-zA-Z 0-9~ ]+$/)]);
      destination_trigger_controls.get('tenant_id')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-z0-9- ]+$/)]);
    }
    
    if (selected_destination_transfer_type === '10') {
      destination_trigger_controls.get('aws_access_key_id')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[A-Z 0-9 ]+$/)]);
      destination_trigger_controls.get('aws_secret_access_key')?.setValidators([Validators.required, Validators.maxLength(200),Validators.pattern(/^[a-zA-Z 0-9+/_-]+$/)]);
      destination_trigger_controls.get('aws_s3_bucket_name')?.setValidators([Validators.required, Validators.maxLength(30)]);
    }

    if (selected_destination_transfer_type === '14') {
      this.divVisibility[triggerDestinationIndex] = false; 
    }

    if (selected_destination_transfer_type === '16') {
      destination_trigger_controls.get('dest_fax_clientPk')?.setValidators([Validators.required]);
    }

    Object.keys(this.multiple_trigger_destination().controls[0].getRawValue()).forEach(key => {
      destination_trigger_controls.get(key)?.updateValueAndValidity();
    });
  };

  destLoginTypeChange(triggerDestinationIndex: number) {
    this.destination_trigger_validation = this.triggerForm.get('multiple_trigger_destination') as FormArray;
    let destination_trigger_controls = this.destination_trigger_validation.controls[triggerDestinationIndex];
    let selected_destination_login_type = this.destination_trigger_validation?.controls[triggerDestinationIndex].get('destination_login_type')?.value;

    if (selected_destination_login_type === 'UsernamePassword') {
      destination_trigger_controls.get('destination_username')?.setValidators([Validators.required, Validators.maxLength(20),Validators.pattern(/^[a-zA-Z0-9 ]+$/)]);
      destination_trigger_controls.get('destination_password')?.setValidators([Validators.required]);
      destination_trigger_controls.get('destination_api_token')?.clearValidators();
    } else if (selected_destination_login_type === 'APIToken') {
      destination_trigger_controls.get('destination_username')?.clearValidators();
      destination_trigger_controls.get('destination_password')?.clearValidators();
      destination_trigger_controls.get('destination_api_token')?.setValidators([Validators.required, Validators.maxLength(50)]);
    }
    destination_trigger_controls.get('destination_username')?.updateValueAndValidity();
    destination_trigger_controls.get('destination_password')?.updateValueAndValidity();
    destination_trigger_controls.get('destination_api_token')?.updateValueAndValidity()
  }

  check_fax_availability() {
    const params = new HttpParams().set('client_pk', this.triggerForm.get('select_client_pk')?.value);
    this.mftServices.loadData("check_fax_availability", params).subscribe(
      (data: HttpResponse<any>) => {
        this.temp_trigger_fax = data.body.allow_fax;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

}




