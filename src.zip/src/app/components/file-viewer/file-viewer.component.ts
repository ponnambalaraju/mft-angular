import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as Papa from 'papaparse';
import { FileElement } from 'src/app/file-manager/model/element';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-file-viewer',
  templateUrl: './file-viewer.component.html',
  styleUrls: ['./file-viewer.component.css']
})
export class FileViewerComponent implements OnInit {
  fileElement: any;
  fileName: string = '';
  mimeType: string = '';
  fileContent: string = '';
  parsedData: any[] = [];
  isLoading: boolean = false;
  headers: string[];
  columnTypes: { [key: string]: string; };
  rows: any[][];
  dataTypes: string[] = ['string', 'int', 'float', 'date', 'datetime', 'time'];
  showDataTypeList: boolean[] = [];
  data: any;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.fileElement = history.state.fileElement;
    if (!this.fileElement) {
      this.router.navigate(['/etl/wizard']);
      return;
    }

    this.fileName = this.fileElement.folder_name ?? '';
    this.mimeType = this.fileElement.mimetype ?? '';
    this.fileContent = atob(this.fileElement.content || '');

    this.isLoading = true;
    if (this.mimeType === 'application/json') {
      this.displayJson();
    } else if (this.mimeType === 'text/csv' || this.mimeType === 'text/tab-separated-values') {
      this.displayCsvOrTsv();
    } else if (this.mimeType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
      this.displayXlsx();
    } else {
      console.error('Unsupported file type');
      this.isLoading = false;
    }
    this.showDataTypeList = new Array(this.headers.length).fill(false);
  }

  toggleDataTypeList(index: number): void {
    this.showDataTypeList = this.showDataTypeList.map((val, i) => i === index ? !val : false);
  }


  selectDataType(header: string, type: string): void {
    console.log(`Selected type: ${type} for header: ${header}`);

    this.columnTypes[header] = type;
    console.log('Updated columnTypes:', this.columnTypes);

    this.showDataTypeList.fill(false); // Close all dropdowns
    console.log('Dropdowns closed:', this.showDataTypeList);

    // Apply conversion to the entire column based on the selected type
    this.data.forEach((row: any) => {
        if (row[header] !== undefined && row[header] !== null) {
            switch (type) {
                case 'string':
                    row[header] = this.convertToString(row[header]);
                    break;
                case 'int':
                    row[header] = this.convertToInt(row[header]);
                    break;
                case 'float':
                    row[header] = this.convertToFloat(row[header]);
                    break;
                case 'date':
                    row[header] = this.convertToDate(row[header]);
                    break;
                case 'datetime':
                    row[header] = this.convertToDateTime(row[header]);
                    break;
                case 'time':
                    row[header] = this.convertToTime(row[header]);
                    break;
                default:
                    break;
            }
        }
    });

    console.log('Updated data:', this.data); // Log the updated data to verify changes
}

convertToString(value: any): string {
  return value.toString();
}

convertToInt(value: any): number {
  return parseInt(value, 10);
}

convertToFloat(value: any): number {
  return parseFloat(value);
}

convertToDate(value: any): string {
  const date = new Date(value);
  return date.toISOString().split('T')[0]; // Format as YYYY-MM-DD
}

convertToDateTime(value: any): string {
  const date = new Date(value);
  return date.toISOString(); // Format as ISO string
}

convertToTime(value: any): string {
  const date = new Date(value);
  return date.toTimeString().split(' ')[0]; // Format as HH:MM:SS
}



  getIconClass(type: string): string {
    switch(type) {
      case 'string': return 'fa-solid fa-font';
      case 'int': return 'fa-solid fa-hashtag';
      case 'float': return 'fa-solid fa-percent';
      case 'date': return 'fa-solid fa-calendar';
      case 'datetime': return 'fa-solid fa-clock';
      case 'time': return 'fa-solid fa-hourglass';
      default: return '';
    }
  }

  displayJson(): void {
    try {
      const jsonData = JSON.parse(this.fileContent);
      this.parsedData = Array.isArray(jsonData) ? jsonData : [jsonData];
      this.inferDataTypes();
    } catch (error) {
      console.error('Error parsing JSON file:', error);
    } finally {
      this.isLoading = false;
    }
  }

  displayCsvOrTsv(): void {
    Papa.parse(this.fileContent, {
      delimiter: this.mimeType === 'text/tab-separated-values' ? '\t' : ',',
      header: true,
      complete: (result) => {
        this.parsedData = result.data;
        this.inferDataTypes();
        this.isLoading = false;
      },
      error: (error: any) => {
        console.error('Error parsing CSV/TSV file:', error);
        this.isLoading = false;
      }
    });
  }

  displayXlsx(): void {
    try {
      const workbook = XLSX.read(this.fileContent, { type: 'binary' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

      this.parsedData = this.convertXlsxToJson(jsonData);
      this.inferDataTypes();
    } catch (error) {
      console.error('Error processing XLSX file:', error);
    } finally {
      this.isLoading = false;
    }
  }

  convertXlsxToJson(sheetData: any[]): any[] {
    const headers = sheetData[0];
    const rows = sheetData.slice(1);
    return rows.map(row => {
      const obj: any = {};
      row.forEach((cell: any, index: number) => {
        obj[headers[index]] = cell;
      });
      return obj;
    });
  }

  // inferDataTypes(): void {
  //   if (this.parsedData.length === 0) {
  //     console.log('No data available to infer types.');
  //     return;
  //   }

  //   // Extract column names (headers)
  //   this.headers = Object.keys(this.parsedData[0]);
  //   console.log('Columns Header:', this.headers);

  //   const columnTypes: { [key: string]: string } = {};

  //   // Initialize type counts and infer types
  //   this.headers.forEach(col => {
  //     const columnValues = this.parsedData.map(row => row[col]);
  //     console.log(`Column Values for "${col}":`, columnValues); // Log column values
  //     columnTypes[col] = this.determineColumnType(columnValues);
  //   });

  //   // Store the column types for display
  //   this.columnTypes = columnTypes;
  //   this.rows = this.parsedData.map(row => this.headers.map(header => row[header]));

  //   // Log the data types
  //   console.log('Column Data Types:', this.columnTypes);
  // }
  inferDataTypes(): void {
    if (this.parsedData.length === 0) {
        console.log('No data available to infer types.');
        return;
    }

    // Extract column names (headers)
    this.headers = Object.keys(this.parsedData[0]);
    console.log('Columns Header:', this.headers);

    const columnTypes: { [key: string]: string } = {};

    // Filter out rows that are completely empty or only contain undefined values
    const filteredData = this.parsedData.filter(row => {
        return this.headers.some(header => row[header] !== undefined && row[header] !== '');
    });

    // Initialize type counts and infer types
    this.headers.forEach(col => {
        const columnValues = filteredData.map(row => row[col]);
        console.log(`Column Values for "${col}":`, columnValues); // Log column values
        columnTypes[col] = this.determineColumnType(columnValues);
    });

    // Store the column types for display
    this.columnTypes = columnTypes;
    this.rows = filteredData.map(row => this.headers.map(header => row[header] !== undefined ? row[header] : ''));

    // Log the data types
    console.log('Column Data Types:', this.columnTypes);
}



  determineColumnType(values: any[]): string {
    const typeCounts: { [key: string]: number } = {
      int: 0,
      float: 0,
      date: 0,
      string: 0
    };

    values.forEach(value => {
      const type = this.inferDataType(value);
      if (typeCounts[type] !== undefined) {
        typeCounts[type]++;
      }
    });

    // Determine the most common type
    const maxType = Object.keys(typeCounts).reduce((a, b) => typeCounts[a] > typeCounts[b] ? a : b);

    if (typeCounts[maxType] === 0) {
      return 'mixed';
    }

    return maxType;
  }

  inferDataType(value: any): string {
    if (value === null || value === undefined) return 'null';

    // Remove leading/trailing whitespace
    const trimmedValue = value.toString().trim();

    // Check for integer
    if (/^-?\d+$/.test(trimmedValue)) {
      return 'int';
    }

    // Check for float
    if (/^-?\d*\.?\d+$/.test(trimmedValue)) {
      return 'float';
    }

    // Check for date (YYYY-MM-DD or similar)
    const date = Date.parse(trimmedValue);
    if (!isNaN(date) && !/\d{2}:\d{2}(:\d{2})?$/.test(trimmedValue)) {
        return 'date';
    }
    // Default to string
    return 'string';
  }

  navigate() {
    this.router.navigate(['/etl/wizard']);
    }

  saveExtDatasetes(){

    }


}
