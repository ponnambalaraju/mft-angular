import { Component, AfterViewInit } from '@angular/core';
import { jsPlumb } from 'jsplumb';
import { Users } from 'src/app/models/users';
import { MftService } from 'src/app/services/mft.service';

interface File {
  name: string;
  type: string;
  id: string;
  x?: number;
  y?: number;
}

interface Formula {
  functionname: string;
  functiontype: string;
  functionid: string;
  files?: File[];
}

interface FolderFiles {
  [key: string]: File[];
}

interface WorkspaceItem extends File {
  instanceId: string;
  files?: File[];
}

@Component({
  selector: 'app-workspace',
  templateUrl: './workspace.component.html',
  styleUrls: ['./workspace.component.css']
})
export class WorkspaceComponent implements AfterViewInit {

  constructor( private mftServices: MftService, private loggedInUser: Users) {
  }


  jsPlumbInstance = jsPlumb.getInstance(); // Ensure the correct initialization of jsPlumb instance

  userData:any;
  user_pk: string;

  activeFolder: string | null = null;
  workspaceItems: WorkspaceItem[] = [];
  isAddFilesModalOpen: boolean = false;
  isViewFilesModalOpen: boolean = false;
  selectedFiles: { [key: string]: boolean } = {};
  currentWorkspaceItem: WorkspaceItem | null = null;
  selectedFilesList: File[] = [];

  dropdown1Items = [
    { name: 'HTIPL', type: 'folder' },
    { name: 'HTI', type: 'folder' },
  ];

  folderFiles: FolderFiles = {
    'HTIPL': [
      { name: 'index.html', type: 'file', id: '1' },
      { name: 'index2.html', type: 'file', id: '2' },
      { name: 'index3.html', type: 'file', id: '3' },
      { name: 'index4.html', type: 'file', id: '4' },
      { name: 'index5.html', type: 'file', id: '5' },
    ],
    'HTI': [
      { name: 'file.png', type: 'file', id: '6' },
      { name: 'image.png', type: 'file', id: '7' },
      { name: 'colour.png', type: 'file', id: '8' },
      { name: 'path.png', type: 'file', id: '9' },
      { name: 'folder.png', type: 'file', id: '10' },
    ]
  };

  formulas: Formula[] = [
    { functionname: 'Add', functiontype: 'formula', functionid: '11', files: [] },
    { functionname: 'Subtract', functiontype: 'formula', functionid: '12', files: [] },
    { functionname: 'Multiply', functiontype: 'formula', functionid: '13', files: [] },
    { functionname: 'Divide', functiontype: 'formula', functionid: '14', files: [] }
  ];

  ngAfterViewInit(): void {
    this.jsPlumbInstance.ready(() => {
      this.jsPlumbInstance.bind('connection', (info) => {
        console.log('Connection event:', info);
      });

      // Initialize jsPlumb instance for existing items
      this.workspaceItems.forEach(item => {
        this.initializeJsPlumbForItem(item);
      });
    });
  }


  ngOnInit(): void {


    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      this.user_pk = this.loggedInUser.getUser().user_pk;
    });

  }

  toggleFormula(formula: Formula) {
    this.activeFolder = this.activeFolder === formula.functionname ? null : formula.functionname;
  }

  getFilesForFolder(folderName: string): File[] {
    return this.folderFiles[folderName] || [];
  }

  getIcon(type: string): string {
    switch (type) {
      case 'folder':
        return 'folder';
      case 'file':
        return 'description';
      default:
        return 'insert_drive_file';
    }
  }

  onDragStart(event: DragEvent, item: File) {
    event.dataTransfer?.setData('text/plain', JSON.stringify(item));
  }

  onWorkspaceDragStart(event: DragEvent, item: WorkspaceItem) {
    event.dataTransfer?.setData('text/plain', JSON.stringify(item));
    event.dataTransfer?.setData('workspace', 'true');
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    const data = event.dataTransfer?.getData('text/plain');
    const workspaceData = event.dataTransfer?.getData('workspace');

    if (data) {
      const item = JSON.parse(data) as File;

      if (workspaceData) {
        // Update existing item position
        const existingItem = this.workspaceItems.find(workspaceItem => workspaceItem.id === item.id);
        if (existingItem) {
          existingItem.x = event.offsetX;
          existingItem.y = event.offsetY;
        }
      } else {
        // Add new item to workspace
        const newItem: WorkspaceItem = { ...item, id: this.generateUniqueId(), instanceId: this.generateUniqueId(), x: event.offsetX, y: event.offsetY };
        this.workspaceItems.push(newItem);
        this.initializeJsPlumbForItem(newItem);
      }
    }
  }
  initializeJsPlumbForItem(item: WorkspaceItem) {
    const element = document.getElementById(item.instanceId);
    if (!element) {
      console.error(`Element with id ${item.instanceId} not found.`);
      return;
    }
  
    this.jsPlumbInstance.draggable(element);
    this.jsPlumbInstance.makeSource(element, {
      filter: ".ep",
      anchor: "Continuous",
      connector: ["Straight", { gap: 10 }],
      connectorStyle: { stroke: "#5c96bc", strokeWidth: 2 },
      connectionType: "basic",
      extract: {
        action: "the-action"
      }
    });
    this.jsPlumbInstance.makeTarget(element, {
      dropOptions: { hoverClass: "dragHover" },
      anchor: "Continuous",
      allowLoopback: false
    });
    // Corrected endpoint addition with maxConnections
    this.jsPlumbInstance.addEndpoint(element, {
      anchor: 'Bottom',
      maxConnections: 1 // Add maxConnections property
    });
    this.jsPlumbInstance.addEndpoint(element, {
      anchor: 'Top',
      maxConnections: 1 // Add maxConnections property
    });
  }
  

  generateUniqueId(): string {
    return '_' + Math.random().toString(36).substr(2, 9);
  }

  removeItem(item: WorkspaceItem, array: WorkspaceItem[]) {
    const index = array.indexOf(item);
    if (index > -1) {
      array.splice(index, 1);
    }
    this.jsPlumbInstance.remove(item.instanceId);
  }

  addFormulaToWorkspace(formula: Formula) {
    const newItem: WorkspaceItem = {
      name: formula.functionname,
      type: formula.functiontype,
      id: this.generateUniqueId(),
      instanceId: this.generateUniqueId(),
      x: 10,
      y: 10,
      files: []
    };
    this.workspaceItems.push(newItem);
    this.initializeJsPlumbForItem(newItem);
  }

  addFileToWorkspace(file: File) {
    const newItem: WorkspaceItem = {
      ...file,
      id: this.generateUniqueId(),
      instanceId: this.generateUniqueId(),
      x: 10,
      y: 10,
      files: []
    };
    this.workspaceItems.push(newItem);
    this.initializeJsPlumbForItem(newItem);
  }

  openAddFilesModal(item: WorkspaceItem) {
    this.currentWorkspaceItem = item;
    this.isAddFilesModalOpen = true;
    this.selectedFiles = {};
  }

  closeAddFilesModal(event: Event) {
    this.isAddFilesModalOpen = false;
    this.currentWorkspaceItem = null;
  }

  saveSelectedFiles() {
    if (this.currentWorkspaceItem) {
      const selectedFileIds = Object.keys(this.selectedFiles).filter(fileId => this.selectedFiles[fileId]);
      const selectedFiles = selectedFileIds.map(fileId => this.findFileById(fileId)).filter(file => file) as File[];
      this.currentWorkspaceItem.files = selectedFiles;
    }
    this.closeAddFilesModal(new Event('close'));
  }

  findFileById(fileId: string): File | undefined {
    for (const key in this.folderFiles) {
      const file = this.folderFiles[key].find(file => file.id === fileId);
      if (file) {
        return file;
      }
    }
    return undefined;
  }

  viewFiles(item: WorkspaceItem) {
    this.selectedFilesList = item.files || [];
    this.isViewFilesModalOpen = true;
  }

  closeViewFilesModal(event: Event) {
    this.isViewFilesModalOpen = false;
  }

  preprocess() {
    console.log('Preprocess function called');
    // Add your preprocessing logic here
  }

  convertFormulaToFile(formula: Formula): File {
    return {
      name: formula.functionname,
      type: formula.functiontype,
      id: formula.functionid
    };
  }
}
