import { Component } from '@angular/core';
import { MftService } from 'src/app/services/mft.service';
import { Users } from 'src/app/models/users';

@Component({
  selector: 'app-myaccount',
  templateUrl: './myaccount.component.html',
  styleUrls: ['./myaccount.component.css']
})
export class MyaccountComponent {

  userData: any;
  constructor(private mftServices: MftService, private loggedInUser: Users) { }
  ngOnInit() {
    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
    });
  }

}
