import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { BaseComponent } from 'src/app/components/base/base.component';
import { Users } from 'src/app/models/users';
import { SelectionChangedEvent } from 'ag-grid-community';

@Component({
  selector: 'app-faxservice',
  templateUrl: './faxservice.component.html',
  styleUrls: ['./faxservice.component.css']
})
export class FaxserviceComponent extends BaseComponent implements OnInit {

  userData: any;
  gridApi: any;
  currentEvent: string;
  awsS3ColumnDefs: any;
  clientOptions: any[] = [];
  faxactiveclient: any;
  
  constructor(public override modalService: NgbModal, private mftServices: MftService, private formBuilder: FormBuilder, private loggedInUser: Users) {
    super(modalService);
  }

  awsS3Form = this.formBuilder.group({
    fax_apikey: new FormControl(''),
    fax_secretkey: new FormControl(''),
    fax_service_name: new FormControl(''),
    client_pk: new FormControl(''),
    fax_service_pk: new FormControl('', []),
  });
  
  ngOnInit() {

    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      
      this.awsS3ColumnDefs = [
        { headerName: 'Fax PK', field: 'fax_service_pk', hide: true, suppressColumnsToolPanel: true },
        { headerName: 'Fax Service Id', field: 'fax_service_id', sortable: true, filter: true, resizable: true, minWidth: 100, headerCheckboxSelection: true, checkboxSelection: true },
        { headerName: 'Fax Api Key ID', field: 'fax_apikey', sortable: true, filter: true, resizable: true, minWidth: 250 },
        { headerName: 'Fax Secret Key ID', field: 'fax_secretkey', sortable: true, filter: true,  resizable: true, minWidth: 350 },
        { headerName: 'Fax Service Name', field: 'fax_service_name', sortable: true, filter: true,  resizable: true, minWidth: 200 },
        { headerName: 'Client Name', field: 'client_name', sortable: true, filter: true, resizable: true, minWidth: 200, valueGetter: this.getClientName.bind(this) },
        { headerName: 'Client PK', field: 'client_pk', hide: true },
        { headerName: 'Fax Status (Current)', field: 'fax_status', sortable: true, filter: true, resizable: true, minWidth: 150 },  
        { headerName: 'Fax Creation Date', field: 'fax_creation_date', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Fax Activation Date', field: 'fax_activation_date', sortable: true, filter: true, resizable: true, minWidth: 170 },
        { headerName: 'Fax Deactivation Date (Last)', field: 'fax_deactivation_date', sortable: true, filter: true, resizable: true, minWidth: 170 }
      ];
    });

    this.loadactiveclients();

    this.popupModalService.showMessageAlertPopupModal.subscribe((result :{ show: boolean }) => {
      if (!result.show) {
        this.load_fax_list();
        this.loadactiveclients();
      }
    });
  }

  onSelectionChanged(event: SelectionChangedEvent) {
    const selectedData = this.gridApi.getSelectedRows();
  
    this.active_disable = true;
    this.deactive_disable = true;
    this.edit_disable = true;

    if (selectedData.length > 0) {
      const hasActive = selectedData.some((item: { fax_status: string }) => item.fax_status === "ACTIVE");
      const hasDeactive = selectedData.some((item: { fax_status: string }) => item.fax_status === "INACTIVE");

      super.disableActiveDeactive(selectedData, hasActive, hasDeactive);
    }
  }

      loadactiveclients() {
      const params = new HttpParams().set('client_pk', '%');
      this.mftServices.loadData("active_client_list", params).subscribe(
        (data: HttpResponse<any>) => { 
          this.faxactiveclient = data.body.filter((client: { allow_fax: boolean; }) => client.allow_fax === true);
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    };

    save_fax_service() {
    this.submitted = true;
    if (this.awsS3Form.invalid) {
      return;
    }

    const selectedData = this.gridApi.getSelectedRows();
    var formData: any = new FormData();
    formData.append('fax_apikey', this.awsS3Form.value['fax_apikey']),
    formData.append('fax_secretkey', this.awsS3Form.value['fax_secretkey']),
    formData.append('fax_service_name', this.awsS3Form.value['fax_service_name']),
    formData.append('client_pk', this.awsS3Form.value['client_pk']),
    formData.append('fax_service_pk', this.awsS3Form.value['fax_service_pk'] === '' || this.awsS3Form.value['fax_service_pk'] === null ? 'None' : this.awsS3Form.value['fax_service_pk']),
    formData.append('fax_status', 'ACTIVE'),
    formData.append('fax_creation_date', this.awsS3Form.value['fax_service_pk'] === '' || this.awsS3Form.value['fax_service_pk'] === null ? null : selectedData[0].fax_creation_date),
    formData.append('fax_activation_date', this.awsS3Form.value['fax_service_pk'] === '' || this.awsS3Form.value['fax_service_pk'] === null ? null : selectedData[0].fax_activation_date)

    this.mftServices.postData("save_fax_service", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.mftServices.updatedAlert('SUCCESS');
        this.modalService.dismissAll('Submit click');
        this.load_fax_list();
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  awsS3DataBind(params: any) {  
    this.gridApi = params.api;  
    this.load_fax_list();
  }

  load_fax_list() {
    const httpParams = new HttpParams();
    this.mftServices.loadData("load_fax_list", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.gridApi.setRowData(data.body);
        this.gridApi.refreshCells();
        this.active_disable = true;
        this.deactive_disable = true;
        this.edit_disable = true;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }


  open(content:any, clickEvent: string) {
    this.submitted = false;
    this.currentEvent = clickEvent;

    var availableClientPKs : number[] = [];
    this.gridApi.forEachNode((rowNode: any) => {
      availableClientPKs.push(rowNode.data.client_pk);
    });

    this.clientOptions = [];
    this.userData.client_list.forEach((client: {client_pk: number, allow_fax: number}) => {
      if (!availableClientPKs.includes(client.client_pk) && client.allow_fax === 1) {
        this.clientOptions.push(client);
      }
    });

    if (clickEvent === "NEW") {
      this.awsS3Form.patchValue({ fax_service_pk: '', client_pk: '', fax_apikey: '', fax_secretkey: '', fax_service_name: '' });
    }
    
    if (clickEvent === "EDIT") {
      const selectedData = this.gridApi.getSelectedRows();
      
      
      this.awsS3Form.patchValue({
        fax_service_pk: selectedData[0]["fax_service_pk"], client_pk: selectedData[0]["client_pk"], fax_apikey: selectedData[0]["fax_apikey"], 
        fax_secretkey: selectedData[0]["fax_secretkey"], fax_service_name: selectedData[0]["fax_service_name"] 
      });
    }
    
    const modalRef = this.modalService.open(content, {backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title'});
    modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  getClientName(params: any) {
    let client = this.userData.client_list.find((client: { client_pk: number; }) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  };

}
