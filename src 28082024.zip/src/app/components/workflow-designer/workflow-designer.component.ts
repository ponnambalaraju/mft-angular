import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { AnchorSpec, Connection, jsPlumb } from 'jsplumb';
import { FileElement } from 'src/app/file-manager/model/element';
import { Users } from 'src/app/models/users';
import { MftService } from 'src/app/services/mft.service';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-workflow-designer',
  templateUrl: './workflow-designer.component.html',
  styleUrls: ['./workflow-designer.component.css'],
})
export class WorkflowDesignerComponent implements OnInit, AfterViewInit {

  folderData: FileElement[] = [];
  userData: any;
  user_pk: any;
  clientData: any;
  client_pk: any;
  public user = { user_pk: '', client_pk: '', search_client_pk: ''}
  public client = { client_pk: '' };
  activeformulas: any;
  
  generateId(): string {
    return 'WORK' + '-' + Math.floor(Math.random() * 1000);
  }



  selectedTab: string = 'folder';
  workflowTasks: any[] = [];
  foldersFile: File[] = [];
  UploadFiles: any[] = [];
  savedWorkflows: {
    connections: any;
    name: string;
    work_id:any;
    work_pk:any;
    client_pk:any;
    user_pk:any;
    created_at:any;
    modified_at:any;
    start:any;
    start_style:any[];
    end:any;
    end_style:any[];
    files:string;
    files_style:string;
    folder:String;
    folder_style:string;
    formula:string;
    formula_style:string;
    tasks: any[];
  }[] = [];
  workflowName: string = '';
  instance: any;
  selectedWorkflow: any = null;
  currentFolderItems: any[] = [];
  navigationStack: any[] = [];
  currentParentId: string = 'root';

  constructor(private mftServices: MftService, private loggedInUser: Users, private cdr: ChangeDetectorRef) {
  }
  

  tasks = [
    { name: 'Start Task', icon: 'assets/icons/caret-right.svg' },
    { name: 'Files', icon: 'assets/icons/file-earmark.svg' },
    { name: 'Folders', icon: 'assets/icons/folder.svg' },
    { name: 'Formula', icon: 'assets/icons/calculator.svg' },
    { name: 'End Task', icon: 'assets/icons/x.svg' },
  ];

  loadCurrentFolderItems(): void {
    this.currentFolderItems = this.folderData.filter(
      (item) => item.parent_id === this.currentParentId
    );
  }

  async loadFolder(): Promise<void>{
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    } else if (this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || this.mftServices.loggedInUser.getUser().role_id === 'PROJECT_LEAD') {
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    } else {
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }

    const params = new HttpParams()
      .set('client_pk', this.user.search_client_pk)
      .set('user_pk', this.user.user_pk);

    this.mftServices.loadData("get_wizard_list", params).subscribe(
      (data: HttpResponse<any>) => {
        this.folderData = data.body;
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:',httpError);

      }
    );
  }

  loadDataSets() {
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    }
    else if(this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || 'PROJECT_LEAD'){
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    }
    else{
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams().set('client_pk',this.user.search_client_pk).set('user_pk',this.user.user_pk);
    this.mftServices.loadData("load_datasets", params).subscribe(
      (data: HttpResponse<any>) => {
        this.folderData = [...this.folderData, ...data.body];
        this.loadCurrentFolderItems();
        console.log('FolderFiles',this.folderData);
        
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:',httpError);

      }
    );
  }

  
  openItem(item: any): void {
    if (item.isFolder) {
      this.navigationStack.push(this.currentParentId);
      this.currentParentId = item.wizard_id;
      this.loadCurrentFolderItems();
    } else {
      // Handle file opening logic if necessary
      console.log('File opened:', item.folder_name);
    }
  }
  goBack(): void {
    if (this.navigationStack.length > 0) {
      this.currentParentId = this.navigationStack.pop();
      this.loadCurrentFolderItems();
    }
  }
  goForward(): void {
    // Implement logic to move forward in the navigation if needed
    console.log('Go forward logic not implemented yet');
  }

  ngOnInit() {
    this.loadCurrentFolderItems();
    this.loadFolder();
    this.loadDataSets();
    this.loadactiveformulas();

  }

  loadactiveformulas() {
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    }
    else if(this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || 'PROJECT_LEAD'){
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    }
    else{
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams().set('client_pk', this.user.search_client_pk).set('user_pk', this.user.user_pk);
    this.mftServices.loadData("get_conditional_logic_list",params).subscribe(
      (data: HttpResponse<any>) => {
        this.activeformulas = data.body
      }, 
    );
  };

  ngAfterViewInit() {
    this.instance = jsPlumb.getInstance({
      Container: 'canvas',
    });

    this.instance.bind('connection', (info: any) => {
      console.log('Connection established:', info);
    });

    this.initializeJsPlumb();
    this.refreshCanvas();

  }

  

  saveWorkflow() {
    const workflowName = (document.getElementById('workflowNameInput') as HTMLInputElement).value;
  
    if (workflowName) {
      // Retrieve all connections and map them into a simplified structure
      const connections = this.instance.getAllConnections().map((connection: { sourceId: any; targetId: any; endpoints: any[]; }) => {
        console.log('Saving connection:', connection); // Debugging output
        return {
          sourceId: connection.sourceId,
          targetId: connection.targetId,
          type: "Flowchart",
          anchors: connection.endpoints.map((endpoint: { anchor: { type: any; x: any; y: any; orientation: any; }; }) => ({
            type: endpoint.anchor.type,
            x: endpoint.anchor.x,
            y: endpoint.anchor.y,
            orientation: endpoint.anchor.orientation,
          })),
        };
      });
  
      // Arrays to store details about files, folders, and formulas
      const files: string[] = [];
      const folders: string[] = [];
      const formulas: string[] = [];
      const filesStyle: string[] = [];
      const folderStyle: string[] = [];
      const formulaStyle: string[] = [];
  
      let lastFileTaskId = '';
      let lastFolderTaskId = '';
      let lastFormulaTaskId = '';
  
      // Iterate through each task and classify them
      this.workflowTasks.forEach(task => {
        if (task.name.includes('File')) {
          if (lastFileTaskId !== '' && lastFileTaskId !== task.id) {
            files.push('|');
          }
          task.files.forEach((file: { dataset_pk: { toString: () => string; }; }) => {
            files.push(file.dataset_pk.toString());
          });
          filesStyle.push(JSON.stringify(task.style));
          lastFileTaskId = task.id;
  
        } else if (task.name.includes('Folder')) {
          if (lastFolderTaskId !== '' && lastFolderTaskId !== task.id) {
            folders.push('|');
          }
          task.files.forEach((file: { wizard_pk: { toString: () => string; }; }) => {
            folders.push(file.wizard_pk.toString());
          });
          folderStyle.push(JSON.stringify(task.style));
          lastFolderTaskId = task.id;
  
        } else if (task.name.includes('Formula')) {
          if (lastFormulaTaskId !== '' && lastFormulaTaskId !== task.id) {
            formulas.push('|');
          }
          task.files.forEach((file: { functionid: { toString: () => string; }; }) => {
            formulas.push(file.functionid.toString());
          });
          formulaStyle.push(JSON.stringify(task.style));
          lastFormulaTaskId = task.id;
        }
      });
  
      // Remove trailing separators if they exist
      if (files[files.length - 1] === '|') files.pop();
      if (folders[folders.length - 1] === '|') folders.pop();
      if (formulas[formulas.length - 1] === '|') formulas.pop();
  
      const filesString = files.join(',');
      const foldersString = folders.join(',');
      const formulasString = formulas.join(',');
      const filesStyleString = filesStyle.join(',');
      const folderStyleString = folderStyle.join(',');
      const formulaStyleString = formulaStyle.join(',');
  
      // Check if a workflow with the same name already exists
      const existingWorkflowIndex = this.savedWorkflows.findIndex(workflow => workflow.name === workflowName);
  
      // Create a new workflow object
      const newWorkflow = {
        name: workflowName,
        work_id: this.generateId(),
        work_pk: "",
        client_pk: "",
        user_pk: "",
        created_at: new Date().toISOString(),
        modified_at: new Date().toISOString(),
        start: this.workflowTasks.find(task => task.name === 'Start Task') || {},
        start_style: this.workflowTasks.find(task => task.name === 'Start Task')?.style || [],
        end: this.workflowTasks.find(task => task.name === 'End Task') || {},
        end_style: this.workflowTasks.find(task => task.name === 'End Task')?.style || [],
        files: filesString,
        files_style: filesStyleString,
        folder: foldersString,
        folder_style: folderStyleString,
        formula: formulasString,
        formula_style: formulaStyleString,
        tasks: this.workflowTasks,
        connections: connections,
      };
  
      if (existingWorkflowIndex !== -1) {
        // Update existing workflow
        this.savedWorkflows[existingWorkflowIndex] = newWorkflow;
        console.log('Workflow updated:', this.savedWorkflows[existingWorkflowIndex]);
      } else {
        // Save new workflow
        this.savedWorkflows.push(newWorkflow);
        console.log('Workflow saved:', newWorkflow);
      }
  
      // Reload workflows to reflect changes
      this.loadWorkflows();
  
      // Reset the canvas and tasks
      this.workflowTasks = [];
      this.instance.reset();
  
      // Refresh the canvas view
      this.refreshCanvas();
  
    } else {
      alert('Please enter a name for the workflow.');
    }
  }
  

  // Refresh the canvas
  refreshCanvas() {
    console.log('Refreshing canvas...');
    try {
      this.instance.reset();
      this.instance.batch(() => {
        this.workflowTasks.forEach((task) => {
          console.log('Adding task:', task);
          this.instance.addEndpoint(task.id, {
            // endpoint configuration
          });
        });
      });
    } catch (error) {
      console.error('Error refreshing canvas:', error);
    }
  }


  removeTasks() {
    // Assuming you have a way to identify and remove tasks by their IDs or other attributes
    // Example:
    const taskElements = document.querySelectorAll('.task-class'); // Update selector as needed
    taskElements.forEach((element) => element.remove());
  }

  loadWorkflows() {
    this.workflowTasks = [
      ...this.savedWorkflows[this.savedWorkflows.length - 1].tasks,
    ];
  }

  viewWorkflow(workflowName: string) {
    // Locate the workflow by its name
    const workflow = this.savedWorkflows.find((wf) => wf.name === workflowName);

    if (workflow) {
        // Clear the current state before loading a new workflow
        this.workflowTasks = [];
        this.instance.reset();

        // Set workflow tasks and render them on the canvas
        this.workflowTasks = workflow.tasks;
        this.refreshCanvas();

        // Debug: Log workflow details and connections
        console.log('Loading workflow:', workflow);
        console.log('Connections:', workflow.connections);

        // Ensure the canvas is refreshed before re-establishing connections
        setTimeout(() => {
            // Remove any existing connections
            this.instance.detachAllConnections();

            // Iterate through and establish connections with custom endpoints and anchors
            workflow.connections.forEach((connection: { sourceId: string; targetId: string; type: string; anchors: AnchorSpec[]; }) => {
                // Debug: Log connection details
                console.log('Connecting:', connection);
                console.log('Source ID:', connection.sourceId);
                console.log('Target ID:', connection.targetId);
                console.log('Type:', connection.type);

                const sourceElement = document.querySelector(`#${connection.sourceId}`);
                const targetElement = document.querySelector(`#${connection.targetId}`);

                if (sourceElement && targetElement) {
                    const sourceEndpoint = this.instance.addEndpoint(sourceElement, {
                        endpoint: ['Dot', { radius: 7 }],
                        anchor: connection.anchors[0], // Use custom source anchor
                    });

                    const targetEndpoint = this.instance.addEndpoint(targetElement, {
                        endpoint: ['Dot', { radius: 7 }],
                        anchor: connection.anchors[1], // Use custom target anchor
                    });

                    this.instance.connect({
                        source: sourceEndpoint,
                        target: targetEndpoint,
                        connector: connection.type || 'Flowchart', // Default connector type
                        paintStyle: { stroke: '#478CCF', strokeWidth: 2 },
                        overlays: [
                            {
                                type: 'Label',
                                options: {
                                    label: 'Connection Label',
                                    id: 'myLabel',
                                },
                            },
                        ],
                    });
                }
            });
        }, 200); // Delay to ensure canvas is ready
    } else {
        // Handle case where the workflow is not found
        alert('Workflow not found.');
    }
}

  



  editWorkflow(name: string) {}

  deleteWorkflow(name: string) {
    this.savedWorkflows = this.savedWorkflows.filter((w) => w.name !== name);
    this.loadWorkflows(); // Reload workflows to reflect changes
  }

  initializeJsPlumb() {
    setTimeout(() => {
      this.workflowTasks.forEach((task) => {
        // Assuming task has an id, x, y, width, and height
        const taskElement = document.getElementById(task.id);

        if (taskElement) {
          this.instance.draggable(taskElement, {
            grid: [10, 10],
            stop: (event: any) => {
              // Update task position when dragging stops
              task.x = event.finalPos[0];
              task.y = event.finalPos[1];
            },
          });

          this.instance.addEndpoint(taskElement, {
            anchors: ['Right'],
            isSource: true,
            isTarget: false,
            maxConnections: -1,
            endpointOptions: { uuid: true },
            endpoint: ['Dot', { radius: 7 }],
            paintStyle: { fill: '#478CCF' },
          });

          this.instance.addEndpoint(taskElement, {
            anchors: ['Left'],
            isSource: false,
            isTarget: true,
            maxConnections: -1,
            endpoint: ['Dot', { radius: 7 }],
            paintStyle: { fill: '#478CCF' },
          });

          // Set task element position
          taskElement.style.left = task.x + 'px';
          taskElement.style.top = task.y + 'px';
        }
      });

      this.cdr.detectChanges();
    }, 100); // Delay to ensure elements are ready for jsPlumb
  }

  initializeTask(taskId: string, taskName: string) {
    this.instance.draggable(taskId);
    const sourceEndpointUuid = uuidv4();
const targetEndpointUuid = uuidv4();

const sourceEndpoint = {
  uuid: sourceEndpointUuid,
  // other properties
};

const targetEndpoint = {
  uuid: targetEndpointUuid,
  // other properties
};
    

    const commonEndpointOptions = {
      connector: ['Flowchart', { curviness: 50 }],
      endpoint: ['Dot', { radius: 7 }],
      paintStyle: { fill: '#77E4C8', strokeWidth: 2 },
      connectorStyle: { stroke: '#478CCF', strokeWidth: 3 },
      connectorOverlays: [
        ['Arrow', { width: 12, length: 12, location: 1 }],
        [
          'Label',
          { label: taskName, location: 0.5, cssClass: 'connector-label' },
        ],
      ],
    };

    if (
      taskName === 'Files' ||
      taskName === 'Formula' ||
      taskName === 'Folders'
    ) {
      this.instance.addEndpoint(taskId, {
        anchor: 'Left',
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        endpointOptions: { uuid: true },
        ...commonEndpointOptions,
      });

      this.instance.addEndpoint(taskId, {
        anchor: 'Right',
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        endpointOptions: { uuid: true },
        ...commonEndpointOptions,
      });
    } else {
      this.instance.addEndpoint(taskId, {
        anchors: ['Top', 'Bottom', 'Left', 'Right'],
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        endpointOptions: { uuid: true },
        ...commonEndpointOptions,
      });
    }
  }

  selectTab(tab: string) {
    this.selectedTab = tab;
  }

  onTabChange(tab: string) {
    this.selectedTab = tab;
  }

  //deldting the workarea

  onDragStart(event: DragEvent, task: any) {
    event.dataTransfer?.setData('task', JSON.stringify(task));
  }

  onTaskDelete(taskId: string) {
    // Remove task from the workflowTasks array
    this.workflowTasks = this.workflowTasks.filter(
      (task) => task.id !== taskId
    );

    // Remove the task's connections and endpoints from jsPlumb
    this.instance.removeAllEndpoints(taskId);
    this.instance.remove(taskId);
  }

  CloseWorkflowTask(taskId: string): void {
    this.onTaskDelete(taskId);
    console.log(`Task ${taskId} closed`);
  }

  allowDrop(event: DragEvent) {
    event.preventDefault();
  }

  //Ondrop Event
  onDrop(event: DragEvent) {
    event.preventDefault();
    const data = event.dataTransfer?.getData('task');
    if (data) {
      const task = JSON.parse(data);
      this.addTaskToCanvas(task, event.clientX, event.clientY);
    }
  }

  //Adding Task to Canvas
  addTaskToCanvas(task: any, x: number, y: number) {
    const canvas = document.getElementById('canvas');
    if (canvas) {
      const rect = canvas.getBoundingClientRect();
      const style = {
        top: `${y - rect.top}px`,
        left: `${x - rect.left}px`,
      };
      const id = 'task-' + new Date().getTime();

      this.workflowTasks.push({
        ...task,
        id,
        style,
        files: [], // Initialize files array
      });

      setTimeout(() => {
        this.initializeTask(id, task.name);
      }, 0);
    }
  }

  //File Drop
  onFileDrop(event: DragEvent, task: any): void {
    event.preventDefault();
    const draggedItem = JSON.parse(
      event.dataTransfer?.getData('draggedItem') || '{}'
    );
    console.log('Parsed data:', draggedItem);

    if (draggedItem && draggedItem.isFolder === false) {
      task.files.push({ ...draggedItem });
      console.log('File successfully added to task:', draggedItem);
    } else {
      alert('Dragged file is invalid');
    }
  }
  //Formula Drop
  onFormulaDrop(event: DragEvent, task: any): void {
    event.preventDefault();
    const draggedItem = JSON.parse(
      event.dataTransfer?.getData('draggedItem') || '{}'
    );
    if (draggedItem && draggedItem.formula_name) {
      task.files.push({ ...draggedItem }); // Copy the file object
    } else {
      alert('Dragged Formula is invalid');
    }
  }
  //Folder Drop
  onFolderDrop(event: DragEvent, task: any): void {
    event.preventDefault();
    const draggedItem = JSON.parse(
      event.dataTransfer?.getData('draggedItem') || '{}'
    );
    if (draggedItem && draggedItem.isFolder === true) {
      // Check if the file type is valid (if necessary)

      task.files.push({ ...draggedItem }); // Copy the file object into the task
      console.log(`File dropped into task:`, draggedItem);
    } else {
      alert('Dragged item is not a file or is invalid');
    }
  }

  getFileIcon(file: File): string {
    return '📄'; // Use a generic file icon
  }

  //File Drag
  onFileDragStart(event: DragEvent, item: any): void {
    event.dataTransfer?.setData('draggedItem', JSON.stringify(item));
    event.dataTransfer!.effectAllowed = 'copy'; // Allow only copy operation
    console.log(`Dragging started for folder: ${item.folder_name}`);
    console.log(item);
  }
  //Formula Drag
  onFormulaDragStart(event: DragEvent, formula: any): void {
    if (event.dataTransfer) {
      event.dataTransfer?.setData('draggedItem', JSON.stringify(formula));
      event.dataTransfer!.effectAllowed = 'copy';
      console.log(`Dragging started for: ${formula.name}`);
    }
  }
  //Folder Drag
  onFolderDragStart(event: DragEvent, item: any): void {
    if (event.dataTransfer) {
      event.dataTransfer?.setData('draggedItem', JSON.stringify(item));
      event.dataTransfer!.effectAllowed = 'copy';
      console.log(`Dragging started for folder: ${item.folder_name}`);
      console.log(item);
    }
  }
}
