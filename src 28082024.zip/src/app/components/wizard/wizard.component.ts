import { Component, OnInit } from '@angular/core';
import { Observable, of } from 'rxjs';
import { FileService } from 'src/app/services/file.service';
import { FileElement } from '../../file-manager/model/element';
import { Users } from 'src/app/models/users';
import { MftService } from 'src/app/services/mft.service';
import { EncryptionService } from '../../services/encryption.service';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';


@Component({
  selector: 'app-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.css']
})

export class WizardComponent implements OnInit {
  public fileElements: Observable<FileElement[]> = of([]);
  public currentRoot: FileElement | null = null;
  public currentPath = '';
  public canNavigateUp = false;
  currentDatetime: '';
  public user = { user_pk: '', client_pk: '', search_client_pk: ''}

  files: FileElement[] = [];
  folders: FileElement[] = []

  constructor(public fileService: FileService, private mftServices:MftService, private encryptionService: EncryptionService) {}

  async ngOnInit() {
    await this.loadFolder();

    this.loadDataSets();
  }

  async loadFolder(): Promise<void>{
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    } else if (this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || this.mftServices.loggedInUser.getUser().role_id === 'PROJECT_LEAD') {
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    } else {
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }

    const params = new HttpParams()
      .set('client_pk', this.user.search_client_pk)
      .set('user_pk', this.user.user_pk);

    this.mftServices.loadData("get_wizard_list", params).subscribe(
      (data: HttpResponse<any>) => {
        this.folders = data.body;
        this.folders.forEach(fileElement => {
          this.fileService.add(fileElement);
        });
        this.updateFileElementQuery();
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:',httpError);

      }
    );
  }

  loadDataSets() {
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    }
    else if(this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || 'PROJECT_LEAD'){
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    }
    else{
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams().set('client_pk',this.user.search_client_pk).set('user_pk',this.user.user_pk);
    this.mftServices.loadData("load_datasets", params).subscribe(
      (data: HttpResponse<any>) => {
        this.files= data.body;
        this.files.forEach(fileElement => {
          this.fileService.add(fileElement);
        });
        this.updateFileElementQuery();
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:',httpError);

      }
    );
  }

  async addFolder(folder: { name: string }) {
    const result = this.fileService.add({
      isFolder: true,
      folder_name: folder.name,
      parent_id: this.currentRoot ? this.currentRoot.wizard_id : 'root',
      wizard_pk: '',
      client_pk: this.mftServices.loggedInUser.getUser().user_pk,
      user_pk: this.mftServices.loggedInUser.getUser().user_pk,
      wizard_create_at: this.currentDatetime
    });

    console.log('Result of add operation:', result);

    const formData: any = new FormData();
    let Data = this.encryptionService.encrypt(JSON.stringify(result));
    formData.append('folder_data', Data);
    this.mftServices.postData("create_folder", formData).subscribe(
      response => {
        if (response.body && (response.body as any)['message'].includes('SUCCESS')) {
          this.mftServices.updatedAlert("Wizard Created Successfully.");
          this.loadFolder();
        } else {
          this.mftServices.updatedAlert("Failed to Create Wizard");

        }
      },
      error => { console.error(error); }
    );
  }


  removeElement(element: FileElement) {
    this.fileService.delete(element.wizard_id!);
    this.updateFileElementQuery();
  }

  navigateToFolder(element: FileElement) {
    this.currentRoot = element;
    this.updateFileElementQuery();
    this.currentPath = this.pushToPath(this.currentPath, element.folder_name);
    this.canNavigateUp = true;
  }

navigateUp() {
  if (this.currentRoot && this.currentRoot.wizard_id === 'root') {
    // At the root level, reset the root and path
    this.currentRoot = null;
    this.canNavigateUp = false;
    this.updateFileElementQuery();
  } else if (this.currentRoot) {
    // Get the parent folder using parent_id
    const parentId = this.currentRoot.parent_id || 'root'; // Use 'root' as a fallback
    this.currentRoot = this.fileService.get(parentId) || null;
    this.updateFileElementQuery();
  }

  // Correctly update the path to reflect the parent folder
  this.currentPath = this.popFromPath(this.currentPath);
  console.log("Current Root:", this.currentRoot);
  console.log("Current Path:", this.currentPath);

  }


  moveElement(event: { element: FileElement; moveTo: FileElement }) {
    console.log('Current wizard items',event.element);
    console.log('Current wizard items',event.moveTo);
    event.element.parent_id = event.moveTo.wizard_id;
    console.log('Updated element:', event.element);
    const formData: any = new FormData();
    formData.append('updateFilesAndFolders',JSON.stringify(event.element));
    this.mftServices.postData("update_foldersAndFiles", formData).subscribe(
      response => {
        if (response.body && (response.body as any)['message'].includes('SUCCESS')) {
          this.mftServices.updatedAlert("Upload Success.");
          if(event.element.isFolder){
            this.loadFolder()
          }else{
            this.loadDataSets()
          }
        } else {
          this.mftServices.updatedAlert("Failed to Upload File");

        }
      },
      error => { console.error(error); }
    );
  }

  renameElement(element: FileElement) {
    this.fileService.update(element.wizard_id!, { folder_name: element.folder_name });
    this.updateFileElementQuery();
  }

  updateFileElementQuery() {
    this.fileElements = this.fileService.queryInFolder(
      this.currentRoot ? this.currentRoot.wizard_id! : 'root'
    );
  }

  pushToPath(path: string, folderName: string): string {
    return `${path}${folderName}/`;
  }

  popFromPath(path: string): string {
    const split = path.split('/');
    split.splice(split.length - 2, 1);
    return split.join('/');
  }

}

