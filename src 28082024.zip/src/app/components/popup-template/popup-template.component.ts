import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { PopupModalService } from 'src/app/services/popup-modal.service';

@Component({
  selector: 'app-popup-template',
  templateUrl: './popup-template.component.html',
  styleUrls: ['./popup-template.component.css']
})
export class PopupTemplateComponent {

  @Input() data: any;

  constructor(public activeModal: NgbActiveModal, private router: Router, private mftServices: MftService, private popupModalService: PopupModalService) { }
  
  handleClickResponse(responseString: string) {
    this.activeModal.close();
    if (this.data.process === 'Session Expired') {
      this.router.navigate(['']);
      this.popupModalService.closeTimeoutModal();
    } else if (this.data.process === 'Duplicate Session...') {
      this.router.navigate(['']);
      this.popupModalService.closeTimeoutModal();
    } else if (responseString === 'YES' && (this.data.process === 'activate' || this.data.process === 'deactivate')) {
      var formData: any = new FormData();
      formData.append(this.data.service + '_pk', this.data.selectedPKs),
      formData.append(this.data.service + '_status', this.data.process === 'activate' ? 'ACTIVE' : 'INACTIVE')

      this.mftServices.postData("update_" + this.data.service + "_status", formData).subscribe(
        (data: HttpResponse<any>) => {
          this.mftServices.updatedAlert('The '+ (this.data.service) +' account has been '+ this.data.process +'d successfully');
          if (this.data.service === 'user' || this.data.service === 'trigger' || this.data.service === 'scheduler') {
          } else {
            this.mftServices.updatedAlert('The '+ (this.data.service) +' account has been '+ this.data.process +'d successfully');
            this.data.gridApi.setRowData(data.body);
            this.data.gridApi.refreshCells();
          }
          this.popupModalService.closeMessageAlertPopupModal();
        },
        (httpError: HttpErrorResponse) => { 
          if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
            this.popupModalService.openTimeoutModal();
          } else {
            console.error('There was an error!', httpError.message);
          }
         }
      );
    }
  };

}
