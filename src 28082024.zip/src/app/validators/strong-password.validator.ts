// strong-password.validator.ts

import { AbstractControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { Users } from '../models/users';

export function strongPasswordValidator(usersService: Users): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {

        const newPassword = control.get('new_password');
        const confirmPassword = control.get('confirm_password');

        if (!newPassword?.value || !confirmPassword?.value) {
            console.log('Fields are empty');
            return null; // Return null if either field is empty
        }

        const passwordPattern = new RegExp(usersService.getPasswordPattern());
        // console.log('Password Pattern:', passwordPattern);

        if (passwordPattern.test(newPassword.value)) {
            console.log('Password does not meet the criteria');
            return { 'weakPassword': 'Password must be strong (at least 8 characters, including uppercase, lowercase, digits, and special characters).' };
        }

        // Password match validation
        if (newPassword.value !== confirmPassword.value) {
            console.log('Passwords do not match');
            return { 'passwordMismatch': 'Passwords do not match.' };
        }

        console.log('Password is strong');
        return null;
    };
}
