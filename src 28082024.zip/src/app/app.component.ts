
import { ChangeDetectorRef, Component, OnInit, OnChanges, SimpleChanges, ViewChild, HostListener } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { MediaMatcher } from '@angular/cdk/layout';
import { MatIconRegistry } from '@angular/material/icon';
import { MatSidenav } from '@angular/material/sidenav';
import { DomSanitizer } from '@angular/platform-browser';
import { NgbModal, NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from './services/mft.service';
import { Users } from './models/users';
import { debounceTime } from 'rxjs';
import { environment } from '../environments/environment';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { BaseComponent } from './components/base/base.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent extends BaseComponent implements OnInit, OnChanges {

  currentYear = new Date().getFullYear();
  alphabetic_character: number;
  lowercase_character: number;
  uppercase_character: number;
  number_character: number;
  special_character: number
  consecutive_character: number;
  loginname_consecutive_character: number;
  number_consecutive_character: number;
  email_consecutive_character: number;
  min_length_character: number;
  max_length_character: number;
  alphabetic_character_isChecked:boolean =false;
  lower_character_isChecked:boolean =false;
  upper_character_isChecked:boolean =false;
  numeric_character_isChecked:boolean =false;
  special_character_isChecked:boolean =false;
  consecutive_character_isChecked:boolean =false;
  min_max_isChecked:boolean =false;
  passwordPattern: string;
  uploadedImage: string | ArrayBuffer | null = null;
  newPassword: string ='';
  oldPassword: string ='';
  confirmPassword: string ='';


  @ViewChild('snav') snav: MatSidenav;

  environment = environment.environment;
  //private _success = new Subject<string>();
	staticAlertClosed = false;
	successMessage = '';
	@ViewChild('selfClosingAlert', { static: false }) selfClosingAlert: NgbAlert;

  old_pwd: string;
  new_pwd: string;
  confirm_pwd: string;
  weakPassword: string = "";
  passwordMismatch: string = "";
  emptyPassword: string = "";
  assets_address: string = "";
  isDivOpen: boolean = false;
  isOpen: boolean = false;
  overlayState: string = 'out';
  overlay: string = 'out';

  radioAlphabeticActivated: boolean = false;
  radioUppercaseActivated: boolean = false;
  radioLowercaseActivated: boolean = false;
  radioNumericActivated: boolean = false;
  radioSpecialCharactersActivated: boolean = false;
  radioConsecutiveActivated: boolean = false;
  radiosymbolconsecutiveActivated: boolean = false;
  radionumberconsecutiveActivated: boolean = false;
  radioMinMaxActivated: boolean = false;
  radioAlphabeticActivatednewPas = false;
  radioUppercaseActivatednewPas = false;
  radioLowercaseActivatednewPas = false;
  radioNumericActivatednewPas = false;
  radioSpecialCharactersActivatednewPas = false;
  radioConsecutiveActivatednewPas = false;
  radiosymbolconsecutiveActivatednewPas = false;
  radionumberconsecutiveActivatednewPas = false;
  radioMinMaxActivatednewPas = false;

  public currentURL: string = "";
  data: any;

  @HostListener('document:mousemove', ['$event'])
  @HostListener('document:keydown', ['$event'])
  onUserActivity() {
    this.resetLogoutTimer();
  }

  private startLogoutTimer() {
    this.logoutTimer = setTimeout(() => {
      this.logoutUser();
    }, 900000); // 15 minutes
  }

  private resetLogoutTimer() {
    clearTimeout(this.logoutTimer);
    this.startLogoutTimer();
  }

  private logoutUser() {
    // Perform logout actions, e.g., invalidate session/token
    this.router.navigate(['/logout']);
  }

  openSidebar: boolean = true;

  menuSidebar = [
    {
      link_name: "Dashboard",
      link: "/dashboard",
      icon: '/assets/icons/Dashboard.svg',
      moduleId: 0,
      sub_menu: []
    },{
      link_name: "Triggers",
      link: "/triggers",
      icon: '/assets/icons/Triggers.svg',
      moduleId: 4,
      sub_menu: []
    }, {
      link_name: "Schedulers",
      link: "/schedulers",
      icon: '/assets/icons/Schedulers.svg',
      moduleId: 5,
      sub_menu: []
    }, {
      link_name: "Reports",
      link: "/reports",
      icon: '/assets/icons/Reports.svg',
      moduleId: 6,
      sub_menu: []
    }, {
      link_name: "AWS S3 Reports",
      link: "/aws_s3_reports",
      icon: '/assets/icons/AWSS3Reports.svg',
      moduleId: 11,
      sub_menu: []
    },
    {
      link_name: "My Profile",
      link: "/profile",
      icon: '/assets/icons/MyAccount.svg',
      moduleId: 0,
      sub_menu: []
    },{
      link_name: "ETL Configuration",
      link: null,
      icon: "/assets/icons/AdminConfiguration.svg",
      sub_menu: [
        {
          link_name: "Wizard",
          link: "/etl/wizard",
          icon: '/assets/icons/MyAccount.svg',
          moduleId: 18,
        },
        {
          link_name: "Conditional Logic",
          link: "/etl/logic",
          icon: '/assets/icons/MyAccount.svg',
          moduleId: 17,
        },
        {
          link_name: "Workflow designer",
          link: "/etl/workflowdesigner",
          icon: '/assets/icons/MyAccount.svg',
          moduleId: 16,
        },
      ]
    },{
      link_name: "Admin Configuration",
      link: null,
      icon: "/assets/icons/AdminConfiguration.svg",
      sub_menu: [
        {
          link_name: "Client setup",
          link: "/admin/clientsetup",
          icon: '/assets/icons/ClientSetup.svg',
          moduleId: 1
        }, {
          link_name: "Groups & Projects",
          link: "/admin/groupsprojects",
          icon: '/assets/icons/Groups.svg',
          moduleId: 2
        },
        {
          link_name: "User Management",
          link: "/admin/usermanagement",
          icon: '/assets/icons/UserCreation.svg',
          moduleId: 3
        },
        {
          link_name: "Authentication Policy",
          link: "/admin/authenticationpolicy",
          icon: '/assets/icons/AuthenticationPolicy.svg',
          moduleId: 9
        },
        {
          link_name: "HTI - Amazon S3",
          link: '/admin/hti-amazons3',
          icon: '/assets/icons/AmazonS3.svg',
          moduleId: 10
        },{
          link_name: "Role Management",
          link: "/admin/rolemanagement",
          icon: '/assets/icons/RoleManagement.svg',
          moduleId: 7
        },{
          link_name: "Password Reset",
          link: "/admin/passwordreset",
          icon: '/assets/icons/PasswordReset.svg',
          moduleId: 8
        },{
          link_name: "Email Templates",
          link: "/mailtemplate",
          icon: '/assets/icons/EmailTemplate.svg',
          moduleId: 12
        },{
          link_name: "Fax Profile",
          link: "/faxprofile",
          icon: '/assets/icons/Fax.svg',
          moduleId: 13
        },{
          link_name: "Fax Service",
          link: "/faxservice",
          icon: '/assets/icons/Fax.svg',
          moduleId: 14
        },
      ]
    },
  ]

  constructor(public router: Router, changeDetectorRef: ChangeDetectorRef, media: MediaMatcher, private matIconRegistry: MatIconRegistry,
    private domSanitzer: DomSanitizer, public override modalService: NgbModal, private mftServices: MftService, private loggedInUser: Users, private usersService: Users) {

      super(modalService);

      let tabsPromise = new Promise<string>((resolve, reject) => {
        let broadcast = new BroadcastChannel('test');
        let alertShown = false;
        broadcast.postMessage('I am First');
        broadcast.onmessage = (event) => {
          if (event.data === "I am First") {
            broadcast.postMessage(`Sorry! Already open`);
            alertShown = true;
          }
          if (event.data === `Sorry! Already open` && !alertShown) {
            console.log(this.currentURL);
            /* if (this.currentURL !== '/') {
              this.popupModalService.openDuplicateTabModal();
              return;
            } */
          }
        };
      });

      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      this.mobileQuery.addListener(this._mobileQueryListener);
      this.matIconRegistry.addSvgIcon('ClientSetup', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/ClientSetup.svg'));
      this.matIconRegistry.addSvgIcon('Dashboard', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Dashboard.svg'));
      this.matIconRegistry.addSvgIcon('Schedulers', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Schedulers.svg'));
      this.matIconRegistry.addSvgIcon('LogManagement', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/LogManagement.svg'));
      this.matIconRegistry.addSvgIcon('My Profile', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/MyAccount.svg'));
      this.matIconRegistry.addSvgIcon('PasswordReset', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/PasswordReset.svg'));
      this.matIconRegistry.addSvgIcon('Reports', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Reports.svg'));
      this.matIconRegistry.addSvgIcon('Triggers', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Triggers.svg'));
      this.matIconRegistry.addSvgIcon('Groups', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Groups.svg'));
      this.matIconRegistry.addSvgIcon('UserCreation', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/UserCreation.svg'));
      this.matIconRegistry.addSvgIcon('AuthenticationPolicy', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/AuthenticationPolicy.svg'));
      this.matIconRegistry.addSvgIcon('AmazonS3', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/AmazonS3.svg'));
      this.matIconRegistry.addSvgIcon('RoleManagement', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/RoleManagement.svg'));
      this.matIconRegistry.addSvgIcon('Requisition', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Reports.svg'));
      this.matIconRegistry.addSvgIcon('hl7', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Reports.svg'));
      this.matIconRegistry.addSvgIcon('AWSS3Reports', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/AWSS3Reports.svg'));
      this.matIconRegistry.addSvgIcon('EmailTemplate', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/EmailTemplate.svg'));
      this.matIconRegistry.addSvgIcon('Fax Profile', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Fax.svg'));
      this.matIconRegistry.addSvgIcon('Fax Service', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/Fax.svg'));
      this.matIconRegistry.addSvgIcon('Data Sets', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/MyAccount.svg'));
      this.matIconRegistry.addSvgIcon('Wizard', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/MyAccount.svg'));
      this.matIconRegistry.addSvgIcon('Conditional Logic', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/MyAccount.svg'));
      this.matIconRegistry.addSvgIcon('Workflow designer', this.domSanitzer.bypassSecurityTrustResourceUrl('/assets/icons/MyAccount.svg'));
  }

  userData: any;
  PageTitle: string;
  private logoutTimer: any;

  ngOnInit() {

  // chatbot visibility code starts

  // this.router.events.subscribe(event => {
  //   if (event instanceof NavigationEnd) {
  //     const isLoginPage = event.url === '/';
  //     const bpFabElements = document.querySelectorAll('.bp-widget-widget ');
  //     bpFabElements.forEach(element => {
  //       (element as HTMLElement).style.display = isLoginPage ? 'none' : 'block';
  //     });
  //   }
  // });


    // chatbot visibility code ends

    this.startLogoutTimer();
    this.mftServices.data$.subscribe((value) => {
      if (value === 'New Value') {
        this.userData = this.loggedInUser.getUser();
              if(this.userData.profile_logo )
        this.uploadedImage = 'data:image/png;base64,' + this.userData.profile_logo;
      } else {
        this.mftServices.loadData("reloading", new HttpParams()).subscribe(
          (data: HttpResponse<any>) => {
            const userData = { user_id: data.body.user_id, user_pk: data.body.user_pk, user_name: data.body.user_name, user_status: data.body.user_status,
              user_creation_date: data.body.user_creation_date, user_activation_date: data.body.user_activation_date, user_deactivation_date: data.body.user_deactivation_date,
              user_locked: data.body.user_locked, user_email: data.body.user_email, user_phone_no: data.body.user_phone_no, user_password: data.body.user_password,
              user_description: data.body.user_description, client_pk: data.body.client_pk, client_id: data.body.client_id, client_name: data.body.client_name,
              client_status: data.body.client_status, role_pk: data.body.role_pk, role_id: data.body.role_id, role_name: data.body.role_name, role_status: data.body.role_status,
              allow_downloading_files: data.body.allow_downloading_files, user_created_by: data.body.user_created_by, functional_privileges_pk: data.body.functional_privileges_pk, profile_logo: data.body.profile_logo,
              app_modules_pk: data.body.app_modules_pk, client_list: data.body.client_list, table_headers_list: data.body.table_headers_list, customized_headers_list: data.body.customized_headers_list,
            };

            this.loggedInUser.setUser(userData);
            const newValue = 'New Value';
            this.mftServices.updateData(newValue);
          },
          (httpError: HttpErrorResponse) => { /* super.httpErrorHandler(httpError); */ }
        );
      }
    });

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.currentURL = event.url;
        if (this.currentURL === '/dashboard') { this.PageTitle = "Dashboard"; }
        else if (this.currentURL === '/mailtemplate') { this.PageTitle = "Mail Template"; }
        else if (this.currentURL === '/faxprofile') { this.PageTitle = "Fax Creation"; }
        else if (this.currentURL === '/faxservice') { this.PageTitle = "Fax Service"; }
        else if (this.currentURL === '/triggers') { this.PageTitle = "Triggers"; }
        else if (this.currentURL === '/schedulers') { this.PageTitle = "Schedulers"; }
        else if (this.currentURL === '/reports') { this.PageTitle = "Reports"; }
        else if (this.currentURL === '/aws_s3_reports') { this.PageTitle = "AWS S3 Reports"; }
        else if (this.currentURL === '/profile') { this.PageTitle = "My Profile"; }
        else if (this.currentURL === '/admin/clientsetup') { this.PageTitle = "Client Setup"; }
        else if (this.currentURL === '/admin/usermanagement') { this.PageTitle = "User Management"; }
        else if (this.currentURL === '/admin/groupsprojects') { this.PageTitle = "Groups & Projects"; }
        else if (this.currentURL === '/admin/authenticationpolicy') { this.PageTitle = "Authentication Policy";}
        else if (this.currentURL === '/admin/logmanagement') { this.PageTitle = "Log Management"; }
        else if (this.currentURL === '/admin/passwordreset') { this.PageTitle = "Password Reset"; }
        else if (this.currentURL === '/admin/hti-amazons3') { this.PageTitle = "HTI - Amazon S3"; }
        else if (this.currentURL === '/admin/rolemanagement') { this.PageTitle = "Role Management"; }
        else if (this.currentURL === '/requisition') { this.PageTitle = "Requisition Form"; }
        else if (this.currentURL === '/hl7') { this.PageTitle = "HL7 Messages"; }
        else if (this.currentURL === '/etl/datasets') { this.PageTitle = "Data Sets"; }
        else if (this.currentURL === '/etl/wizard') { this.PageTitle = "Wizard"; }
        else if (this.currentURL === '/etl/transformation') { this.PageTitle = "Transformation"; }
        else if (this.currentURL === '/etl/logic') { this.PageTitle = "Conditional Logic"; }
        else if (this.currentURL === '/etl/workflowdesigner') { this.PageTitle = "Workflow designer"; }
      }
    });

		this.mftServices.successMessage$.subscribe((message) => (this.successMessage = message));
		this.mftServices.successMessage$.pipe(debounceTime(5000)).subscribe(() => {
			if (this.selfClosingAlert !== undefined) {
        this.selfClosingAlert.close();
      }
		});
  };

  ngOnChanges(changes: SimpleChanges): void {
    // Perform validation on myModelVariable
    this.userData = this.loggedInUser.getUser(); // Set the value of isValid based on some condition
  }

  title = 'MFT';

  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  open(content: any) {
    this.resetRadioButtons();
    this.getPasswordValidator();
    this.submitted = false;
    this.modalService.open(content, { backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title' }).result.then(
      (result) => {
        this.closeResult = `Closed with: ${result}`;
      },
      (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      }
    );
  }

  resetRadioButtons() {
    this.radioAlphabeticActivated = false;
    this.radioUppercaseActivated = false;
    this.radioLowercaseActivated = false;
    this.radioNumericActivated = false;
    this.radioSpecialCharactersActivated = false;
    this.radioConsecutiveActivated = false;
    this.radiosymbolconsecutiveActivated = false;
    this.radionumberconsecutiveActivated = false;
    this.radioMinMaxActivated = false;
    this.radioAlphabeticActivatednewPas = false;
    this.radioUppercaseActivatednewPas = false;
    this.radioLowercaseActivatednewPas = false;
    this.radioNumericActivatednewPas = false;
    this.radioSpecialCharactersActivatednewPas = false;
    this.radioConsecutiveActivatednewPas = false;
    this.radiosymbolconsecutiveActivatednewPas = false;
    this.radionumberconsecutiveActivatednewPas = false;
    this.radioMinMaxActivatednewPas = false;
  }

  updatePassword() {
if (this.new_pwd === null || typeof this.new_pwd === 'undefined') {
  this.new_pwd = '';
}
if (this.old_pwd === null || typeof this.old_pwd === 'undefined') {
  this.old_pwd = '';
}

if (this.confirm_pwd === null || typeof this.confirm_pwd === 'undefined') {
  this.confirm_pwd = '';
}




    if (this.new_pwd==='' && this.old_pwd==='' && this.confirm_pwd===''){
      this.newPassword = "/"
      this.oldPassword = "Old Password is required"
      this.confirmPassword = "/"
      return;
    }else if(this.new_pwd==='' && this.old_pwd===''){
      this.newPassword = "New Password is required"
      this.oldPassword = "Old Password is required"
      this.confirmPassword = "" ;

      return;
    }else if(this.old_pwd===''&& this.confirm_pwd===''){
      this.oldPassword = "Old Password is required"
      this.newPassword = ""
      this.confirmPassword = "Confirm Password is required"
      return;
    }else if(this.confirm_pwd==='' && this.new_pwd===''){
      this.oldPassword = ""
      this.confirmPassword = "Confirm Password is required"
      this.newPassword = "New Password is required"
      return;
    }else if(this.new_pwd===''){
      this.newPassword = "New Password is required"
      this.oldPassword = "";
      this.confirmPassword = "";

      return;
    }else if(this.old_pwd===''){
      this.oldPassword = "Old Password is required"
      this.confirmPassword = "";
      this.newPassword = "";
            return;
    }else if(this.confirm_pwd===''){
      this.confirmPassword = "confirm Password is required"
      this.newPassword = "";
      this.oldPassword = "";
      return;
    }else{
      this.confirmPassword = "";
      this.newPassword = "";
      this.oldPassword = "";
    }
    const passwordPattern = new RegExp(this.passwordPattern);
    if (!passwordPattern.test(this.new_pwd)) {
      this.passwordMismatch =""
      return;
    }

    // Password match validation
    if (this.new_pwd !== this.confirm_pwd) {
        this.passwordMismatch = "Passwords do not match.";
        return;
    }

    this.submitted = true;

    if (this.old_pwd === '') { return; } else { this.emptyPassword === '' }

    var formData: any = new FormData();
    formData.append('old_password', this.old_pwd);
    formData.append('new_password', this.new_pwd);
    formData.append('user_pk', this.userData.user_pk);

    this.mftServices.postData('update_old_password', formData).subscribe(
      (data: HttpResponse<any>) => {
          this.mftServices.updatedAlert(data.body.result + " - " + data.body.data);
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          this.popupModalService.openTimeoutModal();
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
    );
    this.modalService.dismissAll('Update Password');
  }

  showElement = true;

  // @HostListener('window:beforeunload', ['$event'])
  // onBeforeUnload(event: Event) {
  //   this.logout();
  // }

  logout() {
    var formData: any = new FormData();
    formData.append('user_pk', this.userData.user_pk);

    this.mftServices.postData("logout", formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.data === 'SUCCESS') {
          this.showElement = false;
          this.router.navigate(['']);
        } else {
          alert('Failure');
        }
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          this.popupModalService.openTimeoutModal();
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
    );
  }

  passwordValue(eventValue: any, fieldName: string) {
    if (fieldName === "old_password") {
      this.old_pwd = eventValue.target.value;
    } else if (fieldName === "new_password") {
      this.new_pwd = eventValue.target.value;
    } else if (fieldName === "confirm_password") {
      this.confirm_pwd = eventValue.target.value;
    }
  };

getPasswordValidator(): void {
    const client_pk = this.usersService.getClientPK();
    this.confirmPassword = "";
    this.newPassword = "";
    this.oldPassword = "";

    const params = new HttpParams().set('client_pk', client_pk);
    this.mftServices.loadData("password_validator", params).subscribe((response: HttpResponse<any>) => {
      this.data = response.body;
      this.alphabetic_character = this.data.alphabetic_character;
      this.lowercase_character = this.data.lowercase_character;
      this.uppercase_character = this.data.uppercase_character;
      this.number_character = this.data.number_character;
      this.special_character = this.data.special_character;
      this.consecutive_character = this.data.consecutive_character;
      this.min_length_character = this.data.min_length_character;
      this.max_length_character = this.data.max_length_character;
      this.alphabetic_character_isChecked = this.data.alphabetic_character_isChecked;
      this.lower_character_isChecked = this.data.lower_character_isChecked;
      this.upper_character_isChecked = this.data.upper_character_isChecked;
      this.numeric_character_isChecked = this.data.numeric_character_isChecked;
      this.special_character_isChecked = this.data.special_character_isChecked;
      this.consecutive_character_isChecked = this.data.consecutive_character_isChecked;
      this.min_max_isChecked = this.data.min_max_isChecked;

      const requirements = [
        this.data.alphabetic_character_isChecked ? `^(?=(?:[^A-Za-z]*[A-Za-z]){${this.alphabetic_character}})` : '',
        this.data.lower_character_isChecked ? `(?=(?:[^a-z]*[a-z]){${this.lowercase_character}})` : '',
        this.data.upper_character_isChecked ? `(?=(?:[^A-Z]*[A-Z]){${this.uppercase_character}})` : '',
        this.data.numeric_character_isChecked ? `(?=(?:[^0-9]*[0-9]){${this.number_character}})` : '',
        this.data.special_character_isChecked ? `(?=(?:[^@#$%^&+=!]*[@#$%^&+=!]){${this.special_character}})` : '',
        this.data.consecutive_character_isChecked ? `(?!.*([A-Za-z0-9@#$%^&+=!])\\1{${this.consecutive_character}})` : '',
        this.data.min_max_isChecked ? `.{${this.min_length_character},${this.max_length_character}}` : '',
      ];
      this.passwordPattern = requirements.join('');
    });

  }
  openDiv() {
    this.isDivOpen = true;
    this.overlayState = 'in';
  }

  closeDiv() {
    this.isDivOpen = false;
    this.overlayState = 'out';
  }
  openOverlay() {
    this.isOpen = true;
    this.overlay = 'in';
  }

  close() {
    this.isOpen = false;
    this.overlay = 'out';
  }
  logInput(event: Event) {
    const inputValue = (event.target as HTMLInputElement).value;
    console.log('Input Value:', inputValue);
    const alphabeticCharacters = inputValue.split('').filter(char => /[A-Za-z]/.test(char));
    const alphabeticCharacterCount = alphabeticCharacters.length;
    const uppercaseCharacters = inputValue.split('').filter(char => /[A-Z]/.test(char));
    const uppercaseCount = uppercaseCharacters.length;
    const lowercaseCharacters = inputValue.split('').filter(char => /[a-z]/.test(char));
    const lowercaseCount = lowercaseCharacters.length;
    const numericCharacters = inputValue.split('').filter(char => /[0-9]/.test(char));
    const numericCount = numericCharacters.length;
    const specialCharacters = inputValue.split('').filter(char => /[@#$%^&+=!]/.test(char));
    const specialCharacterCount = specialCharacters.length;
    const consecutiveCharacters = inputValue.split('').filter((char, index, array) => {
      return index > 0 && /[A-Za-z]/.test(char) && char === array[index - 1];
    });
    const consecutiveCount = consecutiveCharacters.length + 2;
    const numberconsecutiveCharacters = inputValue.split('').filter((char, index, array) => {
      return index > 0 && /[/\d/]/.test(char) && char === array[index - 1];
    });
    const numberconsecutiveCount = numberconsecutiveCharacters.length + 2;

    const symbolsconsecutiveCharacters = inputValue.split('').filter((char, index, array) => {
      return index > 0 && /[@#$%^&+=!]/.test(char) && char === array[index - 1];
    });
    const symbolconsecutiveCount = symbolsconsecutiveCharacters.length + 2;


    const minMaxCharacters = inputValue.split('');
    const minMaxCount = minMaxCharacters.length;

    if (alphabeticCharacterCount >= this.alphabetic_character) {
      this.radioAlphabeticActivated = true;
    } else {
      this.radioAlphabeticActivated = false;
    }

    if (uppercaseCount >= this.uppercase_character) {
      this.radioUppercaseActivated = true;
    } else {
      this.radioUppercaseActivated = false;
    }

    if (lowercaseCount >= this.lowercase_character) {
      this.radioLowercaseActivated = true;
    } else {
      this.radioLowercaseActivated = false;
    }

    if (numericCount >= this.number_character) {
      this.radioNumericActivated = true;
    } else {
      this.radioNumericActivated = false;
    }

    if (specialCharacterCount >= this.special_character) {
      this.radioSpecialCharactersActivated = true;
    } else {
      this.radioSpecialCharactersActivated = false;
    }
    if (consecutiveCount === 2) {
      this.radioConsecutiveActivated = false;
    }else if (consecutiveCount <= this.consecutive_character) {
      this.radioConsecutiveActivated = true;
    }else if (consecutiveCount > this.consecutive_character) {
      this.radioConsecutiveActivated = false;
    }
    if (numberconsecutiveCount === 2) {
      this.radionumberconsecutiveActivated = false;
    } else if (numberconsecutiveCount <= this.consecutive_character) {
      this.radionumberconsecutiveActivated = true;
    }else if (numberconsecutiveCount > this.consecutive_character) {
      this.radionumberconsecutiveActivated = false;
    }

    if (symbolconsecutiveCount === 2) {
      this.radiosymbolconsecutiveActivated = false;
    } else if (symbolconsecutiveCount <= this.consecutive_character) {
      this.radiosymbolconsecutiveActivated = true;
    }else if (symbolconsecutiveCount > this.consecutive_character) {
      this.radiosymbolconsecutiveActivated = false;
    }

    if (minMaxCount >= this.min_length_character && minMaxCount <= this.max_length_character) {
      this.radioMinMaxActivated = true;
    } else {
      this.radioMinMaxActivated = false;
    }

  }

  newPasswordLog(event: Event){
    const newPassword = (event.target as HTMLInputElement).value;
    const alphabeticCharacters = newPassword.split('').filter(char => /[A-Za-z]/.test(char));
    const alphabeticCharacterCount = alphabeticCharacters.length;
    const uppercaseCharacters = newPassword.split('').filter(char => /[A-Z]/.test(char));
    const uppercaseCount = uppercaseCharacters.length;
    const lowercaseCharacters = newPassword.split('').filter(char => /[a-z]/.test(char));
    const lowercaseCount = lowercaseCharacters.length;
    const numericCharacters = newPassword.split('').filter(char => /[0-9]/.test(char));
    const numericCount = numericCharacters.length;
    const specialCharacters = newPassword.split('').filter(char => /[@#$%^&+=!]/.test(char));
    const specialCharacterCount = specialCharacters.length;
    const consecutiveCharacters = newPassword.split('').filter((char, index, array) => {
      return index > 0 && /[A-Za-z]/.test(char) && char === array[index - 1];
    });
    const consecutiveCount = consecutiveCharacters.length + 2;
    const numberconsecutiveCharacters = newPassword.split('').filter((char, index, array) => {
      return index > 0 && /[/\d/]/.test(char) && char === array[index - 1];
    });
    const numberconsecutiveCount = numberconsecutiveCharacters.length + 2;

    const symbolsconsecutiveCharacters = newPassword.split('').filter((char, index, array) => {
      return index > 0 && /[@#$%^&+=!]/.test(char) && char === array[index - 1];
    });
    const symbolconsecutiveCount = symbolsconsecutiveCharacters.length + 2;
    const minMaxCharacters = newPassword.split('');
    const minMaxCount = minMaxCharacters.length;

    if (alphabeticCharacterCount >= this.alphabetic_character) {
      this.radioAlphabeticActivatednewPas = true;
    } else {
      this.radioAlphabeticActivatednewPas = false;
    }

    if (uppercaseCount >= this.uppercase_character) {
      this.radioUppercaseActivatednewPas = true;
    } else {
      this.radioUppercaseActivatednewPas = false;
    }

    if (lowercaseCount >= this.lowercase_character) {
      this.radioLowercaseActivatednewPas = true;
    } else {
      this.radioLowercaseActivatednewPas = false;
    }

    if (numericCount >= this.number_character) {
      this.radioNumericActivatednewPas = true;
    } else {
      this.radioNumericActivatednewPas = false;
    }

    if (specialCharacterCount >= this.special_character) {
      this.radioSpecialCharactersActivatednewPas = true;
    } else {
      this.radioSpecialCharactersActivatednewPas = false;
    }
    if (consecutiveCount === 2) {
      this.radioConsecutiveActivatednewPas = false;
    } else if (consecutiveCount <= this.consecutive_character) {
      this.radioConsecutiveActivatednewPas = true;
    }else if (consecutiveCount > this.consecutive_character) {
      this.radioConsecutiveActivatednewPas = false;
    }

    if (numberconsecutiveCount === 2) {
      this.radionumberconsecutiveActivatednewPas = false;
    } else if (numberconsecutiveCount <= this.consecutive_character) {
      this.radionumberconsecutiveActivatednewPas = true;
    }else if ( numberconsecutiveCount > this.consecutive_character) {
      this.radionumberconsecutiveActivatednewPas = false;
    }

    if (symbolconsecutiveCount === 2 ) {
      this.radiosymbolconsecutiveActivatednewPas = false;
    }else if (symbolconsecutiveCount <= this.consecutive_character) {
      this.radiosymbolconsecutiveActivatednewPas = true;
    }else if (symbolconsecutiveCount > this.consecutive_character) {
        this.radiosymbolconsecutiveActivatednewPas = false;
    }
    if (minMaxCount >= this.min_length_character && minMaxCount <= this.max_length_character) {
      this.radioMinMaxActivatednewPas = true;
    } else {
      this.radioMinMaxActivatednewPas = false;
    }

  }

  showSubmenu(itemEl: HTMLElement) {
    itemEl.classList.toggle("showMenu");
  }

  isSuccessMessage(): boolean {
    return /(success|successfully|Success|Successfully|SUCCESS|SUCCESSFULLY)/i.test(this.successMessage);
  }

}
