import { Component } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Users } from 'src/app/models/users';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { BaseComponent } from 'src/app/components/base/base.component';
import { SelectionChangedEvent } from 'ag-grid-community';

@Component({
  selector: 'app-mailtemplate',
  templateUrl: './mailtemplate.component.html',
  styleUrls: ['./mailtemplate.component.css']
})
export class MailtemplateComponent extends BaseComponent {

  userData: any;
  selectedFile: File | null = null;
  mailtemplateForm: FormGroup;
  button_disable: boolean = true;
  clientOptions: any[] = [];
  authenticationTypeOptions: any[];
  notificationTypeOptions: any[] = [];
  othernotificationType: string = '';
  templateGridApi: any;
  getExistingTemplates: any;
  templateList: any;
  select_client_pk: number;

  constructor(public override modalService: NgbModal, private mftServices: MftService, private loggedInUser: Users, private formBuilder: FormBuilder) {
    super(modalService);
  }

  public user = { user_pk: '', client_pk: '', search_client_pk: ''}
  public client = { client_pk: '' };
  apiUrl: string;
  templateColumnDefs: any;
  RowData: any;
  AgLoad: boolean = true;
  user_pk: string

  ngOnInit() {
    this.templateColumnDefs = [
      { headerName: 'Mail Template PK', field: 'template_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Mail Template ID', field: 'template_id', sortable: true, filter: true, resizable: true, minWidth: 100, headerCheckboxSelection: true, checkboxSelection: true },
      { headerName: 'Client Name', field: 'select_client_pk', sortable: true, filter: true,  resizable: true, minWidth: 250 },
      { headerName: 'Notification Type', field: 'notification_type', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Header Text', field: 'header_text', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Body Text', field: 'body_text', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Support Mail Text', field: 'support_text', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Regards Text', field: 'regards_text', sortable: true, filter: true, resizable: true, minWidth: 200 },
    ];

    this.mftServices.data$.subscribe((value) => {

      this.userData = this.loggedInUser.getUser();
      this.user_pk = this.loggedInUser.getUser().user_pk;
    });

    this.mailtemplateForm = this.formBuilder.group({

      select_client_name: new FormControl(''),
      template_pk: new FormControl('', []),
      template_id: new FormControl('', []),
      notification_type: new FormControl ('', [Validators.required]),
      header_text: new FormControl ('', [Validators.required]),
      body_text: new FormControl ('', [Validators.required]),
      support_text: new FormControl ('', [Validators.required]),
      regards_text: new FormControl ('', [Validators.required]),
    });

    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();

      if (this.userData.role_id === 'SYS_ADMIN') {
        this.user.search_client_pk = "%";
      } else {
        this.user.search_client_pk = this.userData.client_pk;
      }

      const params = new HttpParams().set('client_pk', this.user.search_client_pk);
      this.mftServices.loadData("active_client_list", params).subscribe(
        (data: HttpResponse<any>) => {
          this.clientOptions = data.body;
          if (this.userData.role_id === 'SYS_ADMIN') {
            this.user.search_client_pk = "%";
          }
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    });
  }

  loadTemplateList() {
    const httpParams = new HttpParams().set('client_pk', (this.user.search_client_pk !== "" && this.user.search_client_pk == "All" ? this.user.search_client_pk : '%'));
    this.mftServices.loadData("template_list", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.templateList = data.body
        this.templateGridApi.setRowData(data.body);
        this.templateGridApi.refreshCells();
        this.edit_disable = true;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  onSelectionChanged(event: SelectionChangedEvent) {
    const selectedData = this.templateGridApi.getSelectedRows();
    this.edit_disable = true;
    if (selectedData.length > 0) {
      this.edit_disable = false;
    }
    else{
      this.edit_disable = true;
    }
  }

  currentEvent: string;
  open(content:any, clickEvent: string) {
    this.submitted = false;
    this.currentEvent = clickEvent;


    if (clickEvent === "NEW") {
      this.mailtemplateForm.patchValue({
        template_pk: 'None', template_id: '', client_name: '', notification_type: '',header_text: '',body_text: '',support_text: '',regards_text: ''});
    }
    if (clickEvent === "EDIT") {
      const selectedData = this.templateGridApi.getSelectedRows();
      this.mailtemplateForm.patchValue({
        template_pk: selectedData[0]["template_pk"], template_id: selectedData[0]["template_id"], client_name: selectedData[0]["select_client_name"], notification_type: selectedData[0]["notification_type"],
        header_text: selectedData[0]["header_text"], body_text: selectedData[0]["body_text"], support_text: selectedData[0]["support_text"], regards_text: selectedData[0]["regards_text"]
       });
    }
    const modalRef = this.modalService.open(content, {backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title'});
    modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

    const httpParams = new HttpParams();
    this.mftServices.loadData("load_active_notification_types", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.othernotificationType.includes(obj.notification_type_pk.toString())) {
            obj.notification_type_status = true;
          } else {
            obj.notification_type_status = false;
          }
        });
        this.notificationTypeOptions = data.body;
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          this.popupModalService.openTimeoutModal();
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
      );
  };

  templateDataBind(params: any) {
    this.templateGridApi = params.api;
    this.loadTemplateList();
  };

  save_template() {
    this.submitted = true;
    if (this.mailtemplateForm.invalid) {
      const invalid = [];
      const controls = this.mailtemplateForm.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
      return;
    }

    const clientOptions = this.clientOptions.filter((item: { client_name: string }) => item.client_name === this.mailtemplateForm.value['select_client_name']);
    clientOptions.forEach((item: { client_pk: number }) => {
      this.select_client_pk = item.client_pk
    });

    const filteredList = this.templateList.filter((item: { client_pk: number;notification_type: string }) => item.client_pk === this.select_client_pk && item.notification_type === this.mailtemplateForm.value['notification_type']);
    if(filteredList.length > 0 && (this.currentEvent === "NEW" || this.currentEvent === "EDIT") ){
      this.mftServices.updatedAlert("Client Name and Notification Type Already Exists");
      return
    }

    var formData: any = new FormData();
    formData.append('template_pk', this.mailtemplateForm.value['template_pk']),
    formData.append('template_id', this.mailtemplateForm.value['template_id']),
    formData.append('client_name', this.mailtemplateForm.value['select_client_name']),
    formData.append('notification_type', this.mailtemplateForm.value['notification_type']),
    formData.append('header_text', this.mailtemplateForm.value['header_text']),
    formData.append('body_text', this.mailtemplateForm.value['body_text']),
    formData.append('support_text', this.mailtemplateForm.value['support_text']),
    formData.append('regards_text', this.mailtemplateForm.value['regards_text']),
    formData.append('client_pk', this.select_client_pk),



    this.mftServices.postData("save_mailtemplate", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.templateGridApi.refreshCells();
        this.modalService.dismissAll('Submit click');
        if (data.body.result === 'SUCCESS') {
          if (this.mailtemplateForm.value['template_pk'] !== "") {
            this.mftServices.updatedAlert("The template details has been saved successfully");
          } else {
            this.mftServices.updatedAlert("The template details has been updated successfully");
          }
        } else {
          this.mftServices.updatedAlert(data.body.data);
        }
        this.loadTemplateList();
      }, (error) => { console.error('There was an error!', error.message); }
    );
  };


}
