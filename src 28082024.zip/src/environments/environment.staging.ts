export const environment = {
    production: false,
    environment: 'STAGING',
    mft_context: '/mft2.0'
};