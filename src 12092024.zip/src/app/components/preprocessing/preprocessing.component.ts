import { Component } from '@angular/core';
import { MftService } from 'src/app/services/mft.service';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BaseComponent } from 'src/app/components/base/base.component';
import { Users } from 'src/app/models/users';
import Papa from 'papaparse';
import { FileElement } from 'src/app/file-manager/model/element';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-preprocessing',
  templateUrl: './preprocessing.component.html',
  styleUrls: ['./preprocessing.component.css']
})
export class PreprocessingComponent extends BaseComponent{

  formulaForm: any;
  userData: any;
  user_pk: any;
  clientData: any;
  client_pk: any;
  public user = { user_pk: '', client_pk: '', search_client_pk: ''}
  public client = { client_pk: '' };
  activeformulas: any;
  formulaOptions: any[] = [];
  otherformula: string = '';
  item: string;
  headers: any;
  currentFolderItems: any[] = [];
  navigationStack: string[] = [];
  forwardStack: string[] = [];
  currentParentId: string = 'root';
  fileName: any;
  mimeType: any;
  fileContent: string;
  folderData: FileElement[] = []
  dropdown1Items: string[] = [];
  filteredDropdown1Items = [...this.dropdown1Items];
  activeDropdown: string | null = null;
  title: string = '';
  isEditing: boolean = false;
  originalTitle: string = '';
  content: string = '';
  isDarkMode: boolean = false;
  selectedSyntax: string;
  selectedDescription: string;
  cursorPosition: number = 0;
  isPreviewMode: boolean = false;
  formulaNameList: any[];

  constructor(public override modalService: NgbModal, private mftServices: MftService, private loggedInUser: Users, private formBuilder: FormBuilder) {
    super(modalService);
  }

  ngOnInit() {
    this.formulaForm = this.formBuilder.group({
      c_logic_pk: ['', []],
      formula_name: [],
      formula_content: ['', []],
      client_pk: ['', []],
      user_pk: ['', []],
      created_date: ['', []],
      modified_date: ['', []],
      c_logic_status: ['', []],
    });

    this.mftServices.data$.subscribe((value) => {
      this.loadActiveFormula();
      this.loadsavedformulas();
      this.loadFolder();
      this.loadDataSets();
    });

  }

  formulas: { name: string; content: string; selected: boolean }[] = [];
  selectedFormulaForEditing: { name: string; content: string } | null = null;



  toggleDropdown(dropdown: string): void {
    this.activeDropdown = this.activeDropdown === dropdown ? null : dropdown;
  }

  filterItems(event: Event, dropdown: string): void {
    const input = event.target as HTMLInputElement;
    const query = input.value.toLowerCase(); // Get the value from the input event

    if (dropdown === 'dropdown2') {
      if (query) {
        this.formulaNameList = this.formulaOptions.filter(formula =>
          formula.Formula_name.toLowerCase().includes(query)
        );
      } else {
        this.formulaNameList = [...this.formulaOptions];
      }
    }
    console.log('FilteredValues:', this.formulaNameList);

  }


  startEditing() {
    if (!this.isPreviewMode) {
      this.isEditing = true;
      this.originalTitle = this.title;
    }
  }

  saveTitle() {
    this.isEditing = false;
    // if (!this.title.trim()) {
    //   this.title = 'Enter Your Formula Name';
    // }
  }

  preventClose(event: Event): void {
    event.stopPropagation();
  }

  onInput(event: Event): void {
    const target = event.target as HTMLTextAreaElement;
    this.content = target.value;
  }

  toggleTheme(): void {
    this.isDarkMode = !this.isDarkMode;
  }

  saveCursorPosition(event: any): void {
    this.cursorPosition = event.target.selectionStart;
  }

  insertTextAtCursor(text: string): void {
    if (this.cursorPosition !== undefined && this.cursorPosition !== null) {
      const beforeCursor = this.content.substring(0, this.cursorPosition);
      const afterCursor = this.content.substring(this.cursorPosition);
      this.content = beforeCursor + text + afterCursor;
      this.cursorPosition += text.length;
    }
  }

  handleFormulaClick(formula: any, event: Event): void{
      // Prevent the dropdown from closing if that's the issue
    this.preventClose(event);

    // Pass the formula's name to passSyntax
    this.passSyntax(formula.Formula_name);

    // Pass the formula's JSON representation to passJsonFormula
    this.passJsonFormula(formula.Formula_pk);
  }

  passColumn(selectedColumn: string) {
    this.insertTextAtCursor(selectedColumn);
  }

  passSyntax(selectedFormulaName: string) {
    const formulaItem = this.formulaOptions.find(item => item.Formula_name === selectedFormulaName);
    if (formulaItem) {
      this.selectedSyntax = formulaItem.Syntax;
      this.selectedDescription = formulaItem.Description;
    } else {
      console.error('Formula not found:', selectedFormulaName);
    }
  }
  passJsonFormula(selectedJsonFormula: string) {
    const formulaJsonItem = this.formulaOptions.find(item => item.Formula_pk === selectedJsonFormula);
    if (formulaJsonItem) {
      this.insertTextAtCursor(formulaJsonItem.JsonFormula + ',\n');
    }
  }

  selectAll(event: Event) {
    const checked = (event.target as HTMLInputElement).checked;
    this.formulas.forEach(formula => (formula.selected = checked));
  }

  viewFormula(formula: { name: string }) {
    console.log('View formula:', formula.name);
  }

  previewFormula(formula: { formula_name: any; formula_content: string; }) {
    this.title = formula.formula_name;
    this.content = formula.formula_content;
    this.isEditing = false;
    this.isPreviewMode = true;
  }

  editFormula(formula: { formula_name: any; formula_content: string; c_logic_pk: string; created_date: string; modified_date: string; c_logic_status: string }) {
    this.selectedFormulaForEditing = { name: formula.formula_name, content: formula.formula_content };
    this.title = formula.formula_name;
    this.content = formula.formula_content;
    this.formulaForm.patchValue({
      formula_name: formula.formula_name,
      formula_content: formula.formula_content,
      c_logic_pk: formula.c_logic_pk,
      created_date: formula.created_date,
      modified_date: formula.modified_date,
      c_logic_status: formula.c_logic_status
    });
    this.isEditing = true;
    this.isPreviewMode = false;
  }

  deleteFormula(formula: { formula_name: any; formula_content: string; c_logic_pk: string; created_date: string; modified_date: string; c_logic_status: string },title:string){
    if (confirm(`Are you sure you want to "${title}"?`)) {
      const client_pk = this.mftService.loggedInUser.getUser().client_pk;
      const formData:any = new FormData();
      formData.append('c_logic_status', title);
      formData.append('c_logic_pk', formula.c_logic_pk);
      formData.append('client_pk', client_pk);
      this.mftService.postData("formula_status",formData).subscribe(
        (response: HttpResponse<any>) => {
          const firstElement = response.body[0];
          if (firstElement && firstElement.message === 'SUCCESS') {
            this.mftService.updatedAlert("The role status updated successfully");
          } else {
            if (firstElement.status === 'FAILURE' && firstElement.data !== '') {
              this.mftService.updatedAlert(firstElement.data);
            } else {
              this.mftService.updatedAlert("Failed to update the status");
            }
          }
          this.ngOnInit();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }

  }

  loadActiveFormula(): void {
    const httpParams = new HttpParams();
    this.mftService.loadData("load_active_formula", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.otherformula.includes(obj.Formula_pk.toString())) {
            obj.Formula_status = true;
          } else {
            obj.Formula_status = false;
          }
        });
        this.formulaOptions = data.body;
        this.formulaNameList = [...this.formulaOptions];
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          console.error('Popup model', httpError.message);
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
      );
  }

  saveFormula() {
    this.submitted = true;
    const formulaName = this.formulaForm.value['formula_name'];
    const formulaContent = this.formulaForm.value['formula_content'];
    const c_logic_pk = this.formulaForm.value['c_logic_pk'];
    const createdDate = this.formulaForm.value['created_date'] || '';
    const modifiedDate = this.formulaForm.value['modified_date'] || '';
    const c_logicStatus = this.formulaForm.value['c_logic_status'] || '';

    if (formulaName === '' ) {
      alert('Formula name cannot be empty or default. Please provide a valid formula name.');
      return;
    }

    if (formulaContent.trim() === '') {
      alert('Formula space cannot be empty. Please enter valid formula content.');
      return;
    }

    if (!c_logic_pk) {
      const isDuplicate = this.formulas.some(f => f.name === formulaName);
      if (isDuplicate) {
        alert('A formula with this name already exists. Please choose a different name.');
        return;
      }
    }

    const formData: any = new FormData();
    formData.append('c_logic_pk', c_logic_pk || '');
    formData.append('formula_name', formulaName);
    formData.append('formula_content', formulaContent);
    formData.append('client_pk', this.mftServices.loggedInUser.getUser().client_pk);
    formData.append('user_pk', this.mftServices.loggedInUser.getUser().user_pk);
    formData.append('created_date', createdDate);
    formData.append('modified_date', modifiedDate);
    formData.append('c_logic_status', c_logicStatus);

    console.log('Form Data:', {
      c_logic_pk: c_logic_pk,
      formula_name: formulaName,
      formula_content: formulaContent,
      client_pk: this.mftServices.loggedInUser.getUser().client_pk,
      user_pk: this.mftServices.loggedInUser.getUser().user_pk,
      created_date: createdDate,
      modified_date: modifiedDate,
      c_logic_status: c_logicStatus
    });

    this.mftServices.postData("save_conditional_logic", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.modalService.dismissAll('Submit click');
        if (data.body.result === 'SUCCESS') {
          if (c_logic_pk) {
            this.mftServices.updatedAlert("The formula has been updated successfully");
          } else {
            this.mftServices.updatedAlert("The formula has been Saved successfully");
          }
          this.loadsavedformulas();
          this.cancelFormula();
        } else {
          this.mftServices.updatedAlert(data.body.data);
        }
      }, (error) => { console.error('There was an error!', error.message); }
    );
  }

  loadsavedformulas() {
    if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    }
    else if(this.mftService.loggedInUser.getUser().role_id === 'ORG_ADMIN' || 'PROJECT_LEAD'){
      this.user.search_client_pk = this.mftService.loggedInUser.getUser().client_pk;
    }
    else{
      this.user.user_pk = this.mftService.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams().set('client_pk', this.user.search_client_pk).set('user_pk', this.user.user_pk);
    this.mftServices.loadData("get_conditional_logic_list",params).subscribe(
      (data: HttpResponse<any>) => {
        this.activeformulas = data.body
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };


  cancelFormula() {
    this.title = '';
    this.content = '';
    this.isEditing = false;
    this.isPreviewMode = false;
    this.selectedFormulaForEditing = null;
  }

  modifyStatusRole(rolePk: any, title:string) {
    if (confirm(`Are you sure you want to "${title}"?`)) {
      const client_pk = this.mftService.loggedInUser.getUser().client_pk;
      const formData:any = new FormData();
      formData.append('role_status', title);
      formData.append('role_pk', rolePk);
      formData.append('client_pk', client_pk);
      this.mftService.postData("role_status",formData).subscribe(
        (response: HttpResponse<any>) => {
          const firstElement = response.body[0];
          if (firstElement && firstElement.message === 'SUCCESS') {
            this.mftService.updatedAlert("The role status updated successfully");
          } else {
            if (firstElement.status === 'FAILURE' && firstElement.data !== '') {
              this.mftService.updatedAlert(firstElement.data);
            } else {
              this.mftService.updatedAlert("Failed to update the status");
            }
          }
          this.ngOnInit();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
  }

  async loadFolder(): Promise<void>{
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    } else if (this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || this.mftServices.loggedInUser.getUser().role_id === 'PROJECT_LEAD') {
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    } else {
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }

    const params = new HttpParams()
      .set('client_pk', this.user.search_client_pk)
      .set('user_pk', this.user.user_pk);

    this.mftServices.loadData("get_wizard_list", params).subscribe(
      (data: HttpResponse<any>) => {
        this.folderData = data.body;
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:',httpError);

      }
    );
  }

  loadDataSets() {
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    }
    else if(this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || 'PROJECT_LEAD'){
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    }
    else{
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams().set('client_pk',this.user.search_client_pk).set('user_pk',this.user.user_pk);
    this.mftServices.loadData("load_datasets", params).subscribe(
      (data: HttpResponse<any>) => {
        if(!data.body.error){
          this.folderData = [...this.folderData, ...data.body];
        }
        this.loadCurrentFolderItems();
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:',httpError);

      }
    );
  }


  loadCurrentFolderItems(): void {
    this.currentFolderItems = this.folderData.filter((item: any) => item.parent_id === this.currentParentId);
  }

  openItem(item: any): void {
    if (item.isFolder) {
      this.navigationStack.push(this.currentParentId);
      this.currentParentId = item.wizard_id;
      this.forwardStack = [];
      this.loadCurrentFolderItems();
    } else {
      // Handle file opening logic
      if (item.mimetype) {
        this.fileName = item.folder_name ?? '';
        this.mimeType = item.mimetype ?? '';
        this.fileContent = atob(item.content || '');

        if (this.mimeType === 'application/json') {
          this.displayJson();
        } else if (this.mimeType === 'text/csv' || this.mimeType === 'text/tab-separated-values') {
          this.displayCsv();
        } else if (this.mimeType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
          this.displayXlsx();
        } else {
          console.error('Unsupported file type');
        }
      }
    }
  }


  displayXlsx(): void {
    try {
      // Parse the fileContent as a binary string for XLSX
      const workbook = XLSX.read(this.fileContent, { type: 'binary' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      this.headers = jsonData[0]; // Extract headers from the first row
      // Optionally, you can process or display the data further
    } catch (error) {
      console.error('Error processing XLSX file:', error);
    }
  }



  displayJson(): void {
    try {
      const jsonData = JSON.parse(this.fileContent);
      if (jsonData.length > 0) {
        this.headers = Object.keys(jsonData[0]);
  }
    } catch (e) {
      console.error('Failed to parse JSON', e);
    }
    console.log('Json',this.headers);
  }

  displayCsv(): void {
    Papa.parse(this.fileContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        this.headers = results.meta.fields;
  },
      error: (error: any) => {
        console.error('Error parsing CSV', error);
      }
    });
    console.log('csv/xlsx',this.headers);
  }

  goBack(): void {
    if (this.navigationStack.length > 0) {
      this.forwardStack.push(this.currentParentId);
      this.currentParentId = this.navigationStack.pop()!;
      this.loadCurrentFolderItems();
    }
  }

  goForward(): void {
    if (this.forwardStack.length > 0) {
      this.navigationStack.push(this.currentParentId);
      this.currentParentId = this.forwardStack.pop()!;
      this.loadCurrentFolderItems();
    }
  }
  // text editor single click to select word

 selectWord(event: MouseEvent): void {
    event.preventDefault();
    const textarea = event.target as HTMLTextAreaElement;
    const cursorPosition = textarea.selectionStart;
    const text = textarea.value;

    // Regex to match specific parts for yellow highlight (e.g., Your_Column_Name and words inside parentheses)
    const regex = /Your_Column_Name|\b(?:[a-z][a-z0-9_]*)\b(?=\s*(,|\))|\s*\()/gi;

    let match;
    let found = false;
    let start = 0;
    let end = 0;

    while ((match = regex.exec(text)) !== null) {
        start = match.index;
        end = regex.lastIndex;

        // Ensure we're not selecting capitalized method names
        if (!/^[A-Z][A-Z0-9_]*$/.test(text.slice(start, end))) {
            if (cursorPosition >= start && cursorPosition <= end) {
                textarea.setSelectionRange(start, end);
                found = true;
                break;
            }
        }
    }

    if (found) {
        // Apply a custom class to highlight the selection
        textarea.classList.add('highlight-selection');
        // Use a timeout to ensure the class is applied after the selection is made
        setTimeout(() => {
            textarea.setSelectionRange(start, end);
        }, 10);
    } else {
        // Remove custom highlighting if the selection doesn't match
        textarea.classList.remove('highlight-selection');
    }
}

}
