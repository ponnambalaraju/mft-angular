import { HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as Papa from 'papaparse';
import { Users } from 'src/app/models/users';
import { MftService } from 'src/app/services/mft.service';
import * as XLSX from 'xlsx';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FileElement } from './../../file-manager/model/element';
import { WizardComponent } from '../wizard/wizard.component';

@Component({
  selector: 'app-file-viewer',
  templateUrl: './file-viewer.component.html',
  styleUrls: ['./file-viewer.component.css']
})
export class FileViewerComponent implements OnInit {
  fileData: any[][] = []; // 2D array to hold the file data
  isLoading = false;
  fileElement: FileElement;
  fileName: string = '';
  mimeType: string = '';
  fileContent: string = '';
  parsedData: any[] = [];
  headers: string[];
  columnTypes: { [key: string]: string; };
  rows: any[][];
  dataTypes: string[] = ['string', 'int', 'float', 'date', 'datetime', 'time'];
  showDataTypeList: boolean[] = [];
  modifydatatype_content: string = '';
  selectedFormat: string = '';

  formats: { [key: string]: string[] } = {

    date: ['DD/MM/YYYY','MM/DD/YYYY','YYYY/MM/DD','YYYY/DD/MM','DD-MM-YYYY','MM-DD-YYYY','YYYY-MM-DD','YYYY-DD-MM','DD/Month/YYYY','Month/DD/YYYY','YYYY/Month/DD','YYYY/DD/Month'],
    datetime: ['YYYY-MM-DDTHH:mm:ss', 'MM/DD/YYYY HH:mm', 'DD-MM-YYYY HH:mm','YYYY/MM/DD HH:mm', 'YYYY-MM-DD HH:mm'],
    time: ['HH:mm', 'hh:mm a', 'HH:mm:ss', 'hh:mm:ss a', 'HH:mm:ss SSS','hh:mm:ss SSS a']
  };

  showFormatDialog: boolean = false;
  selectedDataType: string = '';
  dateTimeFormat: string = '';
  selectedDataHeader: any;


  constructor(private router: Router, private loggedInUser: Users, private mftServices: MftService, private sanitizer: DomSanitizer, private fileManager: WizardComponent) {}

  ngOnInit(): void {
    this.fileElement = history.state.fileElement;
    if (!this.fileElement) {
      this.router.navigate(['/etl/wizard']);
      return;
    }

      this.fileName = this.fileElement.folder_name ?? '';
      this.mimeType = this.fileElement.mimetype ?? '';
      this.fileContent = atob(this.fileElement.content || '');

      this.extractFileContent(this.mimeType, this.fileContent);
  }

  get formatOptions(): string[] {
    return this.formats[this.selectedDataType] || [];
  }

  closeDialog(): void {
    this.showFormatDialog = false;
  }

  onDataTypeClick(header: string, type: string): void {

    if (['date', 'datetime', 'time'].includes(type)) {
      this.selectedDataType = type;
      this.showFormatDialog = true;
      this.selectedDataHeader = header;
    } else {
      this.dateTimeFormat = "";
      this.selectDataType(header, type);
    }

  }

  selectFormat(format: string): void {
    this.dateTimeFormat = format
  }

  applyFormatToColumn(dataType: string, format: string): void {
    console.log(`Applying ${format} format to ${dataType} column`);
  }

  extractFileContent(fileType: string, fileContent: string) {
    this.isLoading = true;

    if (fileType === 'application/json') {
      this.displayJson(fileContent);
    } else if (fileType === 'text/csv' || fileType === 'text/tab-separated-values') {
      this.displayCsvOrTsv(fileType, fileContent);
    } else if (fileType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
      this.displayXlsx(fileContent);
    } else {
      console.error('Unsupported file type');
      this.isLoading = false;
    }
  }

  // Display JSON content
  displayJson(fileContent: string) {
    try {
      const jsonObject = JSON.parse(fileContent);
      this.fileData = this.parseJsonToArray(jsonObject);
      this.ensureUniformRowLengths();
    } catch (e) {
      console.error('Error parsing JSON:', e);
      this.fileData = [];
    }
    this.isLoading = false;
  }

  // Display CSV or TSV content
  displayCsvOrTsv(fileType: string, fileContent: string) {
    Papa.parse(fileContent, {
      delimiter: fileType === 'text/tab-separated-values' ? '\t' : ',', // '\t' for TSV, ',' for CSV
      header: false, // No headers
      skipEmptyLines: false, // Don't skip empty lines
      complete: (result: any) => {
        this.fileData = result.data;
        this.ensureUniformRowLengths();
        this.isLoading = false;
      },
      error: (error: any) => {
        console.error('Error parsing CSV/TSV:', error);
        this.fileData = [];
        this.isLoading = false;
      }
    });
  }

  // Display XLSX content
  displayXlsx(fileContent: string) {
    try {
      const workbook = XLSX.read(fileContent, { type: 'binary' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      this.fileData = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true }); // No headers
      this.ensureUniformRowLengths();
    } catch (e) {
      console.error('Error parsing XLSX:', e);
      this.fileData = [];
    }
    this.isLoading = false;
  }

  // Convert JSON object to a 2D array for table display
  parseJsonToArray(jsonObject: any): any[][] {
    const result: any[][] = [];
    for (const key in jsonObject) {
      if (jsonObject.hasOwnProperty(key)) {
        const value = jsonObject[key];
        result.push([key, value]); // Each key-value pair as a row
      }
    }
    return result;
  }

  // Ensure all rows have the same number of cells by padding with null
  private ensureUniformRowLengths() {
    if (!this.fileData || !this.fileData.length) return;

    const maxLength = Math.max(...this.fileData.map(row => row.length));
    this.fileData = this.fileData.map(row => {
      while (row.length < maxLength) {
        row.push(null); // Pad with null to maintain table structure
      }
      return row;
    });
  }

  // Method to safely render cell content, replacing empty cells with &nbsp;
  getCellContent(cell: any): SafeHtml {
    if (cell !== undefined && cell !== null && cell !== '') {
      return cell;
    } else {
      return this.sanitizer.bypassSecurityTrustHtml('&nbsp;');
    }
  }


  updateFormat(): void {
    if (!this.selectedFormat || !this.selectedDataType) {
      console.error('No format or data type selected');
      return;
    }
    this.closeDialog();
    this.selectDataType(this.selectedDataHeader,this.selectedDataType);
  }

  toggleDataTypeList(index: number): void {
    this.showDataTypeList = this.showDataTypeList.map((val, i) => i === index ? !val : false);
  }

  saveFile() {
    // Ensure `modifydatatype_content` or `fileElement.content` is not undefined
    const content = this.modifydatatype_content && this.modifydatatype_content.trim() !== ''
      ? this.modifydatatype_content
      : this.fileElement.content || '';

    let file: File;

    const fileName = this.fileElement.folder_name ?? '';
    const mimeType = this.fileElement.mimetype ?? '';

    console.log(`File name: ${fileName}`);
    console.log(`MIME type: ${mimeType}`);

    switch (true) {
      case mimeType.includes('csv') || mimeType.includes('text/csv'):
        file = this.createFileFromContent(atob(content), mimeType, fileName);
        break;
      case mimeType.includes('text/tab-separated-values') || mimeType.includes('tsv'):
        file = this.createFileFromContent(atob(content), mimeType, fileName);
        break;
      case mimeType.includes('application/json') || mimeType.includes('json'):
        file = this.createFileFromContent(atob(content), mimeType, fileName);
        break;
      case mimeType.includes('sheet') || mimeType.includes('excel'):
        const worksheet = XLSX.utils.aoa_to_sheet(this.parseCSVToArray(atob(content)));
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
        const xlsxContent = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        file = this.createFileFromContent(new Uint8Array(xlsxContent), mimeType, fileName);
        break;
      default:
        throw new Error('Unsupported file format');
    }

    console.log(file);
    const formData: any = new FormData();

    formData.append('file', file);
    formData.append('dataset_pk', this.fileElement.dataset_pk);
    formData.append('mdfy_file_name', this.fileElement.folder_name);
    formData.append('mdfy_file_size', this.fileElement.file_size);
    formData.append('mdfy_file_type', this.fileElement.file_type);
    formData.append('workflow_modify_by', this.loggedInUser.getUser().user_pk);
    formData.append('modified_at', '');
    formData.append('extr_table_createby', this.loggedInUser.getUser().user_pk);
    formData.append('client_pk', this.fileElement.client_pk);
    formData.append('user_pk', this.loggedInUser.getUser().user_pk);

    this.mftServices.postData("update_datasets", formData).subscribe(
      (response: HttpResponse<any>) => {
        console.log('Response:', response);
        const firstElement = response.body;
        if (firstElement.message === 'SUCCESS') {
          this.mftServices.updatedAlert("The file updated successfully");
        } else {
          this.mftServices.updatedAlert("Failed to updated file");
        }
      },
      error => {
        console.error('Error:', error);
        this.mftServices.updatedAlert("An error occurred while updating the column data type");
      }
    );
  }



  createFileFromContent(content: string | Uint8Array, mimeType: string, fileName: string): File {
    const blob = new Blob([content], { type: mimeType });
    return new File([blob], fileName, { type: mimeType });
  }

  parseCSVToArray(content: string): any[][] {
    return content.split('\n').map(row => row.split(','));
  }

  downloadFile(): void {
    const fileName = this.fileName;
    const mimeType = this.mimeType;
    const content = this.modifydatatype_content && this.modifydatatype_content.trim() !== ''
      ? this.modifydatatype_content
      : this.fileElement.content || '';

    let fileContent;
    let extension;

    const decodedContent = atob(content);

    switch (mimeType) {
      case 'text/csv':
        fileContent = decodedContent;
        extension = 'csv';
        break;
      case 'text/tsv':
        fileContent = this.convertCsvToTsv(decodedContent);
        extension = 'tsv';
        break;
      case 'application/json':
        fileContent = JSON.stringify(JSON.parse(decodedContent), null, 2);
        extension = 'json';
        break;
      case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
      case 'application/vnd.ms-excel':
        extension = 'xlsx';
        fileContent = this.convertToExcel(decodedContent);
        break;
      default:
        console.error('Unsupported MIME type');
        return;
    }

    const blob = new Blob([fileContent], { type: mimeType });
    const url = window.URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName}.${extension}`;

    document.body.appendChild(a);

    a.click();

    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }

  convertCsvToTsv(csv: string): string {
    return csv.replace(/,/g, '\t');
  }

  convertToExcel(csv: string): any {
    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.aoa_to_sheet(csv.split('\n').map(row => row.split(',')));
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

    const wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
    return XLSX.write(workbook, wopts);
  }

  selectDataType(header: string,type: string ): void {
    const content = this.modifydatatype_content && this.modifydatatype_content.trim() !== '' ? this.modifydatatype_content : this.fileElement.content;

    const oldType = this.columnTypes[header];
    console.log(`Old type: ${oldType}, New type: ${type} for header: ${header}`);

    this.columnTypes[header] = header;
    console.log('Updated columnTypes:', this.columnTypes);

    this.showDataTypeList.fill(false);
    console.log('Dropdowns closed:', this.showDataTypeList);

    const formData: any = new FormData();
    formData.append('fileName', this.fileName);
    formData.append('mimeType', this.mimeType);
    formData.append('fileContent', content);
    formData.append('oldDataType', oldType);
    formData.append('newDataType', type);
    formData.append('columnName', header);
    formData.append('SelectedPopupName', this.dateTimeFormat);

    this.mftServices.postData("update_datatypes", formData).subscribe(
      (response: HttpResponse<any>) => {
        console.log('Response:', response);
        const firstElement = response.body;
        if (firstElement.message === 'SUCCESS') {
          this.modifydatatype_content = firstElement.data;
          this.mimeType = firstElement.mimeType;
          this.extractFileContent(this.mimeType, atob(firstElement.data || ''));
          this.mftServices.updatedAlert("The column data type updated successfully");
        } else {
          this.mftServices.updatedAlert(firstElement.data || "Failed to update the column data type");
        }
      },
      error => {
        console.error('Error:', error);
        this.mftServices.updatedAlert("An error occurred while updating the column data type");
      }
    );
  }

  getIconClass(type: string): string {
    switch(type) {
      case 'string': return 'fa-solid fa-font';
      case 'int': return 'fa-solid fa-hashtag';
      case 'float': return 'fa-solid fa-percent';
      case 'date': return 'fa-solid fa-calendar';
      case 'datetime': return 'fa-solid fa-clock';
      case 'time': return 'fa-solid fa-hourglass';
      default: return '';
    }
  }

  // displayJson(fileContent: string): void {
  //   try {
  //     const jsonData = JSON.parse(fileContent);
  //     this.parsedData = Array.isArray(jsonData) ? jsonData : [jsonData];
  //     this.inferDataTypes();
  //   } catch (error) {
  //     console.error('Error parsing JSON file:', error);
  //     this.mftServices.updatedAlert("Failed to parse JSON file");
  //   } finally {
  //     this.isLoading = false;
  //   }
  // }


  // displayCsvOrTsv(fileType: string, fileContent: string): void {
  //   Papa.parse(fileContent, {
  //     delimiter: fileType === 'text/tab-separated-values' ? '\t' : ',',
  //     header: true,
  //     complete: (result) => {
  //       this.parsedData = result.data;
  //       this.inferDataTypes();
  //       this.isLoading = false;
  //     },
  //     error: (error: any) => {
  //       console.error('Error parsing CSV/TSV file:', error);
  //       this.isLoading = false;
  //     }
  //   });
  // }

  // displayXlsx(fileContent: string): void {
  //   try {
  //     const workbook = XLSX.read(fileContent, { type: 'binary' });
  //     const firstSheetName = workbook.SheetNames[0];
  //     const worksheet = workbook.Sheets[firstSheetName];
  //     const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

  //     this.parsedData = this.convertXlsxToJson(jsonData);
  //     this.inferDataTypes();
  //   } catch (error) {
  //     console.error('Error processing XLSX file:', error);
  //   } finally {
  //     this.isLoading = false;
  //   }
  // }

  // convertXlsxToJson(sheetData: any[]): any[] {
  //   const headers = sheetData[0];
  //   const rows = sheetData.slice(1);
  //   return rows.map(row => {
  //     const obj: any = {};
  //     row.forEach((cell: any, index: number) => {
  //       obj[headers[index]] = cell;
  //     });
  //     return obj;
  //   });
  // }

  inferDataTypes(): void {
    if (this.parsedData.length === 0) {
        console.log('No data available to infer types.');
        return;
    }

    this.headers = Object.keys(this.parsedData[0]);
    console.log('Columns Header:', this.headers);

    const columnTypes: { [key: string]: string } = {};

    const filteredData = this.parsedData.filter(row => {
        return this.headers.some(header => row[header] !== undefined && row[header] !== '');
    });

    this.headers.forEach(col => {
        const columnValues = filteredData.map(row => row[col]);
        console.log(`Column Values for "${col}":`, columnValues);
        columnTypes[col] = this.determineColumnType(columnValues);
    });

    this.columnTypes = columnTypes;
    this.rows = filteredData.map(row => this.headers.map(header => row[header] !== undefined ? row[header] : ''));

    console.log('Column Data Types:', this.columnTypes);
}

determineColumnType(values: any[]): string {
  const typeCounts: { [key: string]: number } = {
    int: 0,
    float: 0,
    date: 0,
    datetime: 0,
    time: 0,
    string: 0
  };

  values.forEach(value => {
    if (this.isInteger(value)) {
      typeCounts['int']++;
    } else if (this.isFloat(value)) {
      typeCounts['float']++;
    } else if (this.isDate(value)) {
      typeCounts['date']++;
    } else if (this.isDatetime(value)) {
      typeCounts['datetime']++;
    } else if (this.isTime(value)) {
      typeCounts['time']++;
    } else {
      typeCounts['string']++;
    }
  });

  return Object.keys(typeCounts).reduce((a, b) => typeCounts[a] > typeCounts[b] ? a : b);
  }

  isInteger(value: any): boolean {
    return !isNaN(value) && Number.isInteger(parseFloat(value));
  }

  isFloat(value: any): boolean {
    return !isNaN(value) && !Number.isInteger(parseFloat(value));
  }

  isDate(value: any): boolean {
    return !isNaN(Date.parse(value)) && value.length === 10;
  }

  isDatetime(value: any): boolean {
    return !isNaN(Date.parse(value)) && value.includes('T');
  }

  isTime(value: any): boolean {
    return /^\d{2}:\d{2}(:\d{2})?$/.test(value);
  }

  inferDataType(value: any): string {
    if (value === null || value === undefined) return 'null';

    const trimmedValue = value.toString().trim();

    if (/^-?\d+$/.test(trimmedValue)) {
      return 'int';
    }

    if (/^-?\d*\.?\d+$/.test(trimmedValue)) {
      return 'float';
    }

    const date = Date.parse(trimmedValue);
    if (!isNaN(date) && !/\d{2}:\d{2}(:\d{2})?$/.test(trimmedValue)) {
        return 'date';
    }
    return 'string';
  }
  navigate() {
    console.log('Navigating to /etl/wizard');
    this.router.navigate(['/etl/wizard']).then(() => {
      console.log('Navigation complete');
      setTimeout(() => {
        console.log('Calling activeOpenFolder');
        this.fileManager.activeOpenFolder(this.fileElement);
      }, 100);
    }).catch(error => {
      console.error('Navigation error:', error);
    });
  }

  getExample(format: string): string {
    switch (format) {
      case 'DD/MM/YYYY':
        return '31/12/2024';
      case 'MM/DD/YYYY':
        return '12/31/2024';
      case 'YYYY/MM/DD':
        return '2024/12/31';
      case 'YYYY/DD/MM':
        return '2024/31/12';

	    case 'DD-MM-YYYY':
        return '31-12-2024';
      case 'MM-DD-YYYY':
        return '12-31-2024';
      case 'YYYY-MM-DD':
        return '2024-12-31';
      case 'YYYY-DD-MM':
        return '2024-31-12';

	    case 'DD/Month/YYYY':
        return '31/December/2024';
      case 'Month/DD/YYYY':
        return 'December/31/2024';
      case 'YYYY/Month/DD':
        return '2024/December/31';
      case 'YYYY/DD/Month':
        return '2024/31/December';

      case 'YYYY-MM-DDTHH:mm:ss':
        return '2024-08-30T14:45:00';
      case 'MM/DD/YYYY HH:mm':
        return '08/30/2024 14:45:00';
      case 'DD-MM-YYYY HH:mm':
        return '30-08-2024 14:45:00';
      case 'YYYY/MM/DD HH:mm':
        return '2024/08/30 14:45:00';
      case 'YYYY-MM-DD HH:mm':
        return '2024-08-30 14:45:00';

      case 'HH:mm':
        return '14:30';
      case 'hh:mm a':
        return '02:30 PM';
      case 'HH:mm:ss':
        return '14:30:45';
      case 'hh:mm:ss a':
        return '02:30:45 PM';

      case 'HH:mm:ss SSS':
        return '14:30:45 123';
      case 'hh:mm:ss SSS a':
        return '02:30:45 123 PM';
      default:
        return 'No example available';
    }
  }


  editableName: string = '';
  isEditing: boolean = false;

  get displayName(): string {
    const name = this.fileName.substring(0, this.fileName.lastIndexOf('.'));
    const extension = this.fileName.substring(this.fileName.lastIndexOf('.'));
    return `${name}${extension}`;
  }

  editFileName(): void {
    this.editableName = this.fileName.substring(0, this.fileName.lastIndexOf('.'));
    this.isEditing = true;
  }

  saveFileName(): void {
    const extension = this.fileName.substring(this.fileName.lastIndexOf('.'));
    const oldFileName = this.fileName;
    this.fileName = `${this.editableName}${extension}`;
    this.isEditing = false;

    console.log(`Old file name: ${oldFileName}`);
    console.log(`New file name: ${this.fileName}`);
  }


}
