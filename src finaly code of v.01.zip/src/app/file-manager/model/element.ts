export interface FileElement {
  wizard_pk: string;
  client_pk: string;
  user_pk: string;
  parent_id?: string;
  wizard_id?: string;
  isFolder: boolean;
  folder_name: string;
  wizard_create_at: string;
  created_at?: string;
  dataset_pk?: string;
  datasets_status?: string;
  extr_table_createat?: string;
  extr_table_createby?: string;
  extr_table_modifyat?: string;
  extr_table_name?: string;
  file_size?: string;
  file_type?: string;
  mdfy_file_name?: string;
  mdfy_file_size?: string;
  mdfy_file_type?: string;
  modify_at?: string;
  temp_table_createat?: string;
  temp_table_createby?: string;
  temp_table_name?: string;
  wizard_modify_at?: string;
  content?: string;
  mimetype?: string;
}

