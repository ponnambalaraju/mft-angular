import { StripambersendPipe } from './stripambersend.pipe';

describe('StripambersendPipe', () => {
  it('create an instance', () => {
    const pipe = new StripambersendPipe();
    expect(pipe).toBeTruthy();
  });
});
