import { Component } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { MftService } from 'src/app/services/mft.service';

@Component({
  selector: 'app-passwordreset',
  templateUrl: './passwordreset.component.html',
  styleUrls: ['./passwordreset.component.css']
})
export class PasswordresetComponent {

  new_password: string;
  user_pk: number;

  constructor(private mftServices: MftService) { }

  passwordValue(eventValue: any, fieldName: string) {
    if (fieldName === "new_password") {
      this.new_password = eventValue.target.value;
    }
    if (fieldName === "user_pk") {
      this.user_pk = eventValue.target.value;
    }
  };
  
  hard_password_reset() {
    var formData: any = new FormData();
    formData.append('password', this.new_password);
    formData.append('user_pk', this.user_pk);

    this.mftServices.postData('hard_password_reset', formData).subscribe(
      (data: HttpResponse<any>) => { this.mftServices.updatedAlert(data.body.data); },
      (error) => { console.error('There was an error!', error.message); }
    );
  };

}
