import { Component } from '@angular/core';
import { MftService } from 'src/app/services/mft.service';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BaseComponent } from 'src/app/components/base/base.component';
import { Users } from 'src/app/models/users';
import Papa from 'papaparse';
import { FileElement } from 'src/app/file-manager/model/element';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-preprocessing',
  templateUrl: './preprocessing.component.html',
  styleUrls: ['./preprocessing.component.css']
})
export class PreprocessingComponent extends BaseComponent{

  formulaForm: any;
  userData: any;
  user_pk: any;
  clientData: any;
  client_pk: any;
  public user = { user_pk: '', client_pk: '', search_client_pk: ''}
  public client = { client_pk: '' };
  activeformulas: any;
  formulaOptions: any[] = [];
  otherformula: string = '';
  item: string;
  headers: any;
  currentFolderItems: any[] = [];
  navigationStack: string[] = []; 
  forwardStack: string[] = []; 
  currentParentId: string = 'root';
  fileName: any;
  mimeType: any;
  fileContent: string;
  folderData: FileElement[] = []
  dropdown1Items: string[] = [];
  dropdown2Items: string[] = [];  
  validList : string[];
  filteredDropdown1Items = [...this.dropdown1Items];
  filteredDropdown2Items = [...this.dropdown2Items];
  searchQuery1: string = '';
  searchQuery2: string = '';
  activeDropdown: string | null = null;
  title: string = '';
  isEditing: boolean = false;
  originalTitle: string = '';
  content: string = '';  
  isDarkMode: boolean = false;
  selectedSyntax: string;
  selectedDescription: string;
  selectedFormulaJson: string = '';
  selectedColumn: string;
  cursorPosition: number = 0;
  isPreviewMode: boolean = false;
  lineNumbers: any;
  extractedFile: boolean = false; // Flag to track if a file has been extracted
  formulaNameList: any[];

  constructor(public override modalService: NgbModal, private mftServices: MftService, private loggedInUser: Users, private formBuilder: FormBuilder) {
    super(modalService);
  }

  ngOnInit() {
    this.formulaForm = this.formBuilder.group({
      c_logic_pk: ['', []],
      formula_name: [],
      formula_content: ['', []],
      client_pk: ['', []],
      user_pk: ['', []],
      created_date: ['', []],
      modified_date: ['', []],
      c_logic_status: ['', []],
    });

    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      this.user_pk = this.loggedInUser.getUser().user_pk;
      this.clientData = this.loggedInUser.getUser();
      this.client_pk = this.loggedInUser.getUser().client_pk;
    });

    this.loadActiveFormula();
    this.loadactiveformulas();
    this.loadFolder();
    this.loadDataSets();
    this.updateLineNumbers();
  }

  formulas: { name: string; content: string; selected: boolean }[] = [];
  selectedFormulaForEditing: { name: string; content: string } | null = null;

  toggleDropdown(dropdown: string): void {
    this.activeDropdown = this.activeDropdown === dropdown ? null : dropdown;
  }

  filterItems(event: Event, dropdown: string): void {
    const input = event.target as HTMLInputElement;
    const query = input.value.toLowerCase(); // Get the value from the input event

    if (dropdown === 'dropdown2') {
      if (query) {
        this.formulaNameList = this.formulaOptions.filter(formula =>
          formula.Formula_name.toLowerCase().includes(query)
        );
      } else {
        this.formulaNameList = [...this.formulaOptions];
      }
    }
    console.log('FilteredValues:', this.formulaNameList);

  }

  startEditing() {
    if (!this.isPreviewMode) {
      this.isEditing = true;
      this.originalTitle = this.title;
      
    }
  }
  
  saveTitle() {
    this.isEditing = false;
    // if (!this.title.trim()) {
    //   this.title = 'Enter Your Formula Name';
    // }
  }

  preventClose(event: Event): void {
    event.stopPropagation();
  }

  onInput(event: Event): void {
    const target = event.target as HTMLTextAreaElement;
    this.content = target.value;
    this.updateLineNumbers(); // Update line numbers whenever the content changes
  }

  toggleTheme(): void {
    this.isDarkMode = !this.isDarkMode;
  }

  saveCursorPosition(event: any): void {
    this.cursorPosition = event.target.selectionStart;
  }

  insertTextAtCursor(text: string): void {
    if (this.cursorPosition !== undefined && this.cursorPosition !== null) {
      const beforeCursor = this.content.substring(0, this.cursorPosition);
      const afterCursor = this.content.substring(this.cursorPosition);
      this.content = beforeCursor + text + afterCursor;
      this.cursorPosition += text.length;
    }
  }

  handleFormulaClick(formula: any, event: Event): void{
      // Prevent the dropdown from closing if that's the issue
    this.preventClose(event);

    // Pass the formula's name to passSyntax
    this.passSyntax(formula.Formula_name);
  
    // Pass the formula's JSON representation to passJsonFormula
    this.passJsonFormula(formula.Formula_pk);
  }

  passColumn(selectedColumn: string) {
    this.insertTextAtCursor(selectedColumn);
  }

  passSyntax(selectedFormulaName: string) {
    const formulaItem = this.formulaOptions.find(item => item.Formula_name === selectedFormulaName);
    if (formulaItem) {
      this.selectedSyntax = formulaItem.Syntax;
      this.selectedDescription = formulaItem.Description;
    } else {
      console.error('Formula not found:', selectedFormulaName);
    }
  }
  passJsonFormula(selectedJsonFormula: string) {
    const formulaJsonItem = this.formulaOptions.find(item => item.Formula_pk === selectedJsonFormula);
    if (formulaJsonItem) {
      this.insertTextAtCursor(formulaJsonItem.JsonFormula + ',\n');
      this.updateLineNumbers(); // Update line numbers after inserting text
    }
  }

  selectAll(event: Event) {
    const checked = (event.target as HTMLInputElement).checked;
    this.formulas.forEach(formula => (formula.selected = checked));
  }
  
  viewFormula(formula: { name: string }) {
    console.log('View formula:', formula.name);
  }

  previewFormula(formula: { formula_name: any; formula_content: string; }) {
    this.title = formula.formula_name;
    this.content = formula.formula_content;
    this.isEditing = false;
    this.isPreviewMode = true; 
     // Ensure the content is set in the editor before updating line numbers
     const codeArea = document.getElementById('codeArea') as HTMLTextAreaElement;
     if (codeArea) {
         codeArea.value = formula.formula_content;
     }
 
     // Update line numbers
     this.updateLineNumbers();
  
  }
  
  editFormula(formula: { formula_name: any; formula_content: string; c_logic_pk: string; created_date: string; modified_date: string; c_logic_status: string }) {
    this.selectedFormulaForEditing = { name: formula.formula_name, content: formula.formula_content };
    this.title = formula.formula_name;
    this.content = formula.formula_content;
    this.formulaForm.patchValue({
      formula_name: formula.formula_name,
      formula_content: formula.formula_content,
      c_logic_pk: formula.c_logic_pk,  
      created_date: formula.created_date,
      modified_date: formula.modified_date,
      c_logic_status: formula.c_logic_status
    });
    this.isEditing = true;
    this.isPreviewMode = false;
    this.updateLineNumbers(); // Update line numbers after inserting text
  }

  deleteFormula(formula: { formula_name: any; formula_content: string; c_logic_pk: string; created_date: string; modified_date: string; c_logic_status: string },title:string){
    if (confirm(`Are you sure you want to "${title}"?`)) {
      const client_pk = this.mftService.loggedInUser.getUser().client_pk;
      const formData:any = new FormData();
      formData.append('c_logic_status', title);
      formData.append('c_logic_pk', formula.c_logic_pk);
      formData.append('client_pk', client_pk);
      this.mftService.postData("formula_status",formData).subscribe(
        (response: HttpResponse<any>) => {
          const firstElement = response.body[0];
          if (firstElement && firstElement.message === 'SUCCESS') {
            this.mftService.updatedAlert("The role status updated successfully");
          } else {
            if (firstElement.status === 'FAILURE' && firstElement.data !== '') {
              this.mftService.updatedAlert(firstElement.data);
            } else {
              this.mftService.updatedAlert("Failed to update the status");
            }
          }
          this.ngOnInit();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }

  }

  loadActiveFormula(): void {
    const httpParams = new HttpParams();
    this.mftService.loadData("load_active_formula", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.otherformula.includes(obj.Formula_pk.toString())) {
            obj.Formula_status = true;
          } else {
            obj.Formula_status = false;
          }
        });
        this.formulaOptions = data.body;
        this.formulaNameList = [...this.formulaOptions];
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          console.error('Popup model', httpError.message);
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
      );
  }  
  
//text editor placeholder
updateLineNumbers() {
  const codeArea = document.getElementById('codeArea') as HTMLTextAreaElement;
  const lineNumbers = document.getElementById('lineNumbers') as HTMLElement;
  
  if (!codeArea || !lineNumbers) return;
  
  const lines = codeArea.value.split('\n').length;
  lineNumbers.innerHTML = '';  // Clear the existing line numbers

  for (let i = 1; i <= lines; i++) {
    const lineNumber = document.createElement('span');
    lineNumber.textContent = i.toString();
    lineNumbers.appendChild(lineNumber);
  }
}

syncScroll() {
  const codeArea = document.getElementById('codeArea') as HTMLTextAreaElement;
  const lineNumbers = document.getElementById('lineNumbers') as HTMLElement;

  if (!codeArea || !lineNumbers) return;
  
  lineNumbers.scrollTop = codeArea.scrollTop;  // Sync line numbers with textarea scrolling
}


// Method to extract column names from formula content
extractColumnNames(formulaContent: string): string[] {
  // Example regex to extract column names, adjust as needed
  const regex = /Your_Column_Name|\b(?:[a-z][a-z0-9_]*)\b(?=\s*(,|\))|\s*\()/gi;
  const matches = formulaContent.match(regex);
  console.log(matches);
  
  return matches ? Array.from(new Set(matches)) : [];
}

// Method to validate formula
validateFormula(formulaContent: string): boolean {
  // Extract column names from the formula
  const columnNamesInFormula = this.extractColumnNames(formulaContent);

  // Check if all column names are in the allowed list
  const allowedColumns = this.filteredDropdown1Items.map(item => item.toLowerCase());
  const invalidColumns = columnNamesInFormula.filter(name => !allowedColumns.includes(name.toLowerCase()));

  if (invalidColumns.length > 0) {
    // Alert the user if there are invalid columns
    return false;
  }

  return true;
}



  saveFormula() {  
    this.submitted = true;
    const formulaName = this.formulaForm.value['formula_name'];
    const formulaContent = this.formulaForm.value['formula_content'];
    const c_logic_pk = this.formulaForm.value['c_logic_pk'];
    const createdDate = this.formulaForm.value['created_date'] || '';  
    const modifiedDate = this.formulaForm.value['modified_date'] || '';  
    const c_logicStatus = this.formulaForm.value['c_logic_status'] || ''; 
    const formulaContentUpdated = this.formulaForm.get('formulaField')?.value;
  
    if (formulaName === '' ) {
      alert(' Please provide formula name.');
      return;
    }

    if (formulaContent.trim() === '') {
      alert('Formula space cannot be empty. Please enter valid formula content.');
      return;
    }

    if (this.validateFormula(formulaContent)) {
      // Proceed with saving the formula if validation passes
      const formData: FormData = new FormData();
      formData.append('formula', formulaContentUpdated);
  
    }
  
    if (!c_logic_pk) {

      const isDuplicate = this.formulas.some(f => f.name === formulaName);
      if (isDuplicate) {
        alert('A formula with this name already exists. Please choose a different name.');
        return;
      }
    }

    // logic to check entered formula is in json format
    let parsedContents;
    try {
        parsedContents = JSON.parse(formulaContent);
    } catch (error) {
        try {
            parsedContents = JSON.parse(`[${formulaContent}]`);
        } catch (error) {
            alert("Invalid JSON format !");
            return;
        }
    }

    this.validList= this.filteredDropdown1Items;
    
    // Split the content into individual formulas
    const formulas = formulaContent.split(/\r?\n/);
    
    // Validate each formula
    for (const [index, formula] of formulas.entries()) {
      const str = formula.trim(); // Trim whitespace
    
      // Skip empty lines
      if (str === '') {
        continue;
      }
    
      // Match the formula using the various regex patterns
      const sumMatch = str.match(/=SUM\(([^,]+),([^,]+)\)/);
      const subMatch = str.match(/=SUB\(([^,]+),([^,]+)\)/);
      const averageMatch = str.match(/=AVERAGE\(([^,]+),([^,]+)\)/);
      const productMatch = str.match(/=PRODUCT\(([^,]+),([^,]+)\)/);
      const concatMatch = str.match(/=CONCAT\(([^,]+),([^,]+)\)/);
      const modMatch = str.match(/=MOD\(([^,]+),(\d+)\)/);
      const powerMatch = str.match(/=POWER\(([^,]+),(\d+)\)/);
      const roundMatch = str.match(/=ROUND\(([^,]+),(\d+)\)/);
      const floorMatch = str.match(/=FLOOR\(([^,]+),(\d+)\)/);
      const ceilingMatch = str.match(/=CEILING\(([^,]+),(\d+)\)/);
      const intToFloatMatch = str.match(/=INTTOFLOAT\(([^,]+),(\d+)\)/);
      const expMatch = str.match(/=EXP\(([^,]+),(\d+)\)/);
      const rightMatch = str.match(/=RIGHT\(([^,]+),(\d+)\)/);
      const leftMatch = str.match(/=LEFT\(([^,]+),(\d+)\)/);
      const factMatch = str.match(/=FACT\(([^,]+)\)/);
      const decimalToIntMatch = str.match(/=DECIMALTOINT\(([^,]+)\)/);
      const dayMatch = str.match(/=DAY\(([^,]+)\)/);
      const yearMatch = str.match(/=YEAR\(([^,]+)\)/);
      const epochDateMatch = str.match(/=EPOCHDATE\(([^,]+)\)/);
      const parseDateMatch = str.match(/=PARSEDATE\(([^,]+)\)/);
      const lenMatch = str.match(/=LEN\(([^,]+)\)/);
      const countAMatch = str.match(/=COUNTA\(([^,]+)\)/);
      const upperMatch = str.match(/=UPPER\(([^,]+)\)/);
      const lowerMatch = str.match(/=LOWER\(([^,]+)\)/);
      const properMatch = str.match(/=PROPER\(([^,]+)\)/);
      const trimMatch = str.match(/=TRIM\(([^,]+)\)/);
      const monthMatch = str.match(/=MONTH\(([^,]+)\)/);
      const standardDateMatch = str.match(/=STANDARD_DATE\(([^,]+)\)/);
      const todayMatch = str.match(/=TODAY\(\)/);
      const nowMatch = str.match(/=NOW\(\)/);
      const eDateMatch = str.match(/=EDATE\(([^,]+),(\d+)\)/);
      const addWorkDaysMatch = str.match(/=ADDWORKDAYS\(([^,]+),(\d+)\)/);
      const addDateTimeMatch = str.match(/=ADDDATETIME\(([^,]+),[DMY],([^,]+)\)/);
      const ifErrorMatch = str.match(/=IFERROR\(([^\/]+)\/([^,]+),([^\)]+)\)/);
      const orMatch = str.match(/=OR\(([^,]+)([<>]=?)([^,]+),([^,]+)([<>]=?)([^)]+)\)/);
      const andMatch = str.match(/=AND\(([^,]+)([<>]=?)([^,]+),([^,]+)([<>]=?)([^)]+)\)/);
      const notMatch = str.match(/=NOT\(([^<>]+)([<>])([^)]*)\)/);
      const datedifMatch = str.match(/=DATEDIF\(([^,]+),([^,]+),([DMY])\)/);
      const midMatch = str.match(/=MID\(([^,]+),(\d+),(\d+)\)/);
      const replaceMatch = str.match(/=REPLACE\(([^,]+),([^,]+),([^,]+)\)/);
      const substituteMatch = str.match(/=SUBSTITUTE\(([^,]+),([^,]+),([^,]+),([^,]+)\)/);
      const containsMatch = str.match(/=CONTAINS\(([^,]+),([^,]+),(case_insensitive|case_sensitive)\)/);
      const endsWithMatch = str.match(/=ENDSWITH\(([^,]+),([^,]+),(case_insensitive|case_sensitive)\)/);
      const parseJsonMatch = str.match(/=PARSEJSON\(([^,]+),\$.([^,]+)\)/);
      const renameColumnMatch = formula.match(/\{"operations":\s*"rename_column",\s*"input":\s*\{\s*"old_column":\s*"([^"]+)",\s*"new_column":\s*"([^"]+)"\s*\}\s*\}/);
      const ExtractValidTableMatch = formula.match(/\{"operations":\s*"valid_table",\s*"input":\s*\{\s*"start_row":\s*(\d+),\s*"end_row":\s*(\d+)\s*\}\s*\}/);
      const MergeRowsMatch = formula.match(/\{"operations":\s*"Merge_row",\s*"input":\s*\{\s*"start_row":\s*(\d+),\s*"end_row":\s*(\d+)\s*\}\s*\}/);
      const removeEmptyRowMatch = formula.match(/\{"operations":\s*"remove_empty_row",\s*"input":\s*\{\s*"Flag":\s*"(True|False)"\s*\}\s*\}/);
      const removeUnnamedColumnMatch = formula.match(/\{"operations":\s*"remove_unnamed_column",\s*"input":\s*\{\s*"Flag":\s*"(True|False)"\s*\}\s*\}/);
      const Transpose = formula.match(/\{"operations":\s*"Transpose",\s*"input":\s*\{\s*"Flag":\s*"(True|False)"\s*\}\s*\}/);

      const RemoveSelectedRowMatch = formula.match(/\{"operations":\s*"remove_selected_row",\s*"input":\s*\{\s*"selected_row":\s*\[(\d+(,\d+)*)\],\s*"Flag":\s*"(True|False)"\s*\}\}/);

      // const RemoveSelectedRowMatch = formula.match(/\{"operations":\s*"remove_selected_row",\s*"input":\s*\{\s*"selected_row":\s*\[(\d+(?:,\d+)*)\],\s*"Flag":\s*"(True|False)"\s*\}\s*\}/);




    
      // Validation logic
      if (sumMatch || averageMatch || subMatch || productMatch || concatMatch) {
        const match = sumMatch || averageMatch || subMatch || productMatch || concatMatch;
        const [_, first, second] = match;
        if (!this.validList.includes(first.trim()) || !this.validList.includes(second.trim())) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (modMatch || powerMatch || roundMatch || floorMatch || ceilingMatch || intToFloatMatch || expMatch || rightMatch || leftMatch) {
        const match = modMatch || powerMatch || roundMatch || floorMatch || ceilingMatch || intToFloatMatch || expMatch || rightMatch || leftMatch;
        const [_, column, number] = match;
        if (!this.validList.includes(column.trim()) || isNaN(parseInt(number, 10))) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (factMatch || decimalToIntMatch || dayMatch || yearMatch || epochDateMatch || parseDateMatch || lenMatch || upperMatch || lowerMatch || properMatch || trimMatch || monthMatch || standardDateMatch) {
        const match = factMatch || decimalToIntMatch || dayMatch || yearMatch || epochDateMatch || parseDateMatch || lenMatch || upperMatch || lowerMatch || properMatch || trimMatch || monthMatch || standardDateMatch;
        const [_, column] = match;
        if (!this.validList.includes(column.trim())) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (todayMatch || nowMatch) {
        // No parameters to validate for TODAY() or NOW()
      } else if (eDateMatch || addWorkDaysMatch) {
        const match = eDateMatch || addWorkDaysMatch;
        const [_, column, number] = match;
        if (!this.validList.includes(column.trim()) || isNaN(parseInt(number, 10))) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (addDateTimeMatch) {
        const [_, number, unit, column] = addDateTimeMatch;
        if (isNaN(parseInt(number, 10)) || !['D', 'Y', 'M'].includes(unit) || !this.validList.includes(column.trim())) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (ifErrorMatch) {
        const [_, numerator, denominator, value] = ifErrorMatch;
        if (isNaN(parseFloat(numerator)) || isNaN(parseFloat(denominator)) || !value.trim()) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (orMatch || andMatch) {
        const match = orMatch || andMatch;
        const [_, firstOperand, firstOperator, secondOperand, thirdOperand, thirdOperator, fourthOperand] = match;
        if (isNaN(parseFloat(firstOperand)) || isNaN(parseFloat(secondOperand)) || isNaN(parseFloat(thirdOperand)) || isNaN(parseFloat(fourthOperand))  || !this.validList.includes(firstOperand.trim()) || !this.validList.includes(secondOperand.trim()) || !this.validList.includes(thirdOperand.trim()) || !this.validList.includes(fourthOperand.trim())) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (notMatch) {
        const [_, firstOperand, operator, secondOperand] = notMatch;
        if (isNaN(parseFloat(firstOperand)) || isNaN(parseFloat(secondOperand))  || !this.validList.includes(firstOperand.trim()) || !this.validList.includes(secondOperand.trim())) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (datedifMatch) {
        const [_, startDate, endDate, unit] = datedifMatch;
        if (!this.validList.includes(startDate.trim()) || !this.validList.includes(endDate.trim()) || !['D', 'M', 'Y'].includes(unit)) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (midMatch) {
        const [_, text, start, length] = midMatch;
        if (isNaN(parseInt(start, 10)) || isNaN(parseInt(length, 10)) || !this.validList.includes(text.trim())  ) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (replaceMatch) {
        const [_, text, start, length] = replaceMatch;
        if (isNaN(parseInt(start, 10)) || isNaN(parseInt(length, 10)) || !this.validList.includes(text.trim())) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (substituteMatch) {
        const [_, text, oldText, newText, count] = substituteMatch;
        if (!text.trim() || !oldText.trim() || !newText.trim() || isNaN(parseInt(count, 10))) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (containsMatch || endsWithMatch) {
        const match = containsMatch || endsWithMatch;
        const [_, text, substring, caseType] = match;
        if (!['case_insensitive', 'case_sensitive'].includes(caseType)|| !this.validList.includes(text.trim())) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      } else if (parseJsonMatch) {
        const [_, jsonText, key] = parseJsonMatch;
        if (!jsonText.trim() || !key.trim()) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      }
      else if (renameColumnMatch) {
        const [_, oldColumn, newColumn] = renameColumnMatch;
        // Check if the oldColumn and newColumn are valid (e.g., part of a valid column list)
        if (!this.validList.includes(oldColumn.trim()) || this.validList.includes(newColumn.trim())) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      }
      else if (ExtractValidTableMatch || MergeRowsMatch ) {
        const [_, startRow, endRow] = ExtractValidTableMatch || MergeRowsMatch ;
        // Additional validation if needed
        if (isNaN(parseInt(startRow)) || isNaN(parseInt(endRow))) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
          return;
        }
      }
      else if (removeEmptyRowMatch || removeUnnamedColumnMatch || Transpose) {
        const [_, flagValue] = removeEmptyRowMatch || removeUnnamedColumnMatch || Transpose;
        if (!["True", "False"].includes(flagValue)) {
          alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
            return;
        }
    }
    else if (RemoveSelectedRowMatch) {
      const [_, selectedRow, flagValue,hivalue] = RemoveSelectedRowMatch; // Destructure the captured values
      const selectedRowArray = selectedRow.split(',').map(Number); // Convert selected rows to an array of numbers
      
      // Ensure the flag value is either "True" or "False" and that all elements in the selectedRowArray are valid numbers
      if (!["True", "False"].includes(hivalue) || selectedRowArray.some(isNaN)) {
        alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
        return;
      }
    }
    
      else {
        alert("Invalid formula format detected at line " + (index + 1) + ". Please ensure all formulas follow the correct structure.");
        return; // Stop processing on invalid format
      }
    }

    const formData: any = new FormData();
    formData.append('c_logic_pk', c_logic_pk || '');  
    formData.append('formula_name', formulaName);
    formData.append('formula_content', formulaContent);
    formData.append('client_pk', this.mftServices.loggedInUser.getUser().client_pk);
    formData.append('user_pk', this.mftServices.loggedInUser.getUser().user_pk);
    formData.append('created_date', createdDate);
    formData.append('modified_date', modifiedDate);
    formData.append('c_logic_status', c_logicStatus);
  
    console.log('Form Data:', {
      c_logic_pk: c_logic_pk,
      formula_name: formulaName,
      formula_content: formulaContent,
      client_pk: this.mftServices.loggedInUser.getUser().client_pk,
      user_pk: this.mftServices.loggedInUser.getUser().user_pk,
      created_date: createdDate,
      modified_date: modifiedDate,
      c_logic_status: c_logicStatus
    });
  
    this.mftServices.postData("save_conditional_logic", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.modalService.dismissAll('Submit click');
        if (data.body.result === 'SUCCESS') {
          if (c_logic_pk) {
            this.mftServices.updatedAlert("The formula has been updated successfully");
          } else {
            this.mftServices.updatedAlert("The formula has been Saved successfully");
          }
          this.loadactiveformulas();
          this.cancelFormula(); 
        } else {
          this.mftServices.updatedAlert(data.body.data);
        }
        this.loadactiveformulas();
      }, (error) => { console.error('There was an error!', error.message); }
    );
  }

  loadactiveformulas() {
    if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    }
    else if(this.mftService.loggedInUser.getUser().role_id === 'ORG_ADMIN' || 'PROJECT_LEAD'){
      this.user.search_client_pk = this.mftService.loggedInUser.getUser().client_pk;
    }
    else{
      this.user.user_pk = this.mftService.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams().set('client_pk', this.user.search_client_pk).set('user_pk', this.user.user_pk);
    this.mftServices.loadData("get_conditional_logic_list",params).subscribe(
      (data: HttpResponse<any>) => {
        this.activeformulas = data.body
      }, 
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  cancelFormula() {
    // Reset the form to its default state
    this.formulaForm.reset();
    // Clear other relevant properties
    this.title = '';
    this.content = '';
    this.isEditing = false;
    this.isPreviewMode = false; 
    this.selectedFormulaForEditing = null;
    // Ensure `c_logic_pk` is reset, so it doesn't treat the next save as an edit
    this.formulaForm.patchValue({ c_logic_pk: null });
    const lineNumbers = document.getElementById('lineNumbers') as HTMLElement;
    if (lineNumbers) {
        lineNumbers.innerHTML = ''; // Clear the existing line numbers
    }
}

  modifyStatusRole(rolePk: any, title:string) {
    if (confirm(`Are you sure you want to "${title}"?`)) {
      const client_pk = this.mftService.loggedInUser.getUser().client_pk;
      const formData:any = new FormData();
      formData.append('role_status', title);
      formData.append('role_pk', rolePk);
      formData.append('client_pk', client_pk);
      this.mftService.postData("role_status",formData).subscribe(
        (response: HttpResponse<any>) => {
          const firstElement = response.body[0];
          if (firstElement && firstElement.message === 'SUCCESS') {
            this.mftService.updatedAlert("The role status updated successfully");
          } else {
            if (firstElement.status === 'FAILURE' && firstElement.data !== '') {
              this.mftService.updatedAlert(firstElement.data);
            } else {
              this.mftService.updatedAlert("Failed to update the status");
            }
          }
          this.ngOnInit();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
  }

  async loadFolder(): Promise<void>{
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    } else if (this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || this.mftServices.loggedInUser.getUser().role_id === 'PROJECT_LEAD') {
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    } else {
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }

    const params = new HttpParams()
      .set('client_pk', this.user.search_client_pk)
      .set('user_pk', this.user.user_pk);

    this.mftServices.loadData("get_wizard_list", params).subscribe(
      (data: HttpResponse<any>) => {
        this.folderData = data.body;
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:',httpError);

      }
    );
  }

  loadDataSets() {
    if (this.mftServices.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    }
    else if(this.mftServices.loggedInUser.getUser().role_id === 'ORG_ADMIN' || 'PROJECT_LEAD'){
      this.user.search_client_pk = this.mftServices.loggedInUser.getUser().client_pk;
    }
    else{
      this.user.user_pk = this.mftServices.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams().set('client_pk',this.user.search_client_pk).set('user_pk',this.user.user_pk);
    this.mftServices.loadData("load_datasets", params).subscribe(
      (data: HttpResponse<any>) => {
        this.folderData = [...this.folderData, ...data.body];
        this.loadCurrentFolderItems();
        console.log('FolderFiles',this.folderData);
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:',httpError);
      }
    );
  }


  loadCurrentFolderItems(): void {
    this.currentFolderItems = this.folderData.filter((item: any) => item.parent_id === this.currentParentId);
  }
  
  openItem(item: any): void {
    console.log('Items',item);
    if (item.isFolder) {
      this.navigationStack.push(this.currentParentId);
      this.currentParentId = item.wizard_id;
      this.forwardStack = [];
      this.loadCurrentFolderItems();
    } else {

      // Check if a file has already been extracted
      if (this.extractedFile) {
        const userConfirmed = confirm("You are extracting files again! You will loose all the unsaved work "); 
        if (!userConfirmed) {
            return; 
        }
        this.cancelFormula();
       }
 
      // Handle file opening logic 
      if (item.mimetype) {
        this.fileName = item.folder_name ?? '';
        this.mimeType = item.mimetype ?? '';
        this.fileContent = atob(item.content || '');
        this.extractedFile = true; // Set flag to true after extracting a file

        if (this.mimeType === 'application/json') {
          this.displayJson();
        } else if (this.mimeType === 'text/csv' || this.mimeType === 'text/tab-separated-values') {
          this.displayCsv();
        } else if (this.mimeType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
          this.displayXlsx();
        } else {
          console.error('Unsupported file type');
        }
      } 
      console.log('File opened:', item.folder_name);

    }
  }


  displayXlsx(): void {
    try {
      // Parse the fileContent as a binary string for XLSX
      const workbook = XLSX.read(this.fileContent, { type: 'binary' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      this.headers = jsonData[0]; // Extract headers from the first row
      // Optionally, you can process or display the data further
    } catch (error) {
      console.error('Error processing XLSX file:', error);
    }
  }
  
  displayJson(): void {
    try {
      const jsonData = JSON.parse(this.fileContent);
      if (jsonData.length > 0) {
        this.headers = Object.keys(jsonData[0]);
  }
    } catch (e) {
      console.error('Failed to parse JSON', e);
    }
    console.log('Json',this.headers);
  }
  
  displayCsv(): void {
    Papa.parse(this.fileContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        this.headers = results.meta.fields;
  },
      error: (error: any) => {
        console.error('Error parsing CSV', error);
      }
    });
    
    this.dropdown1Items = this.headers.map((item: any) => {return item;});
    this.filteredDropdown1Items = [...this.dropdown1Items];
  
    console.log('csv/xlsx',this.headers);
  }    
  
  goBack(): void {
    if (this.navigationStack.length > 0) {
      this.forwardStack.push(this.currentParentId); 
      this.currentParentId = this.navigationStack.pop()!; 
      this.loadCurrentFolderItems();
    }
  }
  
  goForward(): void {
    if (this.forwardStack.length > 0) {
      this.navigationStack.push(this.currentParentId); 
      this.currentParentId = this.forwardStack.pop()!; 
      this.loadCurrentFolderItems();
    }
  }
  // text editor single click to select word

 selectWord(event: MouseEvent): void {
    event.preventDefault();
    const textarea = event.target as HTMLTextAreaElement;
    const cursorPosition = textarea.selectionStart;
    const text = textarea.value;

    // Regex to match specific parts for yellow highlight (e.g., Your_Column_Name and words inside parentheses)
    const regex = /Your_Column_Name|\b(?:[a-z][a-z0-9_]*)\b(?=\s*(,|\))|\s*\()/gi;
    
    let match;
    let found = false;
    let start = 0;
    let end = 0;

    while ((match = regex.exec(text)) !== null) {
        start = match.index;
        end = regex.lastIndex;

        // Ensure we're not selecting capitalized method names
        if (!/^[A-Z][A-Z0-9_]*$/.test(text.slice(start, end))) {
            if (cursorPosition >= start && cursorPosition <= end) {
                textarea.setSelectionRange(start, end);
                found = true;
                break;
            }
        }
    }

    if (found) {
        // Apply a custom class to highlight the selection
        textarea.classList.add('highlight-selection');
        // Use a timeout to ensure the class is applied after the selection is made
        setTimeout(() => {
            textarea.setSelectionRange(start, end);
        }, 10);
    } else {
        // Remove custom highlighting if the selection doesn't match
        textarea.classList.remove('highlight-selection');
    }
}

//function to check json valid or not
 isValidJSON(text: string) {
  try {
      JSON.parse(text);
      return true;
  } catch (e) {
      return false;
  }
}

callFunction(){
  console.log("Mouse out function triggered.");

// Regex pattern to match the value after "Column":
const regex = /(?<="Column"\s*:\s*")[^"]+/g;

// Get the formula content
const callfues = this.formulaForm.value['formula_content'];

// Log the formula content to ensure it's as expected
console.log("Formula content:", callfues);

// Perform regex match on the formula content
const regexmatch = callfues.match(regex);

// Check if match was found
if (regexmatch) {
  console.log("Matched columns:", regexmatch);

  // Push each matched string individually into the filteredDropdown1Items array, but only if it doesn't already exist
  regexmatch.forEach((match: string) => {
    if (!this.filteredDropdown1Items.includes(match)) {
      this.filteredDropdown1Items.push(match);
    }
  });
  
  console.log("Valid List", this.filteredDropdown1Items);
} else {
  console.log("No matches found.");
}
 
}
}
