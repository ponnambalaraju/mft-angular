import { Component } from '@angular/core';
import {
  NgbCalendar,
  NgbDateAdapter
} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'ngbd-datepicker-popup',
  templateUrl: './datepicker-popup.html'
})
export class NgbdDatepickerPopup {
  model: any;
  minDate = {year: 1950, month: 1, day: 1};
  maxDate = {year: 2100, month:1, day: 1};

  constructor(
    private ngbCalendar: NgbCalendar,
    private dateAdapter: NgbDateAdapter<string>
  ) {}

  get today() {
    return this.dateAdapter.toModel(this.ngbCalendar.getToday())!;
  }
}
