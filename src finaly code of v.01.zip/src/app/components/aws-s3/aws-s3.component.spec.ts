import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AWSS3Component } from './aws-s3.component';

describe('HtiAmazonS3Component', () => {
  let component: AWSS3Component;
  let fixture: ComponentFixture<AWSS3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AWSS3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AWSS3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
