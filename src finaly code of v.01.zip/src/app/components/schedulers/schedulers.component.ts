import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormControl } from '@angular/forms';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { MftService } from 'src/app/services/mft.service';
import { Validators } from '@angular/forms';
import { BaseComponent } from '../base/base.component';
import cronstrue from 'cronstrue';
import { SelectionChangedEvent } from 'ag-grid-community';
import { ColumnDefs } from 'src/app/column-def';
import cronParser from 'cron-parser';

@Component({
  selector: 'app-schedulers',
  templateUrl: './schedulers.component.html',
  styleUrls: ['./schedulers.component.css'],
})
export class SchedulersComponent extends BaseComponent {

  unix_cron_expression = '';
  columnDefs: ColumnDefs[] = [];
  gridApi: any;
  RowData: any;
  IsColumnsToFit: boolean = false;
  button_disable: boolean = true;
  job_description: string = '';
  override submitted = false;
  schedulerOptions: any[] = [];
  tempClientOptions: any[] = [];
  tempTriggerOptions: any[] = [];
  valid_cron: boolean = false;
  trigger_pk: number;
  triggerOptions: any[] = [];
  schedulerList: any[] = [];
  search_client_pk: string;
  search_trigger_pk: string;
  
  onModelChange() {
    this.valid_cron = false;
    try {
      cronParser.parseExpression(this.unix_cron_expression);
      this.job_description = cronstrue.toString(this.unix_cron_expression);
      this.valid_cron = true;
    } catch (error) {
      /* const parsedExpression = cronParser.parseExpression(this.unix_cron_expression);
      const currentDate = new Date();
      const cronNextDate = parsedExpression.next();

      if (currentDate.getMonth() !== cronNextDate.getMonth() || currentDate.getDate() !== cronNextDate.getDate()) {
        console.log('Valid cron expression'); // If the date is found, set validation message
      } else {
        console.log('Invalid date in cron expression'); // If the date is not found, set validation message
      } */
      this.job_description = 'Invalid date in scheduling';
      this.valid_cron = false;
    }
  }

  constructor(public override modalService: NgbModal, private formBuilder: FormBuilder, private mftServices: MftService) { 
    super(modalService);
  }

  schedulerForm = this.formBuilder.group({
    trigger_pk: new FormControl('', [Validators.required]),
    scheduler_id: new FormControl('', [])
  });

  ngOnInit() {
    this.search_trigger_pk = '%';
    if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.search_client_pk = '%';
    } else {
      this.search_client_pk = this.mftService.loggedInUser.getUser().client_pk;
    }
    const params = new HttpParams().set('client_pk', this.search_client_pk);
    this.mftServices.loadData("scheduler_trigger_list", params).subscribe(
      (data: HttpResponse<any>) => { this.triggerOptions = data.body; },
      (error) => { console.error('There was an error!', error.message); }
    );

    this.customizedHeaderView(5 , 'scheduler_id', this.columnDefs);

    this.popupModalService.showMessageAlertPopupModal.subscribe((result :{ show: boolean }) => {
      if (!result.show) {
        this.load_scheduler_list();
      }
    });
  }

  clickEvent:string;
  currentEvent: string;

  open(content: any, clickEvent: string) {
    this.submitted = false;
    this.currentEvent = clickEvent;

    if (clickEvent === 'NEW') {
      this.clickEvent = clickEvent;
      this.unix_cron_expression = '0 0 * * *';
      this.job_description = '';
      this.schedulerForm.patchValue({ trigger_pk: '', scheduler_id: ''});
    }

    if (clickEvent === 'EDIT') {
      this.clickEvent = clickEvent;
      const selectedData = this.gridApi.getSelectedRows();
      
      this.unix_cron_expression = selectedData[0]["unix_cron_expression"]
      this.schedulerForm.patchValue({ trigger_pk: selectedData[0]["trigger_pk"], scheduler_id: selectedData[0]["scheduler_id"]});
    }
    const modalRef = this.modalService.open(content, { backdrop: 'static', centered: true, size: 'lg', ariaLabelledBy: 'modal-basic-title'});
    modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  
  save_scheduler() {
    this.submitted = true;
    if (this.schedulerForm.invalid) {
      return;
    }
    var formData: any = new FormData();
    formData.append('scheduler_id', this.schedulerForm.get('scheduler_id')?.value);
    formData.append('scheduler_pk', this.clickEvent !== 'NEW' ? this.gridApi.getSelectedRows()[0]["scheduler_pk"] : '');
    formData.append('trigger_pk', this.schedulerForm.get('trigger_pk')?.value);
    formData.append('unix_cron_expression', this.unix_cron_expression);
    formData.append('mft_ui_address', this.mftServices.mft_ui_address),
    
    this.mftServices.postData("save_scheduler", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.modalService.dismissAll('Submit click');
        if (data.body === 'SUCCESS') {
          this.mftServices.updatedAlert("The scheduler details has been saved successfully");
        } else {
          this.mftServices.updatedAlert("Some Issue");
        }
        this.load_scheduler_list();
      },
      (error) => { console.error('There was an error!', error.message); }
    );
  }

  schedulersDataBind(params: any) {
    this.gridApi = params.api;
    params.api.setRowData(this.RowData);
    this.load_scheduler_list();
  }

  loadSchedulers() {
    if (this.search_client_pk === '%' && this.search_trigger_pk === '%') {
      this.gridApi.setRowData(this.schedulerOptions);
    } else if (this.search_client_pk === '%' && this.search_trigger_pk !== '%') {
      this.gridApi.setRowData(this.schedulerOptions.filter((item: any) => item.trigger_pk.toString() === this.search_trigger_pk));
    } else if (this.search_client_pk !== '%' && this.search_trigger_pk === '%') {
      this.gridApi.setRowData(this.schedulerOptions.filter((item: any) => item.client_pk.toString() === this.search_client_pk.toString()));
    } else {
      this.gridApi.setRowData(this.schedulerOptions.filter((item: any) => item.client_pk.toString() === this.search_client_pk.toString() && item.trigger_pk.toString() === this.search_trigger_pk));
    }
    this.gridApi.refreshCells();
  }

  load_scheduler_list() {
    let httpParams = new HttpParams().set('client_pk', this.search_client_pk);
    
    if (this.search_trigger_pk !== undefined) {
      httpParams = httpParams.set('trigger_pk', this.search_trigger_pk);
    }
    
    this.mftServices.loadData("scheduler_list", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.gridApi.setRowData(data.body);
        this.gridApi.refreshCells();

        this.schedulerOptions = data.body;

        this.tempClientOptions = data.body.filter((value: { client_pk: any; }, index: any, self: any[]) =>
          index === self.findIndex((v: { client_pk: any; }) => v.client_pk === value.client_pk)
        );
        this.tempTriggerOptions = data.body.filter((value: { trigger_pk: any; }, index: any, self: any[]) =>
          index === self.findIndex((v: { trigger_pk: any; }) => v.trigger_pk === value.trigger_pk)
        );
        this.active_disable = true;
        this.deactive_disable = true;
        this.edit_disable = true;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  load_trigger_list() {
    this.tempTriggerOptions = this.schedulerOptions.filter((value: { client_pk: any }) => this.search_client_pk === '%' ? value.client_pk !== 0 : value.client_pk === parseInt(this.search_client_pk));
    this.tempTriggerOptions = this.tempTriggerOptions.filter((value: { trigger_pk: any; }, index: any, self: any[]) =>
      index === self.findIndex((v: { trigger_pk: any; }) => v.trigger_pk === value.trigger_pk)
    );
    if (this.search_client_pk !== '%') {
      this.search_trigger_pk = '%';
    }
  }

  onSelectionChanged(event: SelectionChangedEvent) {
    const selectedData = this.gridApi.getSelectedRows();
    this.button_disable = true;
    this.edit_disable = true;
    this.active_disable = true;
    this.deactive_disable = true;
  
    if (selectedData.length > 0) {
      const hasActive = selectedData.some((item: { scheduler_status: string }) => item.scheduler_status === "ACTIVE");
      const hasDeactive = selectedData.some((item: { scheduler_status: string }) => item.scheduler_status === "INACTIVE");
  
      this.disableActiveDeactive(selectedData, hasActive, hasDeactive);
    }
  }

}
