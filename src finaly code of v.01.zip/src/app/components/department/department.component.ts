import { Component } from '@angular/core';
import { RowNode } from 'ag-grid-community';
import { Users } from 'src/app/models/users';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BaseComponent } from '../base/base.component';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent extends BaseComponent {

  constructor(private loggedInUser: Users, public override modalService: NgbModal) { 
    super(modalService);
  }

  departmentColumnDefs: any;
  projectColumnDefs: any;
  departmentAgLoad: boolean = true;
  departmentGridApi: any;
  projectAgLoad: boolean = true;
  projectGridApi: any;
  IsColumnsToFit: boolean = true;
  clientOptions: any[] = [];
  onlyDepartmentList: any[] = [];
  selectedDepartment: any[] = [];
  public user = { search_client_pk: '' }
  userData: any;
  processSelected: any;
  selectedprojtdep: any;
  departmentproject: string;
  departmentprojectpk: number;
  department_pk_list: string ='';
  project_pk_list: string ='';
  edit_grp_disable: boolean = true;
  active_grp_disable: boolean = true;
  deactive_grp_disable: boolean = true;
  create_prj_disable: boolean = false;
  edit_prj_disable: boolean = true;
  active_prj_disable: boolean = true;
  deactive_prj_disable: boolean = true;
  currentEvent: string;

  loadActiveClients(client_pk: string) {
    const params = new HttpParams().set('client_pk', client_pk);
    this.mftService.loadData("load_client_list", params).subscribe(
      (data: HttpResponse<any>) => { 
        this.clientOptions = data.body.filter((client: { client_status: string }) => client.client_status === 'ACTIVE');;
        if (this.userData.role_id === 'SYS_ADMIN') {
          this.user.search_client_pk = "%";
        }
        this.loadClientDepartment(null);
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  ngOnInit() {
    this.departmentColumnDefs = [
      { headerName: 'Client Name', field: 'client_pk', valueGetter: this.getClientName.bind(this), headerCheckboxSelection: true, checkboxSelection: true, resizable: true, minWidth: 150 },
      { headerName: 'Group PK', field: 'department_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Group ID', field: 'department_id', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'Group Name', field: 'department_name', sortable: true, filter: true,  resizable: true, minWidth: 250 },
      { headerName: 'Group Status', field: 'department_status', sortable: true, filter: true, resizable: true, minWidth: 150 }
    ];

    this.projectColumnDefs = [
      { headerName: 'Group Name', field: 'department_pk', sortable: true, filter: true, resizable: true, minWidth: 200, valueGetter: this.getGroupName.bind(this), headerCheckboxSelection: true, checkboxSelection: true },
      { headerName: 'Project PK', field: 'project_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Project ID', field: 'project_id', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Project Name', field: 'project_name', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Project Status', field: 'project_status', sortable: true, filter: true, resizable: true, minWidth: 130 }
    ];

    this.mftService.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      if (this.userData) {
        if (this.userData.role_id === 'SYS_ADMIN') {
          this.user.search_client_pk = "%";
        } else {
          this.user.search_client_pk = this.userData.client_pk;
        }
        this.loadActiveClients(this.user.search_client_pk);
      }
    });
    this.processSelected = "createdepartment";

    this.popupModalService.showModal.subscribe((result :{ show: boolean, data: any }) => {
      if (result.data) {
        if (result.show) {
          console.log('Modal opened in parent component');
        } else {
          console.log('Modal closed in parent component');
          if (this.processSelected == "createdepartment" || this.processSelected == "editdepartment" || this.processSelected == "activatedepartment" || this.processSelected == "deactivatedepartment") {
            this.departmentGridApi.setRowData(result.data);
            this.departmentGridApi.refreshCells();
          } else if (this.processSelected == "createproject" || this.processSelected == "editproject" || this.processSelected == "activateproject" || this.processSelected == "deactivateproject") {
            this.projectGridApi.setRowData(result.data);
            this.projectGridApi.refreshCells();
          }
          if (this.processSelected == "activatedepartment" || this.processSelected == "deactivatedepartment") {
            this.active_grp_disable = true;
            this.deactive_grp_disable = true;
            this.edit_grp_disable = true;
            this.processSelected = "createdepartment";
            this.onProjectSelection();
          }
          if (this.processSelected == "activateproject" || this.processSelected == "deactivateproject") {
            this.active_prj_disable = true;
            this.deactive_prj_disable = true;
            this.edit_prj_disable = true;
            this.processSelected = "createdepartment";
          }
          let active_department = result.data.some((item: { department_status: string }) => item.department_status === "ACTIVE");
          if (active_department) {
            this.create_prj_disable = false;
          } else {
            this.create_prj_disable = true;
          }

        }
      }
    });
  }

  departmentDataBind(params: any) {  
    this.departmentGridApi = params.api;  
    if (this.IsColumnsToFit) {
      this.departmentGridApi.sizeColumnsToFit();  
    }
  };

  projectDataBind(params: any) {  
    this.projectGridApi = params.api;  
    if (this.IsColumnsToFit) {
      this.projectGridApi.sizeColumnsToFit();
    }
  };

  onDepartmentSelection() {
    let selectedData = this.departmentGridApi.getSelectedRows();
    if (selectedData.length > 0) {
      this.department_pk_list = selectedData.map((row: any) => row.department_pk).join(',');
      this.loadDepartmentProject(this.department_pk_list, null);

      const hasActive = selectedData.some((item: { department_status: string }) => item.department_status === "ACTIVE");
      const hasDeactive = selectedData.some((item: { department_status: string }) => item.department_status === "INACTIVE");
  
      if (hasActive && hasDeactive) {
        this.active_grp_disable = true;
        this.deactive_grp_disable = true;
        this.edit_grp_disable = true;
      } else if (hasActive) {
        if (selectedData.length > 1) {
          this.active_grp_disable = true;
          this.deactive_grp_disable = false;
          this.edit_grp_disable = true;
        } else {
          this.active_grp_disable = true;
          this.deactive_grp_disable = false;
          this.edit_grp_disable = false;
        }
      } else if (hasDeactive) {
        this.active_grp_disable = false;
        this.deactive_grp_disable = true;
        this.edit_grp_disable = true;
      } else {
        this.active_grp_disable = true;
        this.deactive_grp_disable = true;
        this.edit_grp_disable = true;
      }
    }
    if (selectedData.length == 0) {
      this.active_grp_disable = true;
      this.deactive_grp_disable = true;
      this.edit_grp_disable = true;
      this.loadActiveClients(this.user.search_client_pk);
    }
  };

  onProjectSelection() {
    let selectedData = this.projectGridApi.getSelectedRows();
    if (selectedData.length > 0) {
      this.project_pk_list = selectedData.map((row: any) => row.project_pk).join(',');

      const hasActive = selectedData.some((item: { project_status: string }) => item.project_status === "ACTIVE");
      const hasDeactive = selectedData.some((item: { project_status: string }) => item.project_status === "INACTIVE");
  
      if (hasActive && hasDeactive) {
        this.active_prj_disable = true;
        this.deactive_prj_disable = true;
        this.edit_prj_disable = true;
      } else if (hasActive) {
        if (selectedData.length > 1){
          this.active_prj_disable = true;
          this.deactive_prj_disable = false;
          this.edit_prj_disable = true;
        } else {
          this.active_prj_disable = true;
          this.deactive_prj_disable = false;
          this.edit_prj_disable = false;
        }
      } else if (hasDeactive) {
        this.active_prj_disable = false;
        this.deactive_prj_disable = true;
        this.edit_prj_disable = true;
      } else {
        this.active_prj_disable = true;
        this.deactive_prj_disable = true;
        this.edit_prj_disable = true;
      }
    }
    if (selectedData.length == 0) {
      this.active_prj_disable = true;
      this.deactive_prj_disable = true;
      this.edit_prj_disable = true;
    }
  };

  loadClientDepartment(event: any): void {
    const httpparams = new HttpParams().set('client_pk', event != null ? event.target.value : this.user.search_client_pk);
    this.mftService.loadData("department_list", httpparams).subscribe(
      (data: HttpResponse<any>) => {
        this.departmentGridApi.setRowData(data.body);
        this.departmentGridApi.refreshCells();
        if (data.body.length === 0) {
          this.create_prj_disable = true;
          this.active_grp_disable = true;
          this.deactive_grp_disable = true;
          this.edit_grp_disable = true;
          this.processSelected = "createdepartment";
        } else {
          this.create_prj_disable = false;
          this.edit_prj_disable = true;
          this.active_prj_disable = true;
          this.deactive_prj_disable = true;
          let active_department = data.body.some((item: { department_status: string }) => item.department_status === "ACTIVE");
          if (!active_department) {
            this.create_prj_disable = true;
            this.processSelected = "createdepartment";
          }
        }
        this.loadDepartmentProject(null, this.user.search_client_pk);
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  loadDepartmentProject(department_pk: any, client_pk: any) {
    let httpparams: any;
    if (client_pk == null && department_pk == null) {
      httpparams = new HttpParams()
    } else if (client_pk == null && department_pk != null) {
      httpparams = new HttpParams().set('department_pk', department_pk);
    } else if (client_pk != null && department_pk == null) {
      httpparams = new HttpParams().set('client_pk', client_pk);
    } else if (client_pk != null && department_pk != null) {
      httpparams = new HttpParams().set('department_pk', department_pk);
    }

    if (this.departmentproject === "Department" && client_pk !== null) {
      this.mftService.loadData("department_list", httpparams).subscribe(
        (data: HttpResponse<any>) => {
          this.departmentGridApi.setRowData(data.body);
          this.departmentGridApi.refreshCells();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    } else {
      this.mftService.loadData("project_list", httpparams).subscribe(
        (data: HttpResponse<any>) => {
          this.projectGridApi.setRowData(data.body);
          this.projectGridApi.refreshCells();
 
          this.edit_prj_disable = true;
          this.active_prj_disable = true;
          this.deactive_prj_disable = true;
          this.processSelected = "createdepartment";
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
  };

  open() {
    if (!this.userData.functional_privileges_pk?.includes('7') || !this.userData.functional_privileges_pk?.includes('8' || !this.userData.functional_privileges_pk?.includes('9') || !this.userData.functional_privileges_pk?.includes('10'))
      || !this.userData.functional_privileges_pk?.includes('11') || !this.userData.functional_privileges_pk?.includes('12') || !this.userData.functional_privileges_pk?.includes('13') || !this.userData.functional_privileges_pk?.includes('14')) {
      let popup_data = { modalTitle: 'Message', modalMessage: 'You don\'t have sufficient privileges to perform any action', yesButtonText: 'OK', isNoVisible: false };
      this.popupModalService.openMessageAlertPopupModal(popup_data); return;
    }

    var data;
    if (this.processSelected == "createdepartment") {
      data = { department_name: '', department_id: '', client_pk: '', department_pk: '', popup: 'createdepartment', search_client_pk: this.user.search_client_pk, clientOptions: this.clientOptions };
      this.popupModalService.openModal(data);
    } else if (this.processSelected == "editdepartment") {
      let selectedData = this.departmentGridApi.getSelectedRows();
      data = { department_name: selectedData[0]["department_name"], department_id: selectedData[0]["department_id"], client_pk: selectedData[0]["client_pk"], 
          department_pk: selectedData[0]["department_pk"], popup: 'createdepartment', search_client_pk: this.user.search_client_pk, clientOptions: this.clientOptions };
      this.popupModalService.openModal(data);
    } else if (this.processSelected == "activatedepartment" || this.processSelected == "deactivatedepartment") {
      const httpParams = new HttpParams()
      .set('activatedeactivate', this.processSelected === "activatedepartment" ? 'ACTIVE' : 'INACTIVE')
      .set('departmentproject', 'Department')
      .set('pk_list', this.department_pk_list);

      let redircetHttpParams: any;
      redircetHttpParams = new HttpParams().set('client_pk', this.user.search_client_pk);
      
      data = { action: this.processSelected === "activatedepartment" ? 'activate' : 'deactivate', service: 'department', httpUrl: 'act_Deact_Department_Project', httpParams: httpParams, redirectHttpUrl: 'department_list', redircetHttpParams: redircetHttpParams };
      this.popupModalService.openModal(data);
    } else if (this.processSelected == "createproject" || this.processSelected == "editproject") {
      let departmentRows: RowNode[] = this.departmentGridApi.getModel().getTopLevelNodes()
      var filteredRows = departmentRows.filter(function (node) { return node.data.department_status === 'ACTIVE'; });
      this.selectedDepartment = filteredRows.map((row: any) => ({ project_department_pk: row.data.department_pk, department_name: row.data.department_name }));

      let temp_project_department_pk = '';
      if (this.processSelected === "createproject" && this.departmentGridApi.getSelectedNodes().length !== 1) {
        temp_project_department_pk = '';
      } else {
        temp_project_department_pk = this.projectGridApi.getSelectedNodes()[0].data.department_pk;
      }
      if (this.processSelected === "createproject") {
        data = { project_department_pk: temp_project_department_pk, project_id: '', project_name: '', project_pk: '', popup: 'createproject', departmentOptions: this.selectedDepartment, department_pk_list: this.department_pk_list };
      } else {
        data = { project_department_pk: temp_project_department_pk, project_id: this.projectGridApi.getSelectedNodes()[0].data.project_id, project_name: this.projectGridApi.getSelectedNodes()[0].data.project_name, 
          project_pk: this.projectGridApi.getSelectedNodes()[0].data.project_pk, popup: 'createproject', departmentOptions: this.selectedDepartment, department_pk_list: this.department_pk_list };
      }
      this.popupModalService.openModal(data);
    } else if (this.processSelected === "activateproject" || this.processSelected === "deactivateproject") {
      const httpParams = new HttpParams()
      .set('activatedeactivate', this.processSelected === "activateproject" ? 'ACTIVE' : 'INACTIVE')
      .set('departmentproject', 'Project')
      .set('pk_list', this.project_pk_list);

      let temp_department_pk = this.department_pk_list !== "" ? this.department_pk_list: null;

      let redircetHttpParams: any;
      if (this.user.search_client_pk == null && temp_department_pk == null) {
        redircetHttpParams = new HttpParams()
      } else if (this.user.search_client_pk == null && temp_department_pk != null) {
        redircetHttpParams = new HttpParams().set('department_pk', temp_department_pk);
      } else if (this.user.search_client_pk != null && temp_department_pk == null) {
        redircetHttpParams = new HttpParams().set('client_pk', this.user.search_client_pk);
      } else if (this.user.search_client_pk != null && temp_department_pk != null) {
        redircetHttpParams = new HttpParams().set('department_pk', temp_department_pk);
      }

      data = { action: this.processSelected === "activateproject" ? 'activate' : 'deactivate', service: 'project', httpUrl: 'act_Deact_Department_Project', httpParams: httpParams, redirectHttpUrl: 'project_list', redircetHttpParams: redircetHttpParams };
      this.popupModalService.openModal(data);
    }
  };
  

  getGroupName(params: any) {
    // Iterate through each row after filtering and sorting
    this.departmentGridApi.forEachNodeAfterFilterAndSort((node: any) => {
      const departmentPk = node.data['department_pk'];
      const departmentName = node.data['department_name'];
    
      if (departmentPk !== null && departmentPk !== undefined) {
        this.onlyDepartmentList.push({ key: departmentPk, value: departmentName });
      }
    });

    if (this.onlyDepartmentList) {
      const temp_department = this.onlyDepartmentList.find(department => parseInt(department.key) === parseInt(params.data.department_pk));
      return temp_department ? temp_department.value : undefined;
    } else {
      return '';
    }

  };

  getClientName(params: any) {
    let client = this.userData.client_list.find((client: { client_pk: number; }) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  };

}