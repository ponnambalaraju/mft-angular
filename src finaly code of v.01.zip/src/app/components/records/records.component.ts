import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { SelectionChangedEvent } from 'ag-grid-community';
import { BaseComponent } from '../base/base.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'app-records',
  templateUrl: './records.component.html',
  styleUrls: ['./records.component.css']
})

export class RecordsComponent extends BaseComponent implements OnInit {

  constructor(public override modalService: NgbModal, private router: Router) {
    super(modalService);
  }

  selectedDate: Date;
  ColumnDefs: any;
  workflowColumnDefs: any[] | null = null;
  formulaColumnDefs: any[] | null = null;
  wizardColumnDefs: any[] | null = null;
  RowData: any;
  AgLoad: boolean = true;
  gridApi: any;
  gridColumnApi: any;
  IsColumnsToFit: boolean = true;
  reportType: string;
  isButtonVisible = false;
  showIcons: boolean = false;
  export_disable: boolean = true;
  totalFileCount:number;
  startDate: Date;
  endDate: Date;
  selectedDateRange: string;

  download_disable: boolean = true;
  rowData: any[] = [];
  sourceTransferTypeOptions: any[] = [];
  destinationTransferTypeOptions: any[] = [];
  clientOptions: any[];
  triggerOptions: any[];
  public user = { user_pk: '', client_pk: '', search_client_pk: '%', search_trigger_pk: '%' };

  ngOnInit() {
    this.reportType = "Wizard_Log";
    this.getReportColumns();
    this.loadChangedReportWithDateFilter();
  }

  getReportColumns() {
    this.wizardColumnDefs = [
      { headerName: 'Module Name', field: 'module_name', sortable: true, filter: true, headerCheckboxSelection: true, checkboxSelection: true, resizable: true, minWidth: 450 },
      { headerName: 'Flow Name', field: 'flow_name', sortable: true, resizable: true, minWidth: 150, suppressMenu: true },
      { headerName: 'Previous Data', field: 'previous_data', sortable: true, resizable: true, minWidth: 250, suppressMenu: true },
      { headerName: 'Modified Data', field: 'modified_data', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
      { headerName: 'Time at', field: 'time_at', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
      { headerName: 'Status', field: 'status', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
      { headerName: 'Status Description', field: 'status_description', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
      { headerName: 'Client Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getClientValue.bind(this) },
      { headerName: 'User Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getUserValue.bind(this) },
    ];    
  }

  BindData(params: any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.setRowData(this.RowData);
    if (this.IsColumnsToFit) {
      this.gridApi.sizeColumnsToFit();
    }
  }

  export_pdf() {
    const selectedData = this.gridApi.getSelectedRows();
    if (selectedData.length <= 0) {
      return;
    }

    const totalFiles = selectedData.length;
    const doc = new jsPDF();

    const selectedColumns = this.gridColumnApi.getAllDisplayedColumns().map((column: any) => column.getColDef());

    const headersForOthers = selectedColumns.map((colDef: any) => {
      const { field, headerName } = colDef;
      const workflowColumnDefs = this.workflowColumnDefs?.find((Def: any) => Def.field === field);
      const formulacolumnDefs = this.formulaColumnDefs?.find((Def: any) => Def.field === field);
      const wizardColumnDefs = this.wizardColumnDefs?.find((Def: any) => Def.field === field);

      return (
        workflowColumnDefs?.headerName ||
        formulacolumnDefs?.headerName || wizardColumnDefs?.headerName ||
        headerName || field
      );
    });

    const tableDataForOthers = selectedData.map((rowData: any) =>
      selectedColumns.map((colDef: any) => rowData[colDef.field])
    );

    (doc as any).autoTable({
      head: [headersForOthers],
      body: tableDataForOthers,
      margin: { top: 50, left: 5, right: 5, bottom: 20 },
      styles: {
        fontSize: 8,
        halign: 'center',
        textColor: [100, 100, 100] // Set text color to black
      },
      headStyles: { fillColor: [211, 211, 211] } // Change background color of header
    });

    const totalPages = doc.internal.pages.length;
    const loadLogoImage = (imageSrc: string): Promise<HTMLImageElement> => {
      return new Promise((resolve, reject) => {
        const logoImage = new Image();
        logoImage.src = imageSrc;
        logoImage.onload = () => resolve(logoImage);
        logoImage.onerror = (error) => reject(error);
      });
    };

    loadLogoImage('/assets/images/Report.png').then((logoImage) => {
      let currentPageNumber = 1;
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);

        doc.setFillColor(255, 255, 255);
        doc.rect(0, 0, doc.internal.pageSize.getWidth(), 42, 'F');

        doc.setFillColor(255, 255, 255);
        doc.rect(10, 10, 30, 30, 'F');
        const imageData = logoImage.src;
        doc.addImage(imageData, 'PNG', 10, 10, 30, 30);
        doc.setFontSize(12);

        doc.setFont('helvetica', 'bold');
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(23);
        doc.text('Hephzibah Technologies Inc', 50, 25);
        doc.setFontSize(16);
        doc.text('MultiProtocol File Transfer', 50, 35);

        doc.setTextColor(100, 100, 100);
        doc.setFontSize(14);
        doc.setFont('Roboto', 'sans-serif');
        doc.text(
          '© Copyright 2024 - Hephzibah Technologies Inc - All Rights Reserved.',
          doc.internal.pageSize.getWidth() / 2,
          doc.internal.pageSize.getHeight() - 15,
          { align: 'center' }
        );

        doc.setFontSize(12);
        if (i !== totalPages) {
          doc.text(`Page ${i}`, doc.internal.pageSize.getWidth() - 20, doc.internal.pageSize.getHeight() - 15, {
            align: 'center',
          });
        }
        doc.setFont('helvetica');
        doc.setTextColor(73, 80, 87);
        doc.setFontSize(8);
        doc.text(`Total No of Files: ${totalFiles}`, 5, 48);
      }
      currentPageNumber++;
      if (this.formulaColumnDefs) {
        doc.save('Conditional logic Report.pdf');
        this.gridColumnApi.refreshCells();
      } else if (this.wizardColumnDefs) {
        doc.save('Wizard Report.pdf');
        this.gridColumnApi.refreshCells();
      } else if (this.workflowColumnDefs) {
        doc.save('Workflow Report.pdf');
        this.gridColumnApi.refreshCells();
      }
      this.formulaColumnDefs = null;
      this.wizardColumnDefs = null;
      this.workflowColumnDefs = null;
    }).catch((error) => {
      console.error('Error loading logo image:', error);
    });
  }


loadChangedReportWithDateFilter() {

    if (this.reportType == "Wizard_Log") {
      this.wizardColumnDefs = [
          { headerName: 'Module Name', field: 'module_name', sortable: true, filter: true, headerCheckboxSelection: true, checkboxSelection: true, resizable: true, minWidth: 450 },
          { headerName: 'Flow Name', field: 'flow_name', sortable: true, resizable: true, minWidth: 150, suppressMenu: true },
          { headerName: 'Previous Data', field: 'previous_data', sortable: true, resizable: true, minWidth: 250, suppressMenu: true },
          { headerName: 'Modified Data', field: 'modified_data', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
          { headerName: 'Time at', field: 'time_at', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
          { headerName: 'Status', field: 'status', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
          { headerName: 'Status Description', field: 'status_description', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
          { headerName: 'Client Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getClientValue.bind(this) },
          { headerName: 'User Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getUserValue.bind(this) },
      ];
      this.gridApi.setColumnDefs(this.wizardColumnDefs);
      this.gridApi.refreshHeader();
  
      const params = new HttpParams().set('client_pk', this.user.search_client_pk);
      this.mftService.loadData("load_wizard_log", params).subscribe(
          (data: HttpResponse<any>) => {
              let filteredData = data.body;
  
              if (this.startDate && this.endDate) {
                  filteredData = filteredData.filter((record: { time_at: Date; module_name: string; }) => {
                      const loginDate = new Date(record.time_at);
                      const startDate = new Date(this.startDate);
                      const endDate = new Date(this.endDate);
  
                      startDate.setHours(0, 0, 0);
                      endDate.setHours(23, 59, 59);
  
                      return loginDate >= startDate && loginDate <= endDate && record.module_name === 'Wizard';
                  });
              } else {
                  filteredData = filteredData.filter((record: { module_name: string; }) => record.module_name === 'Wizard');
              }
  
              this.gridApi.setRowData(filteredData);
              this.gridApi.refreshCells();
          },
          (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
  }

  else if (this.reportType == "ConditionalLogic_Log") {
    this.formulaColumnDefs = [
        { headerName: 'Module Name', field: 'module_name', sortable: true, filter: true, headerCheckboxSelection: true, checkboxSelection: true, resizable: true, minWidth: 450 },
        { headerName: 'Flow Name', field: 'flow_name', sortable: true, resizable: true, minWidth: 150, suppressMenu: true },
        { headerName: 'Previous Data', field: 'previous_data', sortable: true, resizable: true, minWidth: 250, suppressMenu: true },
        { headerName: 'Modified Data', field: 'modified_data', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
        { headerName: 'Time at', field: 'time_at', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
        { headerName: 'Status', field: 'status', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
        { headerName: 'Status Description', field: 'status_description', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
        { headerName: 'Client Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getClientValue.bind(this) },
        { headerName: 'User Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getUserValue.bind(this) },
    ];
    this.gridApi.setColumnDefs(this.formulaColumnDefs);
    this.gridApi.refreshHeader();

    const params = new HttpParams().set('client_pk', this.user.search_client_pk);
    this.mftService.loadData("load_wizard_log", params).subscribe(
        (data: HttpResponse<any>) => {
            let filteredData = data.body;
            
            if (this.startDate && this.endDate) {
                filteredData = filteredData.filter((record: { time_at: Date; module_name: string; }) => {
                    const loginDate = new Date(record.time_at);
                    const startDate = new Date(this.startDate);
                    const endDate = new Date(this.endDate);

                    startDate.setHours(0, 0, 0);
                    endDate.setHours(23, 59, 59);

                    return loginDate >= startDate && loginDate <= endDate && record.module_name === 'Conditional logic';
                });
            } else {
                filteredData = filteredData.filter((record: { module_name: string; }) => record.module_name === 'Conditional logic');
            }

            this.gridApi.setRowData(filteredData);
            this.gridApi.refreshCells();
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
}



else if (this.reportType == "Workflow_Log") {
  this.workflowColumnDefs = [
      { headerName: 'Module Name', field: 'module_name', sortable: true, filter: true, headerCheckboxSelection: true, checkboxSelection: true, resizable: true, minWidth: 450 },
      { headerName: 'Flow Name', field: 'flow_name', sortable: true, resizable: true, minWidth: 150, suppressMenu: true },
      { headerName: 'Previous Data', field: 'previous_data', sortable: true, resizable: true, minWidth: 250, suppressMenu: true },
      { headerName: 'Modified Data', field: 'modified_data', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
      { headerName: 'Time at', field: 'time_at', sortable: true, resizable: true, minWidth: 200, suppressMenu: true },
      { headerName: 'Status', field: 'status', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
      { headerName: 'Status Description', field: 'status_description', sortable: true, resizable: true, minWidth: 350, suppressMenu: true },
      { headerName: 'Client Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getClientValue.bind(this) },
      { headerName: 'User Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getUserValue.bind(this) },
  ];
  this.gridApi.setColumnDefs(this.workflowColumnDefs);
  this.gridApi.refreshHeader();

  const params = new HttpParams().set('client_pk', this.user.search_client_pk);
  this.mftService.loadData("load_wizard_log", params).subscribe(
      (data: HttpResponse<any>) => {
          let filteredData = data.body;
          
          if (this.startDate && this.endDate) {
              filteredData = filteredData.filter((record: { time_at: Date; module_name: string; }) => {
                  const loginDate = new Date(record.time_at);
                  const startDate = new Date(this.startDate); 
                  const endDate = new Date(this.endDate);

                  startDate.setHours(0, 0, 0);
                  endDate.setHours(23, 59, 59);

                  return loginDate >= startDate && loginDate <= endDate && record.module_name === 'Workflow';
              });
          } else {
              filteredData = filteredData.filter((record: { module_name: string; }) => record.module_name === 'Workflow');
          }

          this.gridApi.setRowData(filteredData);
          this.gridApi.refreshCells();
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
  );
}


    this.export_disable = true;
      };

      onSelectionChanged(event: SelectionChangedEvent) {
        const selectedData = this.gridApi.getSelectedRows();

        this.download_disable = true;
        this.export_disable = true;

        if (selectedData.length > 0) {
          this.export_disable = false;
        } else {
          this.export_disable = true;
        }

      }


      getClientValue(params: any) {
        let client = this.mftService.loggedInUser.getUser().client_list.find((client: { client_pk: any; }) => client.client_pk === params.data.client_pk);
        return client ? client.client_name : "";
      };


      getUserValue(params: any) {
        let user = this.mftService.loggedInUser.getUser().user_list.find((user: { user_pk: any; }) => user.user_pk === params.data.user_pk);
        return user ? user.user_name : "";
      };


  onArrowClick(): void {
    if (this.reportType) {
      let route = '';

      console.log('Selected Report Type:', this.reportType);

      switch (this.reportType) {
        case 'Folder_Report':
          route = 'etl/wizard';
          break;
        case 'File_Report':
          route = 'etl/logic';
          break;
        case 'Formula_Report':
          route = 'etl/workflowdesigner';
          break;
        default:
          return;
      }

      this.router.navigate([route]);
    } else {
      console.log('No report type selected');
    }
  }

  onReportTypeChange(event: any) {
    this.loadChangedReportWithDateFilter();
    this.reportType = event.target.value;
    this.showIcons = true;
  }

  


}
