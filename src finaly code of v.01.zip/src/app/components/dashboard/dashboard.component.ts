import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { MftService } from 'src/app/services/mft.service';
import { Chart } from 'chart.js';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { Users } from 'src/app/models/users';
import { BaseComponent } from '../base/base.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { switchMap } from 'rxjs';
import { ApexOptions } from 'ng-apexcharts';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent extends BaseComponent implements OnInit {
  
  public user = { user_pk: '', client_pk: '', search_client_pk: '', search_trigger_pk: '', role_pk: '', user_id: '', user_name: '', user_status: '', user_locked: '', user_creation_date: '', user_activation_date: '', user_deactivation_date: '', user_phone_no: '', user_email: '', user_password: '', user_confirm_password: '', user_description: '', };
  countString: string;
  dateRange: string;
  xCategories: any;
  yData: any;
  xLogin: string[] = [];
  yLogin: number[] = [];
  timeRangeData: any;
  customDate: string;
  @ViewChild("filetransfermodel") fileTransferTemplateRef: TemplateRef<any>;

  constructor(private mftServices: MftService, private loggedInUser: Users, private usersService: Users, public override modalService: NgbModal) {
    super(modalService);
  }
  filesColumnDefs: any;
  // schedulerColumnDefs: any;
  triggerColumnDefs: any;
  RowData: any;  
  AgLoad: boolean = true;
  filesGridApi: any;  
  //schedulerGridApi: any;
  triggerGridApi: any;
  IsColumnsToFit: boolean = false;
  property1: any[];
  loginGraphData: any[];
  user_id_data: string;
  userIdArray:string[];
  user_loggedin_at_data: string;
  user_loggedin_at_data_array:string[];
  convertedDate: string[]; 
  userIdData: string[];
  userLoggedInAtStrings: string[];
  convertedUserLoggedInAtData: any[];
  chartOptions: ApexOptions = { }
  fileTransferAtArray: string[] = [];
  fileTransferStatusArray: string[] = [];
  xLabelArrayCategory: string = '';
  xDataArrayCategory: string[] = [];
  countArrayCategory: number[] = [];
  series: { name: string; data: any[] }[] = [];
  dateDate: any[] = [];
  showCustomRange: boolean = false;
  convertedDateArray:any;

  chartData: { name: string; data: any }[];
  xDate: any;
  dateForm:FormGroup;

  clearChartDataAndXDate(): void {
    this.chartData = [];
    this.xDate = [];
  }

  public chart: any;
  lineChart: any;
  barChart: any;
  @ViewChild('mychart') mychart: any;
  userData: any;
  success_count: number;
  failure_count: number;
  monthly_count: number;

  ngOnInit() {
    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      this.createChart();
      this.loginGraph();
      const httpParams = new HttpParams().set('client_pk', this.userData.role_id === 'SYS_ADMIN' ? '%' : this.userData.client_pk);
      this.mftServices.loadData("dashboard_info", httpParams).subscribe(
        (data: HttpResponse<any>) => {
          this.success_count = data.body.success_count;
          this.failure_count = data.body.failure_count;
          this.monthly_count = data.body.monthly_count;
        }, 
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    });

    this.filesColumnDefs = [
      { headerName: 'File Name', field: 'file_name', sortable: true, filter: true, resizable: true, minWidth: 250 },  
      { headerName: 'File Size', field: 'file_size', sortable: true, filter: true, resizable: true, minWidth: 80, valueFormatter: this.nameValueFormatter.bind(this) },
      { headerName: 'File Transfer Status', field: 'file_transfer_status', sortable: true, filter: true, resizable: true, minWidth: 100 },
      { headerName: 'File Transfered at', field: 'file_transfer_at', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'File Transfer Remarks', field: 'file_transfer_failure_reason', sortable: true, filter: true, resizable: true, minWidth: 200 }
    ];
    
    this.triggerColumnDefs = [
      { headerName: 'Trigger Audit PK', field: 'trigger_audit_pk', center: true , hide: true },
      { headerName: 'Job Id', field: 'trigger_audit_pk', sortable: true, filter: true, resizable: true, minWidth: 150, cellRenderer: this.createHyperLink.bind(this), comparator: (a: number, b: number) => a > b ? 1 : (a < b ? -1 : 0) },
      { headerName: 'Trigger ID', field: 'trigger_pk', sortable: true, filter: true, minWidth: 150, resizable: true, valueGetter: this.getTriggerIDValue.bind(this) },
      { headerName: 'Start Time', field: 'trigger_start_time', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'End Time', field: 'trigger_end_time', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Trigger Type', field: 'trigger_type', sortable: true, filter: true, resizable: true, minWidth: 200, valueGetter: this.getTriggerType.bind(this) },
      { headerName: 'Status', field: 'trigger_status', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Failure Reason', field: 'trigger_failure_reason', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'Success count', field: 'no_of_files_transferred', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'Failure count', field: 'no_of_files_failed', sortable: true, filter: true, resizable: true, minWidth: 150 },
    ];
  }

  getTriggerType(params: any) {
    if (params.data.trigger_type) {
      if (params.data.trigger_type.includes('SCHEDULER')) {
        return 'SCHEDULER';
      } else {
        return 'MANUAL';
      }
    } else {
      return '-';
    }
  }

  getTriggerIDValue(params: any) {
    return 'HTIT-' + '0'.repeat(4 - params.data.trigger_pk.toString().length) + params.data.trigger_pk;
  }

  createChart() {
    const httpParams = new HttpParams().set('client_pk', this.usersService.getClientPK());
    this.mftServices.loadData("file_audit_data", httpParams).subscribe(
      (response: HttpResponse<any>) => {
        const data = response.body;
        this.property1 = data;
  
        data.forEach((item: { [x: string]: string; }) => {
          const fileTransferAt: string = item["File Transfer At"];
          const dateWithoutTime = fileTransferAt.split(' ')[0];
          this.fileTransferAtArray.push(dateWithoutTime);
          const fileTransferStatus: string = item["File Transfer Status"];
          this.fileTransferStatusArray.push(fileTransferStatus);
        });
  
        if (this.fileTransferAtArray.length === this.fileTransferStatusArray.length) {
          const pairCounts: { [key: string]: number } = {};
  
          for (let i = 0; i < this.fileTransferAtArray.length; i++) {
            const pair = `${this.fileTransferAtArray[i]} - ${this.fileTransferStatusArray[i]}`;
            pairCounts[pair] = (pairCounts[pair] || 0) + 1;
          }
  
          const xCategories: string[] = [];
          const yData: number[] = [];
          const maxDataPoints = 7;
  
          for (const pair in pairCounts) {
            if (pair.endsWith(' - SUCCESS')) {
              // Extract the date without ' - SUCCESS'
              const datePart = pair.replace(' - SUCCESS', '');
              const count = pairCounts[pair];
  
              // Add the data to xCategories and yData
              xCategories.push(datePart);
              yData.push(count);
  
              if (xCategories.length > maxDataPoints) {
                // Remove the oldest data point if it exceeds the maximum
                xCategories.shift();
                yData.shift();
              }
            }
          }

          this.lineChart = new Chart("Chart", {
            type: 'line',
            data: {
              labels: xCategories,
              datasets: [
                {
                  label: "Transferred Files",
                  data: yData,
                  tension: 0.4,
                  borderWidth: 3,
                  pointRadius: 3,
                  borderColor: '#5E72E4',
                  backgroundColor: 'rgba(94, 114, 228, 0.2)',
                  fill: true
                }
              ]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: true,
                  onClick: function(event, legendItem) {
                    // Do nothing on legend item click
                  }
                }
              },
              interaction: {
                intersect: false,
                mode: 'index'
              },
              scales: {
                y: {
                  grid: {
                    display: true,
                    drawOnChartArea: true,
                    drawTicks: false
                  },
                  ticks: {
                    display: true,
                    font: {
                      size: 11,
                      family: "inherit",
                      lineHeight: 2
                    }
                  }
                },
                x: {
                  grid: {
                    display: false,
                    drawOnChartArea: false,
                    drawTicks: false
                  },
                  ticks: {
                    display: true,
                    font: {
                      size: 12,
                      family: "inherit",
                      lineHeight: 2
                    }
                  }
                }
              }
            }
          });
        }
      }
    );
  }
  
  filesBindData(params: any) {  
    this.filesGridApi = params.api;

  /* schedulerBindData(params: any) {  
    this.schedulerGridApi = params.api;  
    //this.gridColumnApi = params.columnApi;  
    //params.api.setRowData(this.RowData);  

    const httpParams = new HttpParams().set('client_pk', this.userData.role_id === 'SYS_ADMIN' ? '%' : this.userData.client_pk);
    this.mftServices.loadData("scheduler_list", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.schedulerGridApi.setRowData(data.body);
        this.schedulerGridApi.refreshCells();
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  } */
  }

  triggerDataBind(params: any) {  
    this.triggerGridApi = params.api;  
    const httpParams = new HttpParams().set('client_pk', this.userData.role_id === 'SYS_ADMIN' ? '%' : this.userData.client_pk).set('show_all_jobs', 'false');
    this.mftServices.loadData("dashboard_job_list", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.triggerGridApi.setRowData(data.body);
        this.triggerGridApi.refreshCells();
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  loginGraph() {
    this.mftServices.data$.pipe(
        switchMap(() => {
          this.userData = this.loggedInUser.getUser();
  
          if (this.userData.role_id === 'SYS_ADMIN') {
            this.user.search_client_pk = "%";
          } else {
            this.user.search_client_pk = this.userData.client_pk;
          }
  
          const params = new HttpParams().set('client_pk', this.user.search_client_pk);
          return this.mftServices.loadData("user_login_list", params);
        })
      )
      .subscribe(
        (data: HttpResponse<any>) => {
          if (data && data.body) {
            this.loginGraphData = data.body;

            this.user_id_data = this.loginGraphData.filter(item => item.user_loggedin_status === 'Authentication Success').map(item => item.user_id).join(',');
            
            this.userIdArray = this.user_id_data.split(',');
            this.user_loggedin_at_data = this.loginGraphData
            .filter(item => item.user_loggedin_status === 'Authentication Success')
            .map(item => item.user_loggedin_at)
            .join(', ');          
            this.user_loggedin_at_data_array = this.user_loggedin_at_data.split(', ');
            this.processDataForVisualization();
          } else {
            console.error('Data or data.body is undefined');
          }
        },
        (httpError) => {
          if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
            this.popupModalService.openTimeoutModal();
          } else {
            console.error('There was an error!', httpError.message);
          }
        }
      );
  }

  nameValueFormatter(params:any) {
    return params.value + " Bytes";
  };

  jobIDFormatter(params:any) {
    return 'JOB-' + '0'.repeat(5 - params.data.trigger_audit_pk.toString().length) + params.data.trigger_audit_pk;
  };

  createHyperLink(params: any) {
    if (!params.data) { return document.createElement('span'); }
    const spanElement = document.createElement('span');
    spanElement.innerHTML = `<a href="#"> ${'JOB-' + '0'.repeat(5 - params.data.trigger_audit_pk.toString().length) + params.data.trigger_audit_pk} </a> `;
    spanElement.addEventListener('click', ($event) => {
      $event.preventDefault();
  
      const httpParams = new HttpParams().set('trigger_audit_pk', params.data.trigger_audit_pk).set('show_limited_data', false);
      this.mftServices.loadData("file_list_by_job_id", httpParams).subscribe(
        (data: HttpResponse<any[]>) => {
          const newTab = window.open();
          if (newTab) {    
            if (data.body !== null && data.body !== undefined) {
              newTab.document.write('<html>');
  
              newTab.document.write('<head>');
              newTab.document.write('<title>MFT : ' + 'JOB-' + '0'.repeat(5 - params.data.trigger_audit_pk.toString().length) + params.data.trigger_audit_pk + '</title>');
              newTab.document.write('<style>');
              newTab.document.write('body { margin: 0; padding: 0; min-height: 100vh; display: flex; flex-direction: column; }');
              newTab.document.write('html, body { height: 100%; }');
              newTab.document.write('main { flex: 1; }');
              newTab.document.write('table { border-collapse: collapse; width: 100%; }');
              newTab.document.write('th, td { border: 1px solid #dddddd; text-align: left; font-family: Roboto,sans-serif; padding: 8px; }');
              newTab.document.write('th { background-color: #f2f2f2; }');
              newTab.document.write('</style>');
              newTab.document.write('</head>');
  
              newTab.document.write('<body>');
              newTab.document.write('<div style="display: flex">');
              newTab.document.write('<div style="width: 30%; margin: 2px 2px 2px 10px;">');
              newTab.document.write('<img src="/assets/images/HephzibahTechnologiesLogo.png" style="width: 75px">');
              newTab.document.write('</div>');
              newTab.document.write('</div>');
              newTab.document.write('<h2 style="color: #ffffff;font-size: 18px; background-color: #4c6fbf;font-family: Roboto,sans-serif; padding: 10px;margin-top:5px; text-align: left;">MFT-Files Transferred for : ' + 'JOB-' + '0'.repeat(5 - params.data.trigger_audit_pk.toString().length) + params.data.trigger_audit_pk + '</h2>');
  
              newTab.document.write('<main>');
              newTab.document.write('<table>');
              newTab.document.write('<thead><tr>');
              this.filesColumnDefs.forEach((colDef: any) => {
                newTab.document.write('<th>' + colDef.headerName + '</th>');
              });
              newTab.document.write('</tr></thead><tbody>');
  
              data.body.forEach((obj: any) => {
                newTab.document.write('<tr>');
                this.filesColumnDefs.forEach((colDef: any) => {
                  newTab.document.write(`<td>${obj[colDef.field]}</td>`);
                });
                newTab.document.write('</tr>');
              });    
  
              newTab.document.write('</tbody></table>');
              newTab.document.write('</main>');
  
              newTab.document.write('<footer style="text-align: center; width: 100%; color: black; background-color: #f2f2f2;font-family: Roboto,sans-serif; display: initial;">');
              newTab.document.write('<p>&copy; Copyright 2024 - Hephzibah Technologies Inc - All Rights Reserved.</p>');
              newTab.document.write('</footer>');
              newTab.document.write('</body></html>');
            } else {
              console.error('Data body is null or undefined.');
            }
  
            newTab.document.close();
          } else {
            console.error('Failed to open a new tab. Please check your popup settings.');
          }
        },
        (httpError: HttpErrorResponse) => {
          console.error('HTTP error:', httpError);
        }
      );

    });
    return spanElement;
  }

  processDataForVisualization() {
    this.convertedDate = (this.user_loggedin_at_data_array as string[]).map(originalDate => {
      const dateObject = new Date(originalDate);
      if (isNaN(dateObject.getTime())) {
        return "Invalid Date";
      }
      const mm = String(dateObject.getMonth() + 1).padStart(2, "0");
      const dd = String(dateObject.getDate()).padStart(2, "0");
      const yyyy = dateObject.getFullYear();
    
      return `${mm}/${dd}/${yyyy}`;
    });
    
    const currentDate = new Date();
    const sevenDaysAgo = new Date(currentDate);
    sevenDaysAgo.setDate(currentDate.getDate() - 6);
    sevenDaysAgo.setHours(0, 0, 0); 
    
    const validConvertedDate = this.convertedDate.filter(date => {      
      const dateObject = new Date(date);
      return !isNaN(dateObject.getTime()) && dateObject >= sevenDaysAgo;
    });
    
    const nameAndDayGroups = new Map();
    
    for (let i = 0; i < validConvertedDate.length; i++) {
      const originalDate = validConvertedDate[i];
      const [month, day, year] = originalDate.split('/');
      const formattedDate = `${year}-${month}-${day}`;
      const name = this.userIdArray[i];
    
      if (!nameAndDayGroups.has(name)) {
        nameAndDayGroups.set(name, new Map());
      }
    
      if (!nameAndDayGroups.get(name).has(formattedDate)) {
        nameAndDayGroups.get(name).set(formattedDate, 0);
      }
    
      nameAndDayGroups.get(name).set(formattedDate, nameAndDayGroups.get(name).get(formattedDate) + 1);
    }
    const allDays = Array.from(new Set(validConvertedDate.map(date => {
      const [month, day, year] = date.split('/');
      return `${year}-${month}-${day}`;
    })));
    
    const chartData = Array.from(nameAndDayGroups.keys()).map(
      (name) => {
        const dayCounts = nameAndDayGroups.get(name);
        const userData = allDays.map((day) => {
          const count = dayCounts.get(day) || 0;
          return {
            name: day,
            data: count,
          };
        });
        return {
          name,
          data: userData.map(entry => entry.data),
        };
      }
    );
        
    this.chartOptions = {
      series:chartData,
      chart: {
        type: "bar",
        height: 200
      },
      plotOptions: {
        bar: {
          horizontal: false,
          dataLabels: {
            position: "hide"
          }
        }
      },
      dataLabels: {
        enabled: true,
        offsetX: -6,
        style: {
          fontSize: "12px",
          colors: ["#fff"]
        }
      },
      stroke: {
        show: true,
        width: 1,
        colors: ["#fff"]
      },
      xaxis: {
        categories:allDays
      },
      legend: {
        position: "right",
      },
    };
    }    

    monthlyLogincount(){
      this.convertedDate = (this.user_loggedin_at_data_array as string[]).map(originalDate => {
        const dateObject = new Date(originalDate);
        if (isNaN(dateObject.getTime())) {
          return "Invalid Date";
        }
        const mm = String(dateObject.getMonth() + 1).padStart(2, "0");
        const dd = String(dateObject.getDate()).padStart(2, "0");
        const yyyy = dateObject.getFullYear();
      
        return `${mm}/${dd}/${yyyy}`;
      });
      
      const validConvertedDate = this.convertedDate.filter(date => date !== "Invalid Date");
      const nameAndMonthGroups = new Map();
      
      for (let i = 0; i < validConvertedDate.length; i++) {
        const originalDate = validConvertedDate[i];
        const [month, day, year] = originalDate.split('/');
        const formattedDate = `${year}-${month}`;
        const name = this.userIdArray[i];
      
        if (!nameAndMonthGroups.has(name)) {
          nameAndMonthGroups.set(name, new Map());
        }
      
        if (!nameAndMonthGroups.get(name).has(formattedDate)) {
          nameAndMonthGroups.get(name).set(formattedDate, 0);
        }
      
        nameAndMonthGroups.get(name).set(formattedDate, nameAndMonthGroups.get(name).get(formattedDate) + 1);
      }
      
      const allMonths = Array.from(new Set(validConvertedDate.map(date => {
        const [month, day, year] = date.split('/');
        return `${year}-${month}`;
      })));
      const convertedMonthsArray = allMonths.map((month) => {
        const [year, monthNumber] = month.split('-');
        const monthName = new Date(`${year}-${monthNumber}-01`).toLocaleString('en-US', { month: 'long' });
        return `${year}-${monthName.toLowerCase()}`;
      });
      
      const chartData = Array.from(nameAndMonthGroups.keys()).map(
        (name) => {
          const monthCounts = nameAndMonthGroups.get(name);
          const userData = allMonths.map((month) => {
            const count = monthCounts.get(month) || 0;
            return {
              name: month,
              data: count,
            };
          });
          return {
            name,
            data: userData.map(entry => entry.data),
          };
        }
      );
      
      this.chartOptions = {
        series:chartData,
        chart: {
          type: "bar",
          height: 200
        },
        plotOptions: {
          bar: {
            horizontal: false,
            dataLabels: {
              position: "hide"
            }
          }
        },
        dataLabels: {
          enabled: true,
          offsetX: -6,
          style: {
            fontSize: "12px",
            colors: ["#fff"]
          }
        },
        stroke: {
          show: true,
          width: 1,
          colors: ["#fff"]
        },
        xaxis: {
          categories:convertedMonthsArray
        },
        legend: {
          position: "right",
        },
      };
    }
    yearlyLogincount(){
      this.convertedDate = (this.user_loggedin_at_data_array as string[]).map(originalDate => {
        const dateObject = new Date(originalDate);
        if (isNaN(dateObject.getTime())) {
          return "Invalid Date";
        }
        const yyyy = dateObject.getFullYear();
      
        return `${yyyy}`;
      });
      
      const validConvertedDate = this.convertedDate.filter(date => date !== "Invalid Date");
      const nameAndYearGroups = new Map();
      
      for (let i = 0; i < validConvertedDate.length; i++) {
        const originalDate = validConvertedDate[i];
        const formattedDate = originalDate;
        const name = this.userIdArray[i];
      
        if (!nameAndYearGroups.has(name)) {
          nameAndYearGroups.set(name, new Map());
        }
      
        if (!nameAndYearGroups.get(name).has(formattedDate)) {
          nameAndYearGroups.get(name).set(formattedDate, 0);
        }
      
        nameAndYearGroups.get(name).set(formattedDate, nameAndYearGroups.get(name).get(formattedDate) + 1);
      }    
      const allYears = Array.from(new Set(validConvertedDate));
      
      const chartData = Array.from(nameAndYearGroups.keys()).map(
        (name) => {
          const yearCounts = nameAndYearGroups.get(name);
          const userData = allYears.map((year) => {
            const count = yearCounts.get(year) || 0;
            return {
              name: year,
              data: count,
            };
          });
          return {
            name,
            data: userData.map(entry => entry.data),
          };
        }
      );    
      
      this.chartOptions = {
        series:chartData,
        chart: {
          type: "bar",
          height: 200
        },
        plotOptions: {
          bar: {
            horizontal: false,
            dataLabels: {
              position: "hide"
            }
          }
        },
        dataLabels: {
          enabled: true,
          offsetX: -6,
          style: {
            fontSize: "12px",
            colors: ["#fff"]
          }
        },
        stroke: {
          show: true,
          width: 1,
          colors: ["#fff"]
        },
        xaxis: {
          categories:allYears
        },
        legend: {
          position: "right",
        },
      };
    }
    onSubmit() {
      const startDate = this.dateForm.get('startDate')?.value;
      const endDate = this.dateForm.get('endDate')?.value;
    }


    custoumRange(){
      const userIdData = this.userIdData;
      const originalDates = this.convertedUserLoggedInAtData;
      
      function convertDateFormat(originalDateString: string): string {
        const [day, month, year] = originalDateString.split('/');
        return `${month}/${day}/${year}`;
      }
      
      const startDate = new Date('12/01/2023');
      const endDate = new Date('12/03/2023');

      const dateNamePairs = originalDates.map((date, index) => ({ date, name: userIdData[index] }));
      
      const allDates = [];
      for (let currentDate = startDate; currentDate <= endDate; currentDate.setDate(currentDate.getDate() + 1)) {
        allDates.push(currentDate.toLocaleDateString());
      }
      const xData = [...new Set(allDates)];
    
      const monthAndNameGroups = new Map();
      for (const name of userIdData) {
        monthAndNameGroups.set(name, new Map());
        for (const date of allDates) {
          monthAndNameGroups.get(name).set(date, []);
        }
      }
      
      dateNamePairs.forEach(pair => {
        const formattedDate = convertDateFormat(pair.date);
        const month = new Date(formattedDate).toLocaleDateString();
        if (monthAndNameGroups.has(pair.name) && monthAndNameGroups.get(pair.name).has(month)) {
          monthAndNameGroups.get(pair.name).get(month).push(formattedDate);
        }
      });
      
      const chartData = Array.from(monthAndNameGroups.entries()).map(
        ([name, nameGroups]) => {
          const userData = Array.from(nameGroups.entries()).map(([date, dates]: any) => ({
            name: date,
            data: dates.length,
          }));
          return {
            name,
            data: userData.map(entry => entry.data),
          };
        }
      );
            
      this.chartOptions = {
        series:chartData,
        chart: {
          type: "bar",
          height: 200
        },
        plotOptions: {
          bar: {
            horizontal: false,
            dataLabels: {
              position: "hide"
            }
          }
        },
        dataLabels: {
          enabled: true,
          offsetX: -6,
          style: {
            fontSize: "12px",
            colors: ["#fff"]
          }
        },
        stroke: {
          show: true,
          width: 1,
          colors: ["#fff"]
        },
        xaxis: {
          categories:xData
        }
      };
      
    }

}
