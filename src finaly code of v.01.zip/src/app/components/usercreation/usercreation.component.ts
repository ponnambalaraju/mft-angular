import { Component, Output, EventEmitter } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SelectionChangedEvent } from 'ag-grid-community';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BaseComponent } from '../base/base.component';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-usercreation',
  templateUrl: './usercreation.component.html',
  styleUrls: ['./usercreation.component.css']
})

export class UsercreationComponent extends BaseComponent {

  user_phone_no_error: any;
  button_disable: boolean = true;
  password_disable: boolean = true;
  userunlock_disable: boolean = true;
  popup_role_client_disable: boolean = false;

  constructor(public override modalService: NgbModal) {
    super(modalService);
  }

  separateDialCode = false;
	SearchCountryField = SearchCountryField;
	CountryISO = CountryISO;
  PhoneNumberFormat = PhoneNumberFormat;
	preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.India];

	changePreferredCountries() {
		this.preferredCountries = [CountryISO.UnitedStates, CountryISO.India];
	}

  @Output() passEntry: EventEmitter<any> = new EventEmitter();
  usersColumnDefs: any;
  RowData: any;  
  AgLoad: boolean = true;
  rowSelection: 'single' | 'multiple' = 'single';
  rowMultiSelectWithClick: true;
  gridApi: any;
  gridColumnApi: any;
  //clientOptions: any[] = [];
  //allClientOptions: any[] = [];
  departmentOptions: any[] = [];
  tempDepartmentOptions: any[] = [];
  projectOptions: any[] = [];
  tempProjectOptions: any[] = [];
  roleOptions: any[];
  tempRoleOptions: any[];
  authenticationTypeOptions: any[];
  processSelected: any;
  public user = { search_client_pk: '' };
  allow_downloading_files: boolean;

  ngOnInit() {
    this.usersColumnDefs = [
      { headerName: 'User PK', field: 'user_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'User ID', field: 'user_id', sortable: true, filter: true, resizable: true, minWidth: 130, headerCheckboxSelection: true, checkboxSelection: true },  
      { headerName: 'User Name', field: 'user_name', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'User Email', field: 'user_email', sortable: true, filter: true, resizable: true, minWidth: 225 },
      { headerName: 'User Status', field: 'user_status', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'User Locked', field: 'user_locked', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'User Creation Date', field: 'user_creation_date', sortable: true, filter: true, resizable: true, minWidth: 225 },  
      { headerName: 'User Activation Date', field: 'user_activation_date', sortable: true, filter: true, resizable: true, minWidth: 225 },
      { headerName: 'User Deactivation Date', field: 'user_deactivation_date', sortable: true, filter: true, resizable: true, minWidth: 225 },
      { headerName: 'Client PK', field: 'client_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Client Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getClientValue.bind(this) },
      { headerName: 'Group PK', field: 'department_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Group Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getDepartmentValue.bind(this) },
      { headerName: 'Project PK', field: 'project_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Project Name', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getProjectValue.bind(this) },
      { headerName: 'Role PK', field: 'role_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Role', sortable: true, filter: true, resizable: true, minWidth: 150, valueGetter: this.getRoleValue.bind(this) },
      /* { headerName: 'Allow Downloading Reports', sortable: true, filter: true, resizable: true, minWidth: 250, valueGetter: this.getDownloadValue.bind(this) }, */
      { headerName: 'User Phone No', field: 'user_phone_no', sortable: true, filter: true, resizable: true, minWidth: 225 },
      { headerName: 'User Description', field: 'user_description', sortable: true, filter: true, resizable: true, minWidth: 200, maxWidth: 500 }
    ];

    const params = new HttpParams();

    this.mftService.loadData("load_roles", params).subscribe(
      (data: HttpResponse<any>) => {
        this.roleOptions = data.body;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );

    if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = "%";
    } else {
      this.user.search_client_pk = this.mftService.loggedInUser.getUser().client_pk;
    }
    this.loadDepartment(this.user.search_client_pk);
    this.loadProject(this.user.search_client_pk);

    this.popupModalService.showModal.subscribe((result :{ show: boolean, data: any }) => {
      if (result.show) {
        console.log('Modal opened in parent component');
      } else {
        console.log('Modal closed in parent component');
        if (this.processSelected === "createdepartment") {

          // Loop through the objects to add
          result.data.forEach((new_department: { department_pk: number; client_pk: number }) => {
            // Condition to check if the new object is not already present in the array
            let isObjectAlreadyPresent = this.departmentOptions.some(old_department => old_department.department_pk === new_department.department_pk && old_department.client_pk === new_department.client_pk);

            // If the object is not present, add it to the array
            if (!isObjectAlreadyPresent) {
              this.departmentOptions.push(new_department);
              this.tempDepartmentOptions.push(new_department);
            }
          });

          if (this.tempDepartmentOptions.length === 1) {
            this.userForm.controls['department_pk']?.setValue(this.tempDepartmentOptions[this.tempDepartmentOptions.length - 1].department_pk);
          }

        } else if (this.processSelected === "createproject") {

          // Loop through the objects to add
          result.data.forEach((new_project: { project_pk: number; department_pk: number; }) => {
            // Condition to check if the new object is not already present in the array
            let isObjectAlreadyPresent = this.projectOptions.some(old_project => old_project.project_pk === new_project.project_pk && old_project.department_pk === new_project.department_pk);

            // If the object is not present, add it to the array
            if (!isObjectAlreadyPresent) {
              this.projectOptions.push(new_project);
              this.tempProjectOptions.push(new_project);
            }
          });

          if (this.tempProjectOptions.length === 1) {
            this.userForm.controls['project_pk']?.setValue(this.tempProjectOptions[this.tempProjectOptions.length - 1].project_pk);
          }
        } else if (this.processSelected === "createclient") {
          console.log(result.data);
        }
      }
    });

    this.popupModalService.showMessageAlertPopupModal.subscribe((result :{ show: boolean }) => {
      if (!result.show) {
        this.userListSearch();
      }
    });
  };

  loadDepartment(client_pk: string) {
    const params = new HttpParams().set('client_pk', client_pk);
    this.mftService.loadData("department_list", params).subscribe(
      (data: HttpResponse<any>) => {
        this.departmentOptions = data.body;
        if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
          this.user.search_client_pk = "%";
        }
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  loadProject(client_pk: string) {
    const params = new HttpParams().set('client_pk', client_pk);
    this.mftService.loadData("project_list", params).subscribe(
      (data: HttpResponse<any>) => { 
        this.projectOptions = data.body;
        if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
          this.user.search_client_pk = "%";
        }
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  /* loadactiveclients(client_pk: string) {
    const params = new HttpParams().set('client_pk', client_pk);
    this.mftService.loadData("load_client_list", params).subscribe(
      (data: HttpResponse<any>) => { 
        this.allClientOptions = data.body;
        if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
          this.user.search_client_pk = "%";
          this.clientOptions = data.body.filter((item: { client_name: string; client_status: string }) => item.client_status === 'ACTIVE');
        } else {

          this.clientOptions = data.body.filter((item: { client_pk: number; client_status: string }) => item.client_pk !== 1 && item.client_status === 'ACTIVE');
        }
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }; */

  userDataBind(params: any) {  
    this.gridApi = params.api;  
    this.gridColumnApi = params.columnApi;
    this.userListSearch();
  }

  userListSearch() {
    let temp_search_client_pk;
    if (this.user.search_client_pk === "") {
      temp_search_client_pk = "%";
    } else {
      temp_search_client_pk = this.user.search_client_pk;
    }
    const params = new HttpParams().set('client_pk', temp_search_client_pk);
    
    this.mftService.loadData("userlist", params).subscribe(
      (data: HttpResponse<any>) => {
        if (this.mftService.loggedInUser.getUser().user_id === 'Administrator') {
          this.gridApi.setRowData(data.body);
        } else if (this.mftService.loggedInUser.getUser().role_id === 'ORG_ADMIN' || this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
          this.gridApi.setRowData(data.body.filter((users: { user_id: string; }) => users.user_id !== 'Administrator'));
        } else {
          this.gridApi.setRowData(data.body.filter((users: { user_id: string; role_pk: number }) => users.user_id !== 'Administrator' && this.getRoleName(users.role_pk) !== 'ADMINISTRATOR'));
        }
        this.gridApi.refreshCells();
        this.active_disable = true;
        this.deactive_disable = true;
        this.edit_disable = true;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  onSelectionChanged(event: SelectionChangedEvent) {
    const selectedData = this.gridApi.getSelectedRows();
    
    this.active_disable = true;
    this.deactive_disable = true;
    this.edit_disable = true;
    this.password_disable = true;
    this.userunlock_disable= true;

    if (selectedData.length > 0) {
      const own_user_data = selectedData.some((row: any) => row.user_pk === this.mftService.loggedInUser.getUser().user_pk);
      const hasActive = selectedData.some((item: { user_status: string; }) => item.user_status === "ACTIVE");
      const hasDeactive = selectedData.some((item: { user_status: string; }) => item.user_status === "INACTIVE");
      const hasLocked = selectedData.some((item: { user_locked: string; }) => item.user_locked === "LOCKED");

      this.disableActiveDeactive(selectedData, hasActive, hasDeactive);
  
      if (hasActive && hasDeactive) {
        this.password_disable = true;
        this.userunlock_disable= true;
      } else if (hasActive) {
        if (selectedData.length > 1) {
          this.password_disable = true;
          this.userunlock_disable= true;
        } else {
          this.password_disable = false;
          if (hasLocked){
            this.userunlock_disable= false;
          } else {
            this.userunlock_disable= true;
          }
        }
      }
      if (own_user_data) {
        this.password_disable = true;
        this.userunlock_disable= true;
        this.active_disable = true;
        this.deactive_disable = true;
      }
    } else {
      this.edit_disable = true;
      this.password_disable = true;
      this.userunlock_disable = true;
      this.active_disable = true;
      this.deactive_disable = true;
    }
  }

  currentEvent: string;
  open(content: any, clickEvent: string) {
    this.userForm.get('client_pk')?.enable();
    this.userForm.get('role_pk')?.enable();
    this.submitted = false;
    this.currentEvent = clickEvent;
    if (clickEvent === "NEW") {
      this.userForm.patchValue({
        user_name: '', user_id: '',client_pk:'',authentication_type_pk:'', user_description: '', user_email: '', department_pk: '', project_pk: '', role_pk: '', user_phone_no: null
      });
      if (this.mftService.loggedInUser.getUser().client_list.length === 1) {
        this.userForm.get('client_pk')?.setValue(this.mftService.loggedInUser.getUser().client_list[0].client_pk);
        this.loadPopupDepartment(null);
      }
    }
    if (clickEvent === "EDIT") {
      this.authenticationTypeOptions = [];
      const selectedData = this.gridApi.getSelectedRows();

      const params = new HttpParams().set('client_pk', selectedData[0]["client_pk"]);
      this.mftService.loadData("load_authentication_types", params).subscribe(
        (data: HttpResponse<any>) => {
          this.authenticationTypeOptions = data.body;
          this.userForm.get('authentication_type_pk')?.setValue(this.gridApi.getSelectedRows()[0].authentication_type_pk);
          
          this.tempRoleOptions = this.roleOptions.filter(role => role.role_status === 'ACTIVE' && role.client_pk === selectedData[0]["client_pk"]);
          if (this.mftService.loggedInUser.getUser().role_id !== 'SYS_ADMIN') {
            this.tempRoleOptions = this.tempRoleOptions.filter(role => role.role_id !== 'SYS_ADMIN');
            if (this.mftService.loggedInUser.getUser().role_name !== 'ADMINISTRATOR') {
              this.tempRoleOptions = this.tempRoleOptions.filter(role => role.role_name !== 'ADMINISTRATOR');
            }
            this.popup_role_client_disable = selectedData.some((row: any) => row.user_pk === this.mftService.loggedInUser.getUser().user_pk);
            if (this.popup_role_client_disable) {
              this.userForm.get('client_pk')?.disable();
              this.userForm.get('role_pk')?.disable();
            } else {
              this.userForm.get('client_pk')?.enable();
              this.userForm.get('role_pk')?.enable();
            }
          }
    
          this.tempDepartmentOptions = this.departmentOptions.filter((department: { client_pk: string; department_status: string; }) => department.client_pk == selectedData[0]["client_pk"] && department.department_status === 'ACTIVE');
          this.tempProjectOptions = this.projectOptions.filter((project: { department_pk: string; project_status: string; }) => project.department_pk == selectedData[0]["department_pk"] && project.project_status === 'ACTIVE');
    
          this.userForm.patchValue({
            user_name: selectedData[0]["user_name"], user_id: selectedData[0]["user_id"], user_description: selectedData[0]["user_description"], user_email: selectedData[0]["user_email"],
            client_pk: selectedData[0]["client_pk"], department_pk: selectedData[0]["department_pk"], project_pk: selectedData[0]["project_pk"], role_pk: selectedData[0]["role_pk"], 
            user_phone_no: selectedData[0]["user_phone_no"].split(' ').join(' '), authentication_type_pk: selectedData[0]["authentication_type_pk"] 
          });
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
    const modalRef = this.modalService.open(content, {backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title'});
    modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  };

  save_user() {
    //this.userForm.get('user_phone_no')?.setValue(JSON.parse(JSON.stringify(this.userForm.value["user_phone_no"])).internationalNumber);
    this.onRoleChange();
    this.submitted = true;
    if (this.userForm.invalid) {
      return;
    }
    if (this.currentEvent === 'NEW') {
      let user_email_check: boolean = this.checkValueInColumn('user_email', this.userForm.value['user_email']);
      if (user_email_check) {
        alert("User Email already exist. Please provide valid User Email");
        return;
      }
      /* let user_id_check: boolean = this.checkValueInColumn('user_id', this.userForm.value['user_id']);
      if (user_id_check) {
        alert("User ID already exist. Please provide valid User ID");
        return;
      } */
    }

    /* let user_password: string = this.userForm.value['user_password'] ?? '';
    let user_confirm_password: string = this.userForm.value['user_confirm_password'] ?? '';

    if (user_password !== user_confirm_password) {
      alert("Password and Confirm Password do not match. Please make sure both fields have the same value");
      return;
    } */

    var formData: any = new FormData();
    formData.append('user_pk', this.currentEvent !== 'NEW' ? this.gridApi.getSelectedRows()[0]["user_pk"] : ''),
    formData.append('client_pk', this.userForm.value["client_pk"] !== undefined ? this.userForm.value["client_pk"] : this.gridApi.getSelectedRows()[0]["client_pk"]),
    formData.append('department_pk', this.userForm.value["department_pk"] !== null ? this.userForm.value["department_pk"] : ''),
    formData.append('project_pk', this.userForm.value["project_pk"] !== null ? this.userForm.value["project_pk"] : ''),
    formData.append('role_pk', this.userForm.value["role_pk"] !== undefined ? this.userForm.value["role_pk"] : this.gridApi.getSelectedRows()[0]["role_pk"]),
    formData.append('user_id', this.userForm.value["user_id"]),
    formData.append('user_name', this.userForm.value["user_name"]),
    formData.append('user_status', this.gridApi.getSelectedRows().length > 0 ? this.gridApi.getSelectedRows()[0]["user_status"] : ''),
    formData.append('user_creation_date', this.gridApi.getSelectedRows().length > 0 ? this.gridApi.getSelectedRows()[0]["user_creation_date"] : ''),
    formData.append('user_activation_date', this.gridApi.getSelectedRows().length > 0 ? this.gridApi.getSelectedRows()[0]["user_activation_date"] : ''),
    formData.append('user_deactivation_date', this.gridApi.getSelectedRows().length > 0 ? this.gridApi.getSelectedRows()[0]["user_deactivation_date"] : ''),
    formData.append('user_locked', this.gridApi.getSelectedRows().length > 0 ? this.gridApi.getSelectedRows()[0]["user_locked"] : ""),
    formData.append('user_email', this.userForm.value["user_email"]),
    formData.append('user_description', this.userForm.value["user_description"]),
    formData.append('user_phone_no', JSON.parse(JSON.stringify(this.userForm.value["user_phone_no"])).internationalNumber),
    formData.append('user_created_by', this.mftService.loggedInUser.getUser().user_created_by),
    formData.append('allow_downloading_files', this.userForm.value["allow_downloading_files"]),
    formData.append('mft_ui_address', this.mftService.mft_ui_address),
    formData.append('authentication_type_pk', this.userForm.value["authentication_type_pk"] !== null ? this.userForm.value["authentication_type_pk"] : '')

    this.mftService.postData("save_user", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.mftService.updatedAlert(data.body.result);
        this.userListSearch();
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
    this.modalService.dismissAll('Save User');
  };

  loadPopupDepartment(event: any) {

    var temp_client_pk: number;
    if (event === null) {
      temp_client_pk = this.mftService.loggedInUser.getUser().client_list[0].client_pk;
    } else {
      // temp_client_pk = parseInt(event.target.value.toString())
      temp_client_pk = parseInt(this.userForm.value['client_pk']!);
    }

    if (temp_client_pk !== 1) { 
      this.tempRoleOptions = this.roleOptions.filter(role => role.role_status === 'ACTIVE' && role.client_pk === temp_client_pk);
      if (this.mftService.loggedInUser.getUser().role_name !== 'ADMINISTRATOR') {
        this.tempRoleOptions = this.tempRoleOptions.filter(role => role.role_status === 'ACTIVE' && role.client_pk === temp_client_pk && role.role_name !== 'ADMINISTRATOR');
      }
    } else {
      this.tempRoleOptions = this.roleOptions.filter(role => role.role_status === 'ACTIVE' && role.client_pk === temp_client_pk);
      if (this.mftService.loggedInUser.getUser().role_id !== 'SYS_ADMIN') {
        this.tempRoleOptions = this.tempRoleOptions.filter(role => role.role_id !== 'SYS_ADMIN');
      }
    }

    this.tempRoleOptions = this.roleOptions.filter(role => role.role_status === 'ACTIVE' && role.client_pk === temp_client_pk);
    if (this.mftService.loggedInUser.getUser().role_id !== 'SYS_ADMIN') {
      this.tempRoleOptions = this.tempRoleOptions.filter(role => role.role_id !== 'SYS_ADMIN');
      if (this.mftService.loggedInUser.getUser().role_name !== 'ADMINISTRATOR') {
        this.tempRoleOptions = this.tempRoleOptions.filter(role => role.role_name !== 'ADMINISTRATOR');
      }
    }
    this.userForm.patchValue({
      department_pk: '', project_pk: '', role_pk: '',
    });
    this.tempDepartmentOptions = this.departmentOptions.filter((department: { client_pk: number; department_status: string; }) => department.client_pk == temp_client_pk && department.department_status === 'ACTIVE');
    if (this.tempDepartmentOptions.length === 1) {
      this.userForm.controls['department_pk']?.setValue(this.tempDepartmentOptions[0].department_pk);
      this.tempProjectOptions = this.projectOptions.filter((project: { department_pk: string; project_status: string; }) => project.department_pk == this.tempDepartmentOptions[0].department_pk && project.project_status === 'ACTIVE');
      if (this.tempProjectOptions.length === 1) {
        this.userForm.controls['project_pk']?.setValue(this.tempProjectOptions[0].project_pk);
        this.userForm.get('project_pk')?.setValue(this.tempProjectOptions[0].project_pk);
      }
      this.userForm.patchValue({
        department_pk: '', project_pk: '', role_pk: '',
      });
    } else if (this.tempDepartmentOptions.length > 1) {
      this.tempProjectOptions = this.projectOptions.filter((project: { department_pk: string; project_status: string }) => project.department_pk == this.tempDepartmentOptions[0].department_pk && project.project_status === 'ACTIVE');
    } else {
      this.tempProjectOptions = [];
    }
    this.userForm.patchValue({
      department_pk: '', project_pk: '', role_pk: '',
    });

    /* const roles_params = new HttpParams().set('client_pk', event.target.value);
    this.mftServices.loadData("load_client_roles", roles_params).subscribe(
      (data: HttpResponse<any>) => {
        this.roleOptions = data.body;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    ); */
    
    const params = new HttpParams().set('client_pk', temp_client_pk.toString());
    this.mftService.loadData("load_authentication_types", params).subscribe(
      (data: HttpResponse<any>) => {
        this.authenticationTypeOptions = data.body;
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  loadPopupProject(event: any) {
    this.tempProjectOptions = this.projectOptions.filter((project: { department_pk: string; project_status: string }) => project.department_pk == event.target.value && project.project_status === 'ACTIVE');
  };

  user_selection(user_selection: string, selection_method: string) {

    const selectedActiveValues = this.gridApi.getSelectedRows().map((row: any) => row['user_pk']);
    if (user_selection === 'User Unlock') {
      if (this.gridApi.getSelectedRows().length === 0) { 
        var data = { process: 'Message', modalMessage: 'Please select the user to unlock', yesButtonText: 'OK', isNoVisible: false };
        this.popupModalService.openMessageAlertPopupModal(data); return;
      }
      if (this.gridApi.getSelectedRows().length !== 0) {
        const selectedActiveValues = this.gridApi.getSelectedRows()
          .filter((row: any) => row['user_locked'] === 'LOCKED')
          .map((row: any) => row['user_locked']);

        if (selectedActiveValues.length === 0) {
          var popup_data = { process: 'Message', modalMessage: 'All users are not locked', yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
        }
        if (this.gridApi.getSelectedRows().length !== selectedActiveValues.length) {
          var popup_data = { process: 'Message', modalMessage: 'All are not in same state', yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
        }
      }
    }
    
    for (var i = 0; i < selectedActiveValues.length; i++) {
      var formData: any = new FormData();
      formData.append('user_pk', selectedActiveValues[i]),
      formData.append('mft_ui_address', this.mftService.mft_ui_address)
      
      this.mftService.postData(selection_method, formData).subscribe(
        (data: HttpResponse<any>) => {
          if (data.body.result === 'SUCCESS') {
            if (user_selection === 'Password Reset') {
              this.mftService.updatedAlert(user_selection + " link sent to mail successfully");
            } else if (user_selection === 'User Unlock') {
              this.mftService.updatedAlert(user_selection + "ed successfully");
              this.userListSearch();
            } else {
              this.mftService.updatedAlert("Action failed...");
            }
          }
        },
        (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
      );
    }
  };

  userForm = new FormGroup({
    user_name: new FormControl('', [Validators.required, Validators.maxLength(30),Validators.pattern(/^[a-zA-Z0-9_ ]{2,}$/)]),
    user_id: new FormControl('', []),
    user_description: new FormControl('', [Validators.maxLength(100)]),
    user_email:new FormControl ('',[Validators.required, Validators.maxLength(45), Validators.pattern('[a-z0-9._]+@[a-z0-9.-]+\\.[a-z]{2,}$')]),
    client_pk:new FormControl('',[Validators.required]),
    department_pk:new FormControl('',[Validators.required]),
    project_pk:new FormControl('',[Validators.required]),
    role_pk:new FormControl('',[Validators.required]),
    user_phone_no: new FormControl('', [Validators.required]),
    //user_password: new FormControl ('', [Validators.required, Validators.minLength(8)]),
    //user_confirm_password: new FormControl ('', Validators.required),
    allow_downloading_files:  new FormControl ('', []),
    authentication_type_pk:new FormControl('',[])
  });

  checkValueInColumn(columnId: string, searchValue: any): boolean {
    let duplicateFound = false;
    this.gridApi.forEachNode((node: any) => {
      const cellValue = this.gridApi.getValue(columnId, node);
      if (cellValue === searchValue) {
        duplicateFound = true;
        return; // Exit the forEachNode loop early if the value is found
      }
    });
    return duplicateFound;
  };

  getClientValue(params: any) {
    let client = this.mftService.loggedInUser.getUser().client_list.find((client: { client_pk: any; }) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  };

  getDepartmentValue(params: any) {
    let department = this.departmentOptions.find(department => department.department_pk === params.data.department_pk);
    return department?department.department_name:"";
  };
  
  getProjectValue(params: any) {
    let project = this.projectOptions.find(project => project.project_pk === params.data.project_pk);
    return project?project.project_name:"";
  };

  getRoleValue(params: any) {
    let role = this.roleOptions.find(role => role.role_pk === params.data.role_pk);
    return role?role.role_name:"";
  };

  getRoleName(role_pk: any) {
    let role = this.roleOptions.find(role => role.role_pk === role_pk);
    return role?role.role_name:"";
  };

  getDownloadValue(params: any) {
    if (params.data.allow_downloading_files == true) { return "Yes"; } else { return "No"; }
  };

  showAsterisk: boolean = true;
  onRoleChange() {
    let rolePkValue: number = parseInt(this.userForm.get('role_pk')?.value!);
    let roleNameValue = "";
    if (this.userForm.get('role_pk')?.value !== "") {
      roleNameValue = this.roleOptions.find(role => role.role_pk === rolePkValue)?.role_name || "";
    }
    this.showAsterisk = !(roleNameValue === 'ADMINISTRATOR' || roleNameValue === 'SYSTEM ADMINISTRATOR');
    this.userForm.get('department_pk')?.setValidators([Validators.required]);
    this.userForm.get('project_pk')?.setValidators([Validators.required]);
    if (roleNameValue === 'ADMINISTRATOR' || roleNameValue === 'SYSTEM ADMINISTRATOR') {
      this.userForm.get('department_pk')?.clearValidators();
      this.userForm.get('project_pk')?.clearValidators();
    }
    this.userForm.get('department_pk')?.updateValueAndValidity();
    this.userForm.get('project_pk')?.updateValueAndValidity();
  }

  create_client() {
    this.processSelected = "createclient"
    var data = { department_name: '', department_id: '', client_pk: '', department_pk: '', popup: 'createclient', search_client_pk: this.user.search_client_pk, clientOptions: this.mftService.loggedInUser.getUser().client_list };
    this.popupModalService.openModal(data);
  }

  create_department() {
    if (this.userForm.get('client_pk')?.value === "") {
      alert("Please select the client"); return;
    }
    this.processSelected = "createdepartment";
    var data = { department_name: '', department_id: '', client_pk: this.userForm.get('client_pk')?.value, department_pk: '', popup: 'createdepartment', search_client_pk: this.userForm.get('client_pk')?.value, clientOptions: this.mftService.loggedInUser.getUser().client_list.filter((item: { client_pk: number }) => item.client_pk === parseInt(this.userForm.get('client_pk')?.value!)) };
    this.popupModalService.openModal(data);
  }

  create_project() {
    if (this.userForm.get('department_pk')?.value === "") {
      alert("Please select the group"); return;
    }
    this.processSelected = "createproject";
    let filteredRows = this.departmentOptions.filter((department: { department_pk: number }) => department.department_pk === parseInt(this.userForm.get('department_pk')?.value!))
    let selectedDepartment = filteredRows.map((row: any) => ({ project_department_pk: filteredRows[0].department_pk, department_name: filteredRows[0].department_name }));

    var data = { project_id: '', project_pk: '', project_department_pk: this.userForm.get('department_pk')?.value, popup: 'createproject', departmentOptions: selectedDepartment };
    this.popupModalService.openModal(data);
  }

  getPhoneNumberObject(phoneNumber: string): any {
    return {
      internationalNumber: phoneNumber,
    };
  }

  active_client_validation(client: any) {
    if (client.client_status === 'ACTIVE' && client.client_expiry_date !== null && new Date(client.client_expiry_date) > new Date()) {
      return true;
    } else {
      return false;
    }
  }

}
