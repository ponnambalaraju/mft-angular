import { HttpErrorResponse, HttpParams, HttpResponse, } from '@angular/common/http';
import { AfterViewInit,ChangeDetectorRef,Component,OnInit,} from '@angular/core';
import { AnchorSpec, Connection, jsPlumb } from 'jsplumb';
import { FileElement } from 'src/app/file-manager/model/element';
import { MftService } from 'src/app/services/mft.service';
import { BaseComponent } from '../base/base.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

type TaskName = 'Start Task' | 'Files' | 'Folders' | 'Formula' | 'Destination' | 'End Task';

@Component({
  selector: 'app-workflow-designer',
  templateUrl: './workflow-designer.component.html',
  styleUrls: ['./workflow-designer.component.css'],
})

export class WorkflowDesignerComponent extends BaseComponent implements OnInit {

  ConnectionDetails: any;
  forwardStack: any;
  isDropDisabled = false;
  isCreateFolderDisabled = false;
  isCreateFolderHidden = false;
  folderData: FileElement[] = [];
  userData: any;
  user_pk: any;
  clientData: any;
  client_pk: any;
  public user = { user_pk: '', client_pk: '', search_client_pk: '' };
  public client = { client_pk: '' };
  activeformulas: any;
  savedWorkflows: any[] = [];
  otherfolder: string = '';
  selectedTab: string = 'folder';
  workflowTasks: any[] = [];
  foldersFile: File[] = [];
  UploadFiles: any[] = [];
  workflowName: string = '';
  instance: any;
  selectedWorkflow: any = null;
  currentFolderItems: any[] = [];
  navigationStack: any[] = [];
  currentParentId: string = 'root';
  currentWorkflowName: string = '';
  saveEvent: string = "Save";
  selected_workflow_pk: string;


  tasks = [
    { name: 'Start Task', icon: 'assets/icons/caret-right.svg',imgColor: '#387F39', bgColor: '#BEDC74' },
    { name: 'Files', icon: 'assets/icons/file-earmark.svg',imgColor: '#3572EF', bgColor: '#A7E6FF' },
    { name: 'Folders', icon: 'assets/icons/folders.svg',imgColor: '#FFB200', bgColor: '#ffb300a5' },
    { name: 'Formula', icon: 'assets/icons/calculator.svg',imgColor: '#CDC2A5', bgColor: '#E1D7C6' },
    { name: 'Destination', icon: 'assets/icons/folder-symlink.svg',imgColor: '#405D72', bgColor: '#758694' },
    { name: 'End Task', icon: 'assets/icons/x.svg',imgColor: '#C80036', bgColor: '#FF6969' },
  ];

  ngOnInit() {
    this.mftService.data$.subscribe((value) => {
      this.loadCurrentFolderItems();
      this.loadFolder();
      this.loadDataSets();
      this.loadactiveformulas();
      this.instance = jsPlumb.getInstance({ Container: 'canvas' });
      this.initializeJsPlumb();
      this.instance.reset();
      this.loadActiveworkflows();
    });
  }

  getTaskStyle(task: any): object {
    const reducedBrightnessColor = task.bgColor;
    return {
      'background-color': reducedBrightnessColor,
      ...task.style
    };
  }


  removeFile(task: any, index: number): void {
    if (task.files && index > -1) {
      task.files.splice(index, 1); // Remove the file at the specified index
    }
  }

  loadCurrentFolderItems(): void {
    this.currentFolderItems = this.folderData.filter(
      (item) => item.parent_id === this.currentParentId
    );
  }

  selectedValues: string[] = [];

  onCheckboxChange(event: any) {
    const value = event.target.value;
    const isChecked = event.target.checked;

    if (isChecked) {
      this.selectedValues.push(value);
    } else {
      this.selectedValues = this.selectedValues.filter(val => val !== value);
    }
    this.selected_workflow_pk = this.selectedValues.join('|');
  }



  preprocess(): void {
    const formData: any = new FormData();
    formData.append('workflow_pk', this.selected_workflow_pk);
    formData.append('client_pk', this.mftService.loggedInUser.getUser().client_pk);
    formData.append('user_pk', this.mftService.loggedInUser.getUser().user_pk);


    this.mftService.postData('update_preprocess', formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.status === 'SUCCESS') {
          this.mftService.updatedAlert(data.body.messages);
        }else{
          this.mftService.updatedAlert('An error occurred while processing your request. Please review the files and try again.');
        }
      },
      (error) => {
        console.error('There was an error!', error.message);
        this.mftService.updatedAlert('An error occurred while saving the workflow.');
      }
    );
  }

  loadactiveformulas() {
    if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = '%';
    } else if (
      this.mftService.loggedInUser.getUser().role_id === 'ORG_ADMIN' ||
      'PROJECT_LEAD'
    ) {
      this.user.search_client_pk =
        this.mftService.loggedInUser.getUser().client_pk;
    } else {
      this.user.user_pk = this.mftService.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams()
      .set('client_pk', this.user.search_client_pk)
      .set('user_pk', this.user.user_pk);
    this.mftService
      .loadData('get_conditional_logic_list', params)
      .subscribe((data: HttpResponse<any>) => {
        this.activeformulas = data.body;
      });
  }

  async loadFolder(): Promise<void> {
    if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = '%';
    } else if (
      this.mftService.loggedInUser.getUser().role_id === 'ORG_ADMIN' ||
      this.mftService.loggedInUser.getUser().role_id === 'PROJECT_LEAD'
    ) {
      this.user.search_client_pk =
        this.mftService.loggedInUser.getUser().client_pk;
    } else {
      this.user.user_pk = this.mftService.loggedInUser.getUser().user_pk;
    }

    const params = new HttpParams()
      .set('client_pk', this.user.search_client_pk)
      .set('user_pk', this.user.user_pk);

    this.mftService.loadData('get_wizard_list', params).subscribe(
      (data: HttpResponse<any>) => {
        this.folderData = data.body;
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:', httpError);
      }
    );
  }

  loadDataSets() {
    if (this.mftService.loggedInUser.getUser().role_id === 'SYS_ADMIN') {
      this.user.search_client_pk = '%';
    } else if (
      this.mftService.loggedInUser.getUser().role_id === 'ORG_ADMIN' ||
      'PROJECT_LEAD'
    ) {
      this.user.search_client_pk =
        this.mftService.loggedInUser.getUser().client_pk;
    } else {
      this.user.user_pk = this.mftService.loggedInUser.getUser().user_pk;
    }
    const params = new HttpParams()
      .set('client_pk', this.user.search_client_pk)
      .set('user_pk', this.user.user_pk);
    this.mftService.loadData('load_datasets', params).subscribe(
      (data: HttpResponse<any>) => {
        if(!data.body.error){
          this.folderData = [...this.folderData, ...data.body];
        }
        this.loadCurrentFolderItems();
      },
      (httpError: HttpErrorResponse) => {
        console.log('Error:', httpError);
      }
    );
  }

  openItem(item: any): void {
    if (item.isFolder) {
      this.navigationStack.push(this.currentParentId);
      this.currentParentId = item.wizard_id;
      this.loadCurrentFolderItems();
    } else {
    }
  }
  goBack(): void {
    if (this.navigationStack.length > 0) {
      this.currentParentId = this.navigationStack.pop();
      this.loadCurrentFolderItems();
    }
  }
  goForward(): void {
    if (this.forwardStack.length > 0) {
      this.navigationStack.push(this.currentParentId);
      this.currentParentId = this.forwardStack.pop()!;
      this.loadCurrentFolderItems();
    }
  }

  createFolder(task: any) {
    // Prompt the user for the folder name
    const folderName = prompt('Enter the folder name:');

    if (folderName) {
      task.files.push({ folder_name: folderName });
      this.updateFlags(task);
      this.isDropDisabled = true;
      this.isCreateFolderDisabled = true;
      this.isCreateFolderHidden = true;
    }
  }

  saveWorkflow() {
    const workflowNameInput = document.getElementById('workflowNameInput') as HTMLInputElement;
    this.workflowName = workflowNameInput.value.trim();

    if (this.workflowName) {
        // Initialize flags for required tasks
        let hasStartTask = false;
        let hasEndTask = false;
        let hasDestination = false;
        let hasFormula = false;
        let hasFilesOrFolder = false;
        // Validate if required tasks are present
        this.workflowTasks.forEach((task) => {
            if (task.name.includes('Start Task')) hasStartTask = true;
            if (task.name.includes('End Task')) hasEndTask = true;
            if (task.name.includes('Destination')) hasDestination = true;
            if (task.name.includes('Formula')) hasFormula = true;
            if (task.name.includes('File') || task.name.includes('Folder')) hasFilesOrFolder = true;
        });
        // Check if the workflow contains all necessary tasks
        if (!hasStartTask || !hasEndTask || !hasDestination || !hasFormula || !hasFilesOrFolder) {
            let missingTasks = [];
            if (!hasStartTask) missingTasks.push('Start Task');
            if (!hasEndTask) missingTasks.push('End Task');
            if (!hasDestination) missingTasks.push('Destination');
            if (!hasFormula) missingTasks.push('Formula');
            if (!hasFilesOrFolder) missingTasks.push('Files or Folder');
            this.mftService.updatedAlert(`Please ensure the workflow contains the following tasks: ${missingTasks.join(', ')}.`);
            return; // Stop execution if validation fails
        }
        // Extract connections and initialize arrays for saving task data
        const connections = this.instance.getAllConnections().map((connection: { sourceId: any; targetId: any; endpoints: any[] }) => ({
            sourceId: connection.sourceId,
            targetId: connection.targetId,
            type: 'Flowchart',
            anchors: connection.endpoints.map((endpoint: { anchor: { type: any; x: any; y: any; orientation: any } }) => ({
                type: endpoint.anchor.type,
                x: endpoint.anchor.x,
                y: endpoint.anchor.y,
                orientation: endpoint.anchor.orientation,
            })),
        }));

        // Ensure the task order is preserved
        const orderedTasks = this.workflowTasks.sort((a, b) => a.order - b.order);

        // Initialize arrays for task data
        const files: string[] = [];
        const folders: string[] = [];
        const formulas: string[] = [];
        const destinationsPk: string[] = [];
        const destinationsName: string[] = [];
        const filesStyle: string[] = [];
        const folderStyle: string[] = [];
        const formulaStyle: string[] = [];
        const destinationStyle: string[] = [];
        let lastFileTaskId = '';
        let lastFolderTaskId = '';
        let lastFormulaTaskId = '';
        let lastDestinationTaskId = '';
        const container = document.getElementById('canvas');
        const containerRect = container?.getBoundingClientRect();
        orderedTasks.forEach((task) => {
            const element = document.getElementById(task.id);
            if (element && containerRect) {
                const rect = element.getBoundingClientRect();
                const relativeLeft = rect.left - containerRect.left;
                const relativeTop = rect.top - containerRect.top;
                task.style = {
                    ...task.style,
                    left: relativeLeft + 'px',
                    top: relativeTop + 'px',
                    width: rect.width + 'px',
                    height: rect.height + 'px',
                };
            }

            if (task.name.includes('File')) {
                if (lastFileTaskId !== '' && lastFileTaskId !== task.id) {
                    files.push('|');
                }
                task.files.forEach((file: { dataset_pk: { toString: () => string } }) => {
                    files.push(file.dataset_pk.toString());
                });
                filesStyle.push(JSON.stringify(task.style));
                lastFileTaskId = task.id;
            } else if (task.name.includes('Folder')) {
                if (lastFolderTaskId !== '' && lastFolderTaskId !== task.id) {
                    folders.push('|');
                }
                task.files.forEach((file: { wizard_pk: { toString: () => string } }) => {
                    folders.push(file.wizard_pk.toString());
                });
                folderStyle.push(JSON.stringify(task.style));
                lastFolderTaskId = task.id;
            } else if (task.name.includes('Destination')) {
                if (lastDestinationTaskId !== '' && lastDestinationTaskId !== task.id) {
                    destinationsPk.push('|');
                    destinationsName.push('|');
                }
                task.files.forEach((file: { wizard_pk: { toString: () => string }; folder_name: { toString: () => string } }) => {
                    if (file.wizard_pk) {
                        destinationsPk.push(file.wizard_pk.toString());
                    } else if (file.folder_name) {
                        destinationsName.push(file.folder_name.toString());
                    }
                });
                destinationStyle.push(JSON.stringify(task.style));
                lastDestinationTaskId = task.id;
            } else if (task.name.includes('Formula')) {
                if (lastFormulaTaskId !== '' && lastFormulaTaskId !== task.id) {
                    formulas.push('|');
                }
                task.files.forEach((file: { c_logic_pk: { toString: () => string } }) => {
                    formulas.push(file.c_logic_pk.toString());
                });
                formulaStyle.push(JSON.stringify(task.style));
                lastFormulaTaskId = task.id;
            }
        });
        // Remove trailing separators if they exist
        if (files[files.length - 1] === '|') files.pop();
        if (folders[folders.length - 1] === '|') folders.pop();
        if (formulas[formulas.length - 1] === '|') formulas.pop();
        if (destinationsPk[destinationsPk.length - 1] === '|') destinationsPk.pop();
        if (destinationsName[destinationsName.length - 1] === '|') destinationsName.pop();
        // Convert arrays to comma-separated strings
        const filesString = files.join(',');
        const foldersString = folders.join(',');
        const formulasString = formulas.join(',');
        const destinationsPkString = destinationsPk.join(',');
        const destinationsNameString = destinationsName.join(',');
        const filesStyleString = filesStyle.join(',');
        const folderStyleString = folderStyle.join(',');
        const formulaStyleString = formulaStyle.join(',');
        const destinationStyleString = destinationStyle.join(',');
        // Find the existing workflow if the saveEvent is 'Edit'
        let existingWorkflow = null;
        if (this.saveEvent === 'Edit') {
            existingWorkflow = this.savedWorkflows.find(
                (wf) => wf.workflow_name === this.workflowName
            );
            // Clear old connections if editing
            if (existingWorkflow) {
                this.clearConnections(existingWorkflow.workflow_id);
            }
        }

        const deduplicatedConnections = connections.reduce((unique: any[], connection: { sourceId: any; targetId: any; }) => {
          if (!unique.some((conn: { sourceId: any; targetId: any; }) => conn.sourceId === connection.sourceId && conn.targetId === connection.targetId)) {
              unique.push(connection);
          }
          return unique;
      }, []);

      // Log deduplicated connections
      console.log('Deduplicated Connections:', deduplicatedConnections);


        // Create new workflow object
        const newWorkflow = {
            name: this.workflowName,
            workflow_id: existingWorkflow ? existingWorkflow.workflow_id : '',
            workflow_pk: existingWorkflow ? existingWorkflow.workflow_pk : '', // Set workflow_pk if editing
            client_pk: this.mftService.loggedInUser.getUser().client_pk,
            user_pk: this.mftService.loggedInUser.getUser().user_pk,
            created_at: existingWorkflow ? existingWorkflow.workflow_created_at : "",
            modified_at: existingWorkflow ? existingWorkflow.workflow_modify_at : "",
            workflow_status: existingWorkflow ? existingWorkflow.workflow_status : "",
            start: this.workflowTasks.find((task) => task.name === 'Start Task') || {},
            start_style: this.workflowTasks.find((task) => task.name === 'Start Task')?.style || [],
            end: this.workflowTasks.find((task) => task.name === 'End Task') || {},
            end_style: this.workflowTasks.find((task) => task.name === 'End Task')?.style || [],
            files_style: filesStyleString,
            folder_style: folderStyleString,
            formula_style: formulaStyleString,
            Destination_pk: destinationsPkString,
            DestinationStyle: destinationStyleString,
            tasks: orderedTasks,
            connections: deduplicatedConnections,
            dataset_pk: filesString,
            wizard_pk: foldersString,
            c_logic_pk: formulasString,
            workflow_modify_by: this.mftService.loggedInUser.getUser().user_pk,
            workflow_created_by: existingWorkflow ? existingWorkflow.workflow_created_by : this.mftService.loggedInUser.getUser().user_pk,
        };

        const formData: any = new FormData();
        for (const key in newWorkflow) {
            if (newWorkflow.hasOwnProperty(key)) {
                const typedKey = key as keyof typeof newWorkflow;
                const value = newWorkflow[typedKey];
                if (typeof value === 'object') {
                    formData.append(typedKey, JSON.stringify(value));
                } else {
                    formData.append(typedKey, value as string);
                }
            }
        }

        if (existingWorkflow) {
            // If the workflow exists, update it
            const confirmUpdate = confirm('Are you sure you want to update it?');
            if (confirmUpdate) {
                this.savedWorkflows = this.savedWorkflows.map(workflow =>
                    workflow.workflow_name === this.workflowName ? newWorkflow : workflow
                );
            } else {
                // If user doesn't want to update, exit the function
                return;
            }
        } else {
            // If the workflow doesn't exist, add a new one
            this.savedWorkflows.push(newWorkflow);
        }
        this.mftService.postData('save_workflow', formData).subscribe(
          (data: HttpResponse<any>) => {
            if(data.body.status === 'SUCCESS'){
              this.mftService.updatedAlert(data.body.message);
              this.currentWorkflowName = this.workflowName
              this.loadActiveworkflows();
            }else{
              this.mftService.updatedAlert(data.body.message);
            }
    });
        this.currentWorkflowName = '';
    } else {
        alert('Please enter a name for the workflow.');
    }
}

clearConnections(workflowId: string) {
  // Assuming you have a way to get all connections related to the specific workflowId
  const connections = this.getConnectionsByWorkflowId(workflowId);
  // Loop through each connection and detach it
  connections.forEach((connection: any) => {
    this.instance.deleteConnection(connection);
  });
}
// Helper method to get connections by workflowId
getConnectionsByWorkflowId(workflowId: string) {
  // Retrieve all connections
  const allConnections = this.instance.getAllConnections();
  // Filter connections that belong to the specified workflowId
  return allConnections.filter((connection: { workflowId: string; }) => connection.workflowId === workflowId);
}

  CleanWorkflow(){
       this.instance.reset();
       this.workflowTasks=[];
       this.currentWorkflowName = '';
       this.workflowName = '';

  }


  refreshCanvas() {
    try {
      this.instance.reset();
      this.instance.batch(() => {
        // Log the type and content of `this.workflowTasks`
        console.log('Type of this.workflowTasks:', typeof this.workflowTasks);
        console.log('Content of this.workflowTasks:', this.workflowTasks);

        let responseData: any[];
        if (typeof this.workflowTasks === 'string') {
          // If it's a string, parse it
          try {
            this.workflowTasks = JSON.parse(this.workflowTasks);
          } catch (e) {
            console.error('Error parsing JSON:', e);
            return;
          }
        } else if (Array.isArray(this.workflowTasks)) {
          // If it's already an array, use it directly
          responseData = this.workflowTasks;
        } else {
          console.error('Invalid type for workflowTasks');
          return;
        }
        let connresponseData: any[];
        if (typeof this.ConnectionDetails === 'string') {
          // If it's a string, parse it
          try {
            connresponseData = JSON.parse(this.ConnectionDetails);
          } catch (e) {
            console.error('Error parsing JSON:', e);
            return;
          }
        } else if (Array.isArray(this.ConnectionDetails)) {
          // If it's already an array, use it directly
          connresponseData = this.ConnectionDetails;
        } else {
          console.error('Invalid type for workflowTasks');
          return;
        }

        // Log parsed response data
        console.log('Parsed Response Data:', this.workflowTasks);
        console.log('Parsed connection Data:', connresponseData);

        this.workflowTasks.forEach((task) => {
          console.log('Adding task:', task);
          setTimeout(() => {
            this.initializeTask(task.id, task.name);

            connresponseData.forEach(
              (connection: {
                sourceId: string;
                targetId: string;
                anchors: any[];
                overlays: any[];
              }) => {
                const sourceElement = document.getElementById(
                  connection.sourceId
                );
                const targetElement = document.getElementById(
                  connection.targetId
                );


                if (sourceElement && targetElement) {
                  try {
                    const getAnchorPosition = (
                      x: number,
                      y: number,
                      orientation: number[]
                    ) => {
                      if (x === 0 && y === 0.5) return 'Left';
                      if (x === 1 && y === 0.5) return 'Right';
                      if (x === 0.5 && y === 0) return 'Top';
                      if (x === 0.5 && y === 1) return 'Bottom';
                      return [x, y, orientation[0], orientation[1]];
                    };

                    const sourceAnchor = getAnchorPosition(
                      connection.anchors[0].x,
                      connection.anchors[0].y,
                      connection.anchors[0].orientation
                    );
                    const targetAnchor = getAnchorPosition(
                      connection.anchors[1].x,
                      connection.anchors[1].y,
                      connection.anchors[1].orientation
                    );

                    this.instance.connect({
                      source: connection.sourceId,
                      target: connection.targetId,
                      anchors: [sourceAnchor, targetAnchor],
                      connector: 'Flowchart',
                      isdynamic: true,
                      endpoint: ['Dot', { radius: 7 }],
                      endpointStyle: { fill: '#1C6F91' },
                      paintStyle: { stroke: '#1C6F91', strokeWidth: 2 },
                      connectorStyle: { stroke: '#1C6F91', strokeWidth: 3 },
                      overlays: [
                        [
                          'Arrow',
                          { width: 12, length: 12, location: 1, id: 'arrow' },
                        ],
                      ],
                    });
                  } catch (error) {
                    console.error('Error establishing connection:', error);
                  }
                }
              }
            );
          }, 0);
        });
      });
    } catch (error) {
      console.error('Error refreshing canvas:', error);
    }
  }

  removeTasks() {
    const taskElements = document.querySelectorAll('.task-class'); // Update selector as needed
    taskElements.forEach((element) => element.remove());
  }

  loadWorkflows() {
    this.workflowTasks = [
      ...this.savedWorkflows[this.savedWorkflows.length - 1].tasks,
    ];
  }

  viewWorkflow(workflow_pk: string, Event: string): void {
    this.saveEvent = Event;
    // Locate the workflow by its pk
    const workflow = this.savedWorkflows.find(
      (wf) => wf.workflow_pk === workflow_pk
    );
    this.currentWorkflowName = workflow?.workflow_name || '';
    this.instance.reset();
    if (workflow) {
      // Clear the current state before loading a new workflow
      this.workflowTasks = [];
      // Set workflow tasks and render them on the canvas
      this.workflowTasks = workflow.tasks;
      this.ConnectionDetails = workflow.connections;
      this.refreshCanvas();
    } else {
      alert('Workflow not found.');
    }
}

  copyWorkflow(originalWorkflowName: string) {
    // Find the workflow to copy
    const workflowToCopy = this.savedWorkflows.find(
      (wf) => wf.name === originalWorkflowName
    );

    if (workflowToCopy) {
      // Prompt the user for a new name for the copied workflow
      const newWorkflowName = prompt(
        'Enter a new name for the copied workflow:',
        `${workflowToCopy.name} (Copy)`
      );

      // Check if the user provided a new name
      if (newWorkflowName) {
        // Create a copy of the workflow with the new name
        const copiedWorkflow = {
          ...workflowToCopy,
          name: newWorkflowName, // Use the new name provided by the user
          work_id: '', // Generate a new ID for the copied workflow
          created_at: new Date().toISOString(), // Set the created_at to the current date/time
          modified_at: new Date().toISOString(), // Set the modified_at to the current date/time
        };

        // Add the copied workflow to the saved workflows
        this.savedWorkflows.push(copiedWorkflow);

        // Optionally, you might want to refresh the view or take some other action
        this.loadWorkflows();
        this.refreshCanvas(); // Reload workflows to include the copied one
      } else {
        alert('Please enter a valid name for the copied workflow.');
      }
    } else {
      console.error('Workflow not found:', originalWorkflowName);
    }
  }

  deleteWorkflow(name: string) {
    this.savedWorkflows = this.savedWorkflows.filter((w) => w.name !== name);
    this.loadWorkflows(); // Reload workflows to reflect changes
  }

  initializeJsPlumb() {
    setTimeout(() => {
      this.workflowTasks.forEach((task) => {
        // Assuming task has an id, x, y, width, and height
        const taskElement = document.getElementById(task.id);

        if (taskElement) {
          this.instance.draggable(taskElement, {
            grid: [10, 10],
            stop: (event: any) => {
              // Update task position when dragging stops
              task.x = event.finalPos[0];
              task.y = event.finalPos[1];
            },
          });

          this.instance.addEndpoint(taskElement, {
            anchors: ['Right'],
            isSource: true,
            isTarget: false,
            maxConnections: -1,
            endpointOptions: { uuid: true },
            endpoint: ['Dot', { radius: 7 }],
            paintStyle: { fill: '#1C6F91' },
          });

          this.instance.addEndpoint(taskElement, {
            anchors: ['Left'],
            isSource: false,
            isTarget: true,
            maxConnections: -1,
            endpoint: ['Dot', { radius: 7 }],
            paintStyle: { fill: '#1C6F91' },
          });

          // Set task element position
          taskElement.style.left = task.x + 'px';
          taskElement.style.top = task.y + 'px';
        }
      });

      this.instance.bind('connection', (info: any) => {
        this.infoData(info);
      });
    }, 100); // Delay to ensure elements are ready for jsPlumb
  }
  overlaydata = '';

  infoData(info: any) {
    this.overlaydata = info.targetEndpoint.connectoroverlays;
  }

  initializeTask(taskId: string, taskName: string) {
    this.instance.draggable(taskId);

    const commonEndpointOptions = {
      connector: ['Flowchart', { curviness: 50 }],
      endpoint: ['Dot', { radius: 7 }],
      paintStyle: { fill: '#1C6F91', strokeWidth: 2 },
      connectorStyle: { stroke: '#1C6F91', strokeWidth: 3 },
      connectorOverlays: [['Arrow', { width: 12, length: 12, location: 1 }]],
    };

    // Add endpoints based on taskName
    if (
      taskName === 'Files' ||
      taskName === 'Formula' ||
      taskName === 'Folders' ||
      taskName === 'Destination'
    ) {
      // Add endpoints with 'Left' and 'Right' anchors
      this.instance.addEndpoint(taskId, {
        anchor: 'Left',
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        endpointOptions: { uuid: true },
        ...commonEndpointOptions,
      });

      this.instance.addEndpoint(taskId, {
        anchor: 'Right',
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        endpointOptions: { uuid: true },
        ...commonEndpointOptions,
      });
    } else if (taskName === 'Start Task') {
      // Add endpoint with 'Right' anchor only
      this.instance.addEndpoint(taskId, {
        anchor: 'Right',
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        endpointOptions: { uuid: true },
        ...commonEndpointOptions,
      });
    } else {
      // Add endpoint with 'Left' anchor only
      this.instance.addEndpoint(taskId, {
        anchor: 'Left',
        isSource: true,
        isTarget: true,
        maxConnections: -1,
        endpointOptions: { uuid: true },
        ...commonEndpointOptions,
      });
    }

    // Function to log the width and height of the line
    function logConnectionDimensions(info: any) {
      const sourceEndpoint = info.sourceEndpoint;
      const targetEndpoint = info.targetEndpoint;

      // Get the positions of the source and target endpoints
      const sourcePos = sourceEndpoint.canvas.getBoundingClientRect();
      const targetPos = targetEndpoint.canvas.getBoundingClientRect();

      // Calculate the width and height
      const width = Math.abs(targetPos.left - sourcePos.left);
      const height = Math.abs(targetPos.top - sourcePos.top);

      // Log the width and height of the line
    }

    // Bind to the 'connection' event to log dimensions when a connection is created

    // Bind to the 'connectionMoved' event to log dimensions when a connection is moved
  }

  selectTab(tab: string) {
    this.selectedTab = tab;
  }

  onTabChange(tab: string) {
    this.selectedTab = tab;
  }

  //deldting the workarea

  onDragStart(event: DragEvent, task: any) {
    event.dataTransfer?.setData('task', JSON.stringify(task));
  }

  onTaskDelete(taskId: string) {
    // Remove task from the workflowTasks array
    this.workflowTasks = this.workflowTasks.filter(
      (task) => task.id !== taskId
    );

    // Remove the task's connections and endpoints from jsPlumb
    this.instance.removeAllEndpoints(taskId);
    this.instance.remove(taskId);
  }

  CloseWorkflowTask(taskId: string): void {
    this.onTaskDelete(taskId);
  }

  allowDrop(event: DragEvent) {
    event.preventDefault();
  }

  //Ondrop Event
  onDrop(event: DragEvent) {
    event.preventDefault();
    const data = event.dataTransfer?.getData('task');
    if (data) {
      const task = JSON.parse(data);
      this.addTaskToCanvas(task, event.clientX, event.clientY);
    }
  }

  //Adding Task to Canvas
  addTaskToCanvas(task: any, x: number, y: number) {
    const canvas = document.getElementById('canvas');
    if (canvas) {
      const rect = canvas.getBoundingClientRect();
      const style = {
        top: `${y - rect.top}px`,
        left: `${x - rect.left}px`,
      };
      const id = 'task-' + new Date().getTime();

      // Check if a Start Task, End Task, or Destination Task already exists
      const taskExists = this.workflowTasks.some(existingTask =>
        (task.name === 'Start Task' && existingTask.name === 'Start Task') ||
        (task.name === 'End Task' && existingTask.name === 'End Task') ||
        (task.name === 'Destination' && existingTask.name === 'Destination')
      );

      if (taskExists) {
        this.mftService.updatedAlert(`A ${task.name} already exists. You can only have one ${task.name} on the canvas.`);
        return;  // Exit the function to prevent adding the task
      }

      let files = [];

      this.workflowTasks.push({
        ...task,
        id,
        style,
        files: [],
      });

      setTimeout(() => {
        this.initializeTask(id, task.name);
      }, 0);
    }
  }

  //File Drop
  onFileDrop(event: DragEvent, task: any): void {
    event.preventDefault();
    // Define the allowed keys
    const allowedKeys = [
      'client_pk',
      'dataset_pk',
      'datasets_status',
      'file_name',
      'user_pk',
    ];

    // Parse the dragged item data
    const draggedItemRaw = event.dataTransfer?.getData('draggedItem') || '{}';
    const draggedItem = JSON.parse(draggedItemRaw);

    // Filter the object to keep only the allowed keys
    const filteredDraggedItem = Object.keys(draggedItem)
      .filter((key) => allowedKeys.includes(key))
      .reduce((obj, key) => {
        obj[key] = draggedItem[key];
        return obj;
      }, {} as Record<string, any>);

    console.log('Filtered data:', filteredDraggedItem);

    if (draggedItem && draggedItem.isFolder === false) {
      task.files.push({ ...filteredDraggedItem });
      console.log('File successfully added to task:', task.files);
    } else {
      this.mftService.updatedAlert('Dragged file is invalid');
    }
  }
  //Formula Drop
  onFormulaDrop(event: DragEvent, task: any): void {
    event.preventDefault();
    const draggedItem = JSON.parse(
      event.dataTransfer?.getData('draggedItem') || '{}'
    );
    if (draggedItem && draggedItem.formula_name) {
      task.files.push({ ...draggedItem }); // Copy the file object
    } else {
      this.mftService.updatedAlert('Dragged Formula is invalid');
    }
  }
  //Folder Drop
  onFolderDrop(event: DragEvent, task: any): void {
    event.preventDefault();
    const draggedItem = JSON.parse(
      event.dataTransfer?.getData('draggedItem') || '{}'
    );
    if (draggedItem && draggedItem.isFolder === true) {
      // Check if the file type is valid (if necessary)

      task.files.push({ ...draggedItem }); // Copy the file object into the task
    } else {
      this.mftService.updatedAlert('Dragged item is not a file or is invalid');
    }
  }


  onDestinationFolderDrop(event: DragEvent, task: any) {
    event.preventDefault();
    // Parse the dragged item data
    const draggedItem = JSON.parse(
      event.dataTransfer?.getData('draggedItem') || '{}'
    );
    // Check if dragged item is a folder and if no folder is currently added
    if (draggedItem && draggedItem.isFolder === true) {
      if (task.files.length === 0) {
        // Accept the folder only if none exist
        task.files.push({ ...draggedItem });
        this.updateFlags(task);
        // Disable further drops
        this.isDropDisabled = true;
        this.isCreateFolderDisabled = true;
        this.isCreateFolderHidden = true;
      } else {
        // Alert that a folder has already been dropped
        this.mftService.updatedAlert('Only one folder can be accepted.');
      }
    } else {
      // Alert if the dragged item is invalid or not a folder
      this.mftService.updatedAlert('Dragged item is not a folder or is invalid.');
    }
  }
  
  private updateFlags(task: any) {
    const fileCount = task.files.length;

    // Disable drop and creation if there is exactly one folder
    this.isDropDisabled = fileCount > 0;
    this.isCreateFolderDisabled = fileCount > 0;
    this.isCreateFolderHidden = fileCount > 0;
  }

  getFileIcon(file: File): string {
    return '📄'; // Use a generic file icon
  }

  //File Drag
  onFileDragStart(event: DragEvent, item: any): void {
    event.dataTransfer?.setData('draggedItem', JSON.stringify(item));
    event.dataTransfer!.effectAllowed = 'copy'; // Allow only copy operation
  }

  //Formula Drag
  onFormulaDragStart(event: DragEvent, formula: any): void {
    if (event.dataTransfer) {
      event.dataTransfer?.setData('draggedItem', JSON.stringify(formula));
      event.dataTransfer!.effectAllowed = 'copy';
    }
  }

  //Folder Drag
  onFolderDragStart(event: DragEvent, item: any): void {
    if (event.dataTransfer) {
      event.dataTransfer?.setData('draggedItem', JSON.stringify(item));
      event.dataTransfer!.effectAllowed = 'copy';
    }
  }

  loadActiveworkflows(): void {
    const httpParams = new HttpParams();
    this.mftService.loadData('load_active_workflow', httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.otherfolder.includes(obj.workflow_pk.toString())) {
            obj.workflow_status = 'INACTIVE';
          } else {
            obj.workflow_status = 'ACTIVE';
          }
        });
        this.savedWorkflows = data.body;
      },
      (httpError: HttpErrorResponse) => {
        if (
          httpError instanceof HttpErrorResponse &&
          httpError.status === 401
        ) {
          console.error('Popup model', httpError.message);
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
    );
  }

  cloneWorkflow(workflow_pk: string) {
    const newWorkflowName = prompt('Enter a new name for the copied workflow:');

    if (
      newWorkflowName &&
      confirm(
        `Are you sure you want to create a new workflow with the name "${newWorkflowName}"?`
      )
    ) {
      const nameExists = this.savedWorkflows.some(
        (wf) => wf.workflow_name === newWorkflowName
      );

      if (!nameExists) {
        const user = this.mftService.loggedInUser.getUser();
        const formData: any = new FormData();
        formData.append('workflow_pk', workflow_pk);
        formData.append('new_name', newWorkflowName.trim());
        formData.append('client_pk', user.client_pk);
        formData.append('user_pk', user.user_pk);
        this.mftService.postData('save_workflow', formData).subscribe(
          (response: HttpResponse<any>) => {
            const firstElement = response.body[0];
            if (firstElement && firstElement.message === 'SUCCESS') {
              this.mftService.updatedAlert(
                'The workflow was copied successfully.'
              );
            } else {
              if (
                firstElement.status === 'FAILURE' &&
                firstElement.data !== ''
              ) {
                this.mftService.updatedAlert(firstElement.data);
              } else {
                this.mftService.updatedAlert('Failed to copy the workflow.');
              }
            }
          },
          (httpError: HttpErrorResponse) => {
            this.mftService.httpErrorHandler(httpError);
          }
        );
      } else {
        this.mftService.updatedAlert(
          'A workflow with this name already exists.'
        );
      }
    } else {
      this.mftService.updatedAlert(
        'Workflow cloning was canceled or invalid name provided.'
      );
    }
  }




  deleteFormula(
    workflow: { workflow_pk: string; workflow_status: string },
    title: string
  ) {
    if (confirm(`Are you sure you want to "${title}"?`)) {
      const client_pk = this.mftService.loggedInUser.getUser().client_pk;
      const user_pk = this.mftService.loggedInUser.getUser().user_pk;
      const formData: any = new FormData();
      formData.append('workflow_status', title);
      formData.append('workflow_pk', workflow.workflow_pk);
      formData.append('client_pk', client_pk);
      formData.append('user_pk', user_pk);
      this.mftService.postData('workflow_formula_status', formData).subscribe(
        (response: HttpResponse<any>) => {
          const firstElement = response.body[0];
          if (firstElement && firstElement.message === 'SUCCESS') {
            this.mftService.updatedAlert(
              'The Workflow status updated successfully'
            );
            window.location.reload();
          } else {
            if (firstElement.status === 'FAILURE' && firstElement.data !== '') {
              this.mftService.updatedAlert(firstElement.data);
            } else {
              this.mftService.updatedAlert('Failed to update the status');
            }
          }
        },
        (httpError: HttpErrorResponse) => {
          super.httpErrorHandler(httpError);
        }
      );
    }
  }
}
