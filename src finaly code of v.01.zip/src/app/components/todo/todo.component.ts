import { Component, Output, EventEmitter } from '@angular/core';
import { NgbDateStruct, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SelectionChangedEvent } from 'ag-grid-community';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { BaseComponent } from '../base/base.component';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';
import bootstrap, { Offcanvas } from 'bootstrap';
import { Users } from 'src/app/models/users';
import { MftService } from 'src/app/services/mft.service';
import { hide } from '@popperjs/core';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})

export class TodoComponent extends BaseComponent {


  constructor(public override modalService: NgbModal, private loggedInUser: Users,private formBuilder: FormBuilder) {
    super(modalService);
    const today = new Date();
    this.clientexpiry_minDate = { year: today.getFullYear(), month: today.getMonth() + 1, day: today.getDate() };

  }



	changePreferredCountries() {
		this.preferredCountries = [CountryISO.UnitedStates, CountryISO.India];
	}

  @Output() passEntry: EventEmitter<any> = new EventEmitter();
  taskColumnDefs: any;
  RowData: any;
  AgLoad: boolean = true;
  rowSelection: 'single' | 'multiple' = 'single';
  rowMultiSelectWithClick: true;
  gridApi: any;
  gridColumnApi: any;
  departmentOptions: any[] = [];
  tempDepartmentOptions: any[] = [];
  projectOptions: any[] = [];
  tempProjectOptions: any[] = [];
  roleOptions: any[];
  tempRoleOptions: any[];
  authenticationTypeOptions: any[];
  processSelected: any;
  public user = { search_client_pk: '' };
  allow_downloading_files: boolean;
  task: any = {};
  user_pk: string;
  userData: any;
  todoForm: FormGroup;
  todoList: any;
  templateGridApi: any;
  otherfolder: string = '';
  folderOptions: any[] = [];

  user_phone_no_error: any;
  button_disable: boolean = true;
  password_disable: boolean = true;
  userunlock_disable: boolean = true;
  popup_role_client_disable: boolean = false;
  priorityOptions: string[] = ['High', 'Medium', 'Low'];
  clientexpiry_minDate: NgbDateStruct;
  taskEditForm: FormGroup;

  separateDialCode = false;
	SearchCountryField = SearchCountryField;
	CountryISO = CountryISO;
  PhoneNumberFormat = PhoneNumberFormat;
	preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.India];


  pOptions: any[] = [
    { value: '', name: 'Select...' },
    { value: 'A', name: 'MFT' },
    { value: 'B', name: 'ALM' },
    { value: 'C', name: 'LIMS' },
    { value: 'D', name: 'Salesforce' }
  ];

  taskStatus: any[] = [
    { value: '', name: 'Select...' },
    { value: 'Not Started', name: 'Not Started' },
    { value: 'In Progress', name: 'In Progress' },
    { value: 'Completed', name: 'Completed' }
  ];
  
  priority: any[] = [
    { value: '', name: 'Select...' },
    { value: 'High', name: 'High' },
    { value: 'Medium', name: 'Medium' },
    { value: 'Low', name: 'Low' }
  ];

  ngOnInit() {
    this.loadActiveUsers();
    const currentDate = new Date();
    this.task.startDate = this.formatDateToInput(currentDate);
    this.taskColumnDefs = [

      { headerName: 'Task PK', field: 'task_pk', sortable: true, filter: true, resizable: true, minWidth: 100,hide:true },
      { headerName: 'Task ID', field: 'task_id', sortable: true, filter: true, resizable: true, minWidth: 100, },
      { headerName: 'User PK', field: 'user_pk', sortable: true, filter: true, resizable: true, minWidth: 100,hide:true  },
      { headerName: 'Client PK', field: 'client_pk', sortable: true, filter: true, resizable: true, minWidth: 100,hide:true  },
      { headerName: 'Task Title', field: 'task_title', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Description', field: 'description', sortable: true, filter: true, resizable: true, minWidth: 250 },
      { headerName: 'Assign To', field: 'assign_to', sortable: true, filter: true, resizable: true, minWidth: 250 },
      { headerName: 'Task Status', field: 'task_status', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'Created By', field: 'created_by', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Priority', field: 'priority', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'Project Name', field: 'project_name', sortable: true, filter: true, resizable: true, minWidth: 150 },
      { headerName: 'Module', field: 'module', sortable: true, filter: true, resizable: true, minWidth: 150, },


      { headerName: 'Created Date', field: 'created_date', sortable: true, filter: true, resizable: true, minWidth: 150,hide:true },
      { headerName: 'Task Modify Date', field: 'task_modify_date', sortable: true, filter: true, resizable: true, minWidth: 250,hide:true },
      { headerName: 'Estimated Hours', field: 'estimate_hours', sortable: true, filter: true, resizable: true, minWidth: 150,hide:true },
      { headerName: 'Task Completed Date', field: 'task_completed_date', sortable: true, filter: true, resizable: true, minWidth: 200,hide:true },
      { headerName: 'Hours Taken To Complete', field: 'hrs_taken_to_complete', sortable: true, filter: true, resizable: true, minWidth: 150,hide:true },
      { headerName: 'Comment', field: 'comment', sortable: true, filter: true, resizable: true, minWidth: 150,hide:true  },
      { headerName: 'Attachment', field: 'attachment', sortable: true, filter: true, resizable: true, minWidth: 150,hide:true  },

    ];

    this.mftService.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      this.user_pk = this.loggedInUser.getUser().user_pk;
    });

    this.todoForm = this.formBuilder.group({
      task_pk: ['', Validators.required],
      task_id: ['', Validators.required],
      user_pk: ['', Validators.required],
      client_pk: ['', Validators.required],
      task_title: ['', Validators.required],
      description: ['', Validators.required],
      assign_to: ['', Validators.required],
      task_status: ['', Validators.required],
      created_by: ['', Validators.required],
      priority: ['', Validators.required],
      project_name: ['', Validators.required],
      created_date: ['', Validators.required],
      task_modify_date: ['', Validators.required],
      estimate_hours: ['', Validators.required],
      task_completed_date: ['', Validators.required],
      hrs_taken_to_complete: ['', Validators.required],
      comment: ['', Validators.required],
      attachment: ['', []],
      module: ['', Validators.required],
    });
  };

  formatDateToInput(date: Date): string {
    const pad = (n: number) => n < 10 ? '0' + n : n;

    const year = date.getFullYear();
    const month = pad(date.getMonth() + 1); 
    const day = pad(date.getDate());

    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());

    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
  }

  addTask(form: NgForm): void {
    if (form.valid) {
      console.log('Task Added:', this.task); 
      form.resetForm();
      this.task = {}; 
    }
  }

  override onRowClicked(event: any) {
    const clickedData = event.data;
    this.showLeftNavbar(clickedData);
  }
  
  showLeftNavbar(task: any) {
    console.log('Task clicked:', task);
    const offcanvasLabel = document.getElementById('offcanvasBottomLabel');
    const offcanvasElement = document.getElementById('offcanvasBottom') as HTMLElement;

    if (offcanvasLabel) {
      offcanvasLabel.textContent = `Details for ${String(task.task_id).padStart(4, '0')}`;
    }
    const taskID = task.task_id;
    const selectedData = this.todoList.filter((data: { task_id: any; }) => data.task_id === taskID);
    console.log('Selected Data:', selectedData);

        
    this.todoForm.patchValue({
      task_pk: selectedData[0]["task_pk"], task_id: selectedData[0]["task_id"],user_pk: selectedData[0]["user_pk"], client_pk: selectedData[0]["client_pk"],
      task_title: selectedData[0]["task_title"], description: selectedData[0]["description"],assign_to: selectedData[0]["assign_to"], task_status: selectedData[0]["task_status"],
      created_by: selectedData[0]["created_by"], priority: selectedData[0]["priority"],project_name: selectedData[0]["project_name"], created_date: selectedData[0]["created_date"],
      task_modify_date: selectedData[0]["task_modify_date"], estimate_hours: selectedData[0]["estimate_hours"],
      task_completed_date: selectedData[0]["task_completed_date"], hrs_taken_to_complete: selectedData[0]["hrs_taken_to_complete"],
      comment: selectedData[0]["comment"],attachment: selectedData[0]["attachment"],module: selectedData[0]["module"],
     });

    if (offcanvasElement) {
      const offcanvas = new Offcanvas(offcanvasElement);
      offcanvas.show();
    } else {
      console.error("Offcanvas element not found");
    }
  }

  loadActiveUsers(): void {
    const httpParams = new HttpParams();
    this.mftService.loadData("load_active_user", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.otherfolder.includes(obj.user_pk.toString())) {
            obj.user_status = true;
          } else {
            obj.user_status = false;
          }
        });
        this.folderOptions = data.body;
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          console.error('Popup model', httpError.message);
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
      );
  }

  

  // resetForm(form: NgForm): void {
  //   form.resetForm();
  //   this.task = {}; 
  // }

  resetForm() {
    this.todoForm.reset();
  }


  userDataBind(params: any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.userListSearch();
  }

  userListSearch() {
    if (this.gridApi && this.task) {
      this.gridApi.setRowData(this.task);
    }
  }

  currentEvent: string;
  open(content: any, clickEvent: string) {
    this.submitted = false;
    this.currentEvent = clickEvent;
    if (clickEvent === "NEW") {
      this.todoForm.patchValue({
        task_pk: 'None', task_id: '', user_pk: '', client_pk:'', task_title: '', description:'',assign_to: '',task_status:'', created_by: '', priority:'', project_name: '',
         created_date:'',task_modify_date: '',estimate_hours:'',
        task_completed_date: '', hrs_taken_to_complete:'',comment: '',attachment:'', module:'', });
    }
    if (clickEvent === "EDIT") {

      const selectedData = this.templateGridApi.getSelectedRows();
      this.todoForm.patchValue({
        task_pk: selectedData[0]["task_pk"], task_id: selectedData[0]["task_id"],user_pk: selectedData[0]["user_pk"], client_pk: selectedData[0]["client_pk"],
        task_title: selectedData[0]["task_title"], description: selectedData[0]["description"],assign_to: selectedData[0]["assign_to"], task_status: selectedData[0]["task_status"],
        created_by: selectedData[0]["created_by"], priority: selectedData[0]["priority"],project_name: selectedData[0]["project_name"], created_date: selectedData[0]["created_date"],
        task_modify_date: selectedData[0]["task_modify_date"], estimate_hours: selectedData[0]["estimate_hours"],
        task_completed_date: selectedData[0]["task_completed_date"], hrs_taken_to_complete: selectedData[0]["hrs_taken_to_complete"],
        comment: selectedData[0]["comment"],attachment: selectedData[0]["attachment"],module: selectedData[0]["module"],
       });
    }

    const modalRef = this.modalService.open(content, {backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title'});
    modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  };

  getClientValue(params: any) {
    let client = this.mftService.loggedInUser.getUser().client_list.find((client: { client_pk: any; }) => client.client_pk === params.data.client_pk);
    return client ? client.client_name : "";
  };

  getDepartmentValue(params: any) {
    let department = this.departmentOptions.find(department => department.department_pk === params.data.department_pk);
    return department?department.department_name:"";
  };

  getProjectValue(params: any) {
    let project = this.projectOptions.find(project => project.project_pk === params.data.project_pk);
    return project?project.project_name:"";
  };


  save_form(){
    console.log("save form click");
    this.submitted = true;
    if (this.todoForm.invalid) {
      const invalid = [];
      const controls = this.todoForm.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
    }

    var formData: any = new FormData();
    formData.append('task_pk', this.todoForm.value['task_pk']),
    formData.append('task_id', this.todoForm.value['task_id']),
    formData.append('user_pk', this.loggedInUser.getUser().user_pk),
    formData.append('client_pk', this.loggedInUser.getUser().client_pk),
    formData.append('task_title', this.todoForm.value['task_title']),
    formData.append('description', this.todoForm.value['description']),
    formData.append('assign_to', this.todoForm.value['assign_to']),
    formData.append('task_status', this.todoForm.value['task_status']),
    formData.append('created_by', this.todoForm.value['created_by']),
    formData.append('priority', this.todoForm.value['priority']),
    formData.append('project_name', this.todoForm.value['project_name']),
    formData.append('created_date', this.todoForm.value['created_date']),
    formData.append('task_modify_date', this.todoForm.value['task_modify_date']),
    formData.append('estimate_hours', this.todoForm.value['estimate_hours']),
    formData.append('task_completed_date', this.todoForm.value['task_completed_date']),
    formData.append('hrs_taken_to_complete', this.todoForm.value['hrs_taken_to_complete']),
    formData.append('comment', this.todoForm.value['comment']),
    formData.append('attachment', this.todoForm.value['attachment']),  
    formData.append('module', this.todoForm.value['module']),  

    
    this.mftService.postData("save_todo", formData).subscribe(
      (data: HttpResponse<any>) => {
        this.templateGridApi.refreshCells();
        this.modalService.dismissAll('Submit click');
        if (data.body.result === 'SUCCESS') {
          if (this.todoForm.value['task_pk'] !== "") {
            this.mftService.updatedAlert("SUCCESS");
          } else {
            this.mftService.updatedAlert("FAILURE");
          }
        } else {
          this.mftService.updatedAlert(data.body.data);
        }
        this.loadTemplateList();
      }, (error) => { console.error('There was an error!', error.message); }
    );
  };


  loadTemplateList() {
    const httpParams = new HttpParams().set('client_pk', (this.user.search_client_pk !== "" && this.user.search_client_pk == "All" ? this.user.search_client_pk : '%'));
    this.mftService.loadData("todo_list", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        this.todoList = data.body
        this.templateGridApi.setRowData(data.body);
        this.templateGridApi.refreshCells();
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  templateDataBind(params: any) {
    this.templateGridApi = params.api;
    this.loadTemplateList();
  };


}
