import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MftService } from 'src/app/services/mft.service';
import { PopupModalService } from 'src/app/services/popup-modal.service';

@Component({
  selector: 'app-popup-modal',
  templateUrl: './popup-modal.component.html',
  styleUrls: ['./popup-modal.component.css']
})

export class PopupModalComponent {
  @Input() data: any;

  submitted: boolean = false;
  departmentOptions: any[] = [];
  clientOptions: any[] = [];

  constructor(public activeModal: NgbActiveModal, public modalService: NgbModal, public popupModalService: PopupModalService, private mftService: MftService) { }

  ngOnInit() {
    if (this.data.popup === 'createdepartment') {
      this.departmentForm.patchValue({ department_name: this.data.department_name, department_id: this.data.department_id, department_pk: this.data.department_pk, client_pk: this.data.client_pk });
    }
    if (this.data.popup === 'createproject') {
      this.projectForm.patchValue({ project_department_pk: this.data.project_department_pk, project_id: this.data.project_id, project_name: this.data.project_name, project_pk: this.data.project_pk });
    }
  }

  closeModal(data: any): void {
    this.activeModal.close();
    this.popupModalService.closeModal(data);
  }

  departmentForm = new FormGroup({
    department_pk: new FormControl('',),
    department_name: new FormControl('', [Validators.required,Validators.maxLength(250),Validators.pattern(/^[a-zA-Z0-9 -_]{2,}$/)]), 
    department_id: new FormControl('', []),
    client_pk: new FormControl('', [Validators.required])
  });

  projectForm = new FormGroup({
    project_pk: new FormControl(''),
    project_name: new FormControl('', [Validators.required,Validators.required,Validators.maxLength(250),Validators.pattern(/^[a-zA-Z0-9 -_]{2,}$/)]),
    project_id: new FormControl('', []),
    project_department_pk: new FormControl('', [Validators.required])
  });

  customizeHeadersForm = new FormGroup({
    availableHeaders: new FormControl('', []),
    selectedHeaders: new FormControl('', [Validators.required])
  });

  save_project(content: any) {
    this.submitted = true;
    if (this.projectForm.invalid) {
      return;
    }

    var formData: any = new FormData();
    formData.append('project_name', this.projectForm.value["project_name"]),
    formData.append('project_id', this.projectForm.value["project_id"]),
    formData.append('department_pk', this.projectForm.value["project_department_pk"]),
    formData.append('project_pk', this.projectForm.value["project_pk"]),
    formData.append('project_status', 'ACTIVE'),
    formData.append('department_pk_list', this.projectForm.value["project_department_pk"]);

    this.mftService.postData("save_project", formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.result === 'SUCCESS') {
          this.mftService.updatedAlert(data.body.result);
        } else {
          this.mftService.updatedAlert(data.body.result + '-' + data.body.data);
        }
        this.closeModal(data.body.data);
      },
      (httpError: HttpErrorResponse) => { this.httpErrorHandler(httpError); }
    );
  };

  save_department(content: any) {
    this.submitted = true;
    if (this.departmentForm.invalid) {
      return;
    }

    var formData: any = new FormData();
    formData.append('client_pk', this.departmentForm.value["client_pk"]),
    formData.append('department_name', this.departmentForm.value["department_name"]),
    formData.append('department_id', this.departmentForm.value["department_id"]),
    formData.append('search_client_pk', this.data.search_client_pk),
    formData.append('department_status', 'ACTIVE'),
    formData.append('department_pk', this.departmentForm.value["department_pk"]);

    this.mftService.postData("save_department", formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.result === 'SUCCESS') {
          this.mftService.updatedAlert(data.body.result);
        } else {
          this.mftService.updatedAlert(data.body.result + '-' + data.body.data);
        }
        this.closeModal(data.body.data);
      },
      (httpError: HttpErrorResponse) => { this.httpErrorHandler(httpError); }
    );
  };

  update_status() {
    this.mftService.postData(this.data.httpUrl, this.data.httpParams).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.result === 'SUCCESS') {
          this.mftService.updatedAlert(data.body.result);
          this.mftService.loadData(this.data.redirectHttpUrl, this.data.redircetHttpParams).subscribe(
            (data: HttpResponse<any>) => {
              this.closeModal(data.body);
            },
            (httpError: HttpErrorResponse) => { this.httpErrorHandler(httpError); }
          );
        } else {
          this.mftService.updatedAlert(data.body.result + '-' + data.body.data);
        }
        this.closeModal(data.body.data);
      },
      (httpError: HttpErrorResponse) => { this.httpErrorHandler(httpError); }
    );
  }

  httpErrorHandler(httpError: HttpErrorResponse) {
    if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
      this.popupModalService.openTimeoutModal();
    } else {
      console.error('There was an error!', httpError.message);
    }
  }

  move_right(selectedOption: string) {

    if (selectedOption === 'SINGLE_SELECTION') {
      const availableHeadersLength = this.customizeHeadersForm.value["availableHeaders"]?.length ?? 0;
      for (var i = 0; i < availableHeadersLength; i++) {
        let table_headers_pk = this.customizeHeadersForm.value["availableHeaders"]?.[i];
        let header = this.data.availableHeadersList.find((table_header: { table_headers_pk: number}) => table_header.table_headers_pk === Number(table_headers_pk));
                
        if (header) {
          this.data.selectedHeadersList.push(header);
          
          let headerIndex = this.data.availableHeadersList.findIndex((header: { table_headers_pk: string; }) => header.table_headers_pk === table_headers_pk);
          this.data.availableHeadersList.splice(headerIndex, 1);
        }
      }
    } else {
      const availableHeadersLength = this.data.availableHeadersList.length ?? 0;
      for (var i = 0; i < availableHeadersLength; i++) {
        let header = this.data.availableHeadersList?.[i];
        if (header) {
          this.data.selectedHeadersList.push(header);
        }
      }
      this.data.availableHeadersList = [];
    }
  }

  move_left(selectedOption: string) {
    if (selectedOption === 'SINGLE_SELECTION') {
      const selectedHeadersList = this.customizeHeadersForm.value["selectedHeaders"]?.length ?? 0;
      for (var i = 0; i < selectedHeadersList; i++) {
        let table_headers_pk = this.customizeHeadersForm.value["selectedHeaders"]?.[i];
        let header = this.data.selectedHeadersList.find((table_header: { table_headers_pk: number}) => table_header.table_headers_pk === Number(table_headers_pk));
        
        if (header) {
          this.data.availableHeadersList.push(header);
          
          let headerIndex = this.data.selectedHeadersList.findIndex((header: { table_headers_pk: string; }) => header.table_headers_pk === table_headers_pk);
          this.data.selectedHeadersList.splice(headerIndex, 1);
        }
      }
    } else {
      const selectedHeadersLength = this.data.selectedHeadersList.length ?? 0;
      for (var i = 0; i < selectedHeadersLength; i++) {
        let header = this.data.selectedHeadersList?.[i];        
        if (header) {
          this.data.availableHeadersList.push(header);
        }
      }
      this.data.selectedHeadersList = [];
    }
  }

  move(selectedOption: string) {
    const selectedHeadersLength = this.customizeHeadersForm.value["selectedHeaders"]?.length ?? 0;
    
    // Determine the direction of movement
    const moveUp = selectedOption === 'UP';
    
    // Iterate over the selected headers in reverse order if moving down
    const startIndex = moveUp ? 0 : selectedHeadersLength - 1;
    const endIndex = moveUp ? selectedHeadersLength : -1;
    const step = moveUp ? 1 : -1;
  
    for (let i = startIndex; i !== endIndex; i += step) {
      let table_headers_pk = this.customizeHeadersForm.value["selectedHeaders"]?.[i];
      
      let headerIndex = this.data.selectedHeadersList.findIndex((header: { table_headers_pk: string; }) => header.table_headers_pk === table_headers_pk);
      
      // Check if the header can be moved in the desired direction
      if ((moveUp && headerIndex > 0) || (!moveUp && headerIndex < this.data.selectedHeadersList.length - 1)) {
        // Move the header one step in the desired direction
        const newIndex = moveUp ? headerIndex - 1 : headerIndex + 1;
        
        // Swap the positions of the current header and the header at the new index
        [this.data.selectedHeadersList[headerIndex], this.data.selectedHeadersList[newIndex]] = [this.data.selectedHeadersList[newIndex], this.data.selectedHeadersList[headerIndex]];
      }
    }
  }

  save_customized_header() {
    let selected_table_headers = this.data.selectedHeadersList.map((object: any) => object.table_headers_pk).join('|');
    if (selected_table_headers === "") {
      this.mftService.updatedAlert('Please select atleast 1 column to view');
      this.activeModal.close();
      return;
    }
    const httpParams = new HttpParams()
      .set('user_pk', this.mftService.loggedInUser.getUser().user_pk)
      .set('app_modules_pk', this.data.app_modules_pk)
      .set('selected_table_headers', selected_table_headers)
      .set('customized_headers_pk', this.data.customized_headers_pk === undefined ? "" : this.data.customized_headers_pk);

    this.mftService.postData(this.data.httpUrl, httpParams).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.result.split('-')[0] === 'SUCCESS') {
          this.mftService.updatedAlert('SUCCESS');
          let return_data = { 'selected_table_headers': selected_table_headers, 'customized_headers_pk': data.body.result.split('-')[1] }; 

          let selected_table_headers_pk: string[] = selected_table_headers.split('|');// Split the selected headers from the database
          
          if (this.data.columnDefs && this.data.columnDefs.length > 0) {
            for (let i = 0; i < this.data.columnDefs.length; i++) {
              let colDef = this.data.columnDefs[i];
              if (selected_table_headers_pk.includes(colDef.table_headers_pk.toString())) {
                colDef.hide = false;
                this.data.columnDefs[i] = colDef;
              } else {
                colDef.hide = true;
                this.data.columnDefs[i] = colDef;
              }
            }
  
            for (let i = 0; i < selected_table_headers_pk.length; i++) {
              let colDef = this.data.columnDefs.find((colDef: { table_headers_pk: number; }) => colDef.table_headers_pk === Number(selected_table_headers_pk[i]));
              let colDefIndex = this.data.columnDefs.findIndex((colDef: { table_headers_pk: number; }) => colDef.table_headers_pk === Number(selected_table_headers_pk[i]));
  
              this.data.columnDefs.splice(colDefIndex, 1);
              if (colDef !== undefined) {
                if (colDef.field === this.data.initial_column) {
                  this.data.columnDefs.splice(0, 0, colDef);
                } else {
                  this.data.columnDefs.splice(i, 0, colDef);
                }
              }
            }
  
            this.data.gridApi.setColumnDefs(this.data.columnDefs);
            this.data.gridApi.refreshCells();
            
            let header_index = this.mftService.loggedInUser.getUser().customized_headers_list.findIndex((header: { app_modules_pk: number }) => header.app_modules_pk === this.data.app_modules_pk);
            let temp_customized_headers = this.mftService.loggedInUser.getUser().customized_headers_list.find((header: { app_modules_pk: number }) => header.app_modules_pk === this.data.app_modules_pk)
            
            if (temp_customized_headers !== undefined) {
              temp_customized_headers.selected_table_headers = selected_table_headers;
              this.mftService.loggedInUser.getUser().customized_headers_list.splice(header_index, 1);
              this.mftService.loggedInUser.getUser().customized_headers_list.push(temp_customized_headers);
              /* if (header_index !== -1) {
                this.mftService.loggedInUser.getUser().customized_headers_list.splice(header_index, 1);
              }
              if (temp_customized_headers) {
                this.mftService.loggedInUser.getUser().customized_headers_list.push(temp_customized_headers);
              } */
            } else {
              let customized_headers = { app_modules_pk: this.data.app_modules_pk, user_pk: this.mftService.loggedInUser.getUser().user_pk, selected_table_headers: selected_table_headers, customized_headers_pk: parseInt(data.body.result.split('-')[1]) };
              this.mftService.loggedInUser.getUser().customized_headers_list.push(customized_headers);
            }
            //this.loggedInUser.setUser(this.mftService.loggedInUser.getUser());
          }
          this.closeModal(return_data);
        } else {
          this.mftService.updatedAlert(data.body.result + '-' + data.body.data);
        }
      },
      (httpError: HttpErrorResponse) => { this.httpErrorHandler(httpError); }
    );
  }
}
