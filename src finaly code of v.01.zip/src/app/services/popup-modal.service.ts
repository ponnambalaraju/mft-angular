import { EventEmitter, Injectable } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PopupModalComponent } from 'src/app/components/popup-modal/popup-modal.component';
import { PopupTemplateComponent } from 'src/app/components/popup-template/popup-template.component';

@Injectable({
  providedIn: 'root'
})

export class PopupModalService {

  showModal: EventEmitter<{ show: boolean, data?: any }> = new EventEmitter<{ show: boolean, data?: any }>();
  showMessageAlertPopupModal: EventEmitter<{ show: boolean }> = new EventEmitter<{ show: boolean }>();
  isPopupOpened: boolean = false;

  constructor(private modalService: NgbModal) { }

  openModal(data: any): void {
    const modalRef = this.modalService.open(PopupModalComponent, { backdrop: 'static', ariaLabelledBy: 'modal-basic-title' });
    modalRef.componentInstance.data = data;
    this.showModal.emit({ show: true, data: ''});
  }

  closeModal(data: any): void {
    this.showModal.emit({ show: false, data: data});
  }

  openMessageAlertPopupModal(data: any): void {
    const modalRef = this.modalService.open(PopupTemplateComponent);
    modalRef.componentInstance.data = data;
    this.showMessageAlertPopupModal.emit({ show: true });
  }

  closeMessageAlertPopupModal(): void {
    this.showMessageAlertPopupModal.emit({ show: false });
  }

  openTimeoutModal(): void {
    if (!this.isPopupOpened) {
      this.isPopupOpened = true;
      const modalRef = this.modalService.open(PopupTemplateComponent, { backdrop: 'static', ariaLabelledBy: 'modal-basic-title' });
      let data: any = { };
      data.process = 'Session Expired';
      data.modalMessage = 'Your session has expired. You will be redirected to login page';
      data.yesButtonText = 'OK';
      data.isNoVisible = false;
      modalRef.componentInstance.data = data;
    }
  }

  closeTimeoutModal(): void {
    this.isPopupOpened = false;
  }

  openDuplicateTabModal(): void {
    if (!this.isPopupOpened) {
      this.isPopupOpened = true;
      const modalRef = this.modalService.open(PopupTemplateComponent, { backdrop: 'static', ariaLabelledBy: 'modal-basic-title' });
      let data: any = { };
      data.process = 'Duplicate Session...';
      data.modalMessage = 'Duplicate session not allowed in this application. You will be redirected to login page';
      data.yesButtonText = 'OK';
      data.isNoVisible = false;
      modalRef.componentInstance.data = data;
    }
  }

}
