export const environment = {
    production: false,
    environment: 'DEVELOPMENT',
    mft_context: '/mft2.0'
};