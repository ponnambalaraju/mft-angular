export const environment = {
    production: true,
    environment: 'PRODUCTION',
    mft_context: '/mft2.0'
};