import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtiAmazonS3Component } from './hti-amazon-s3.component';

describe('HtiAmazonS3Component', () => {
  let component: HtiAmazonS3Component;
  let fixture: ComponentFixture<HtiAmazonS3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HtiAmazonS3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HtiAmazonS3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
