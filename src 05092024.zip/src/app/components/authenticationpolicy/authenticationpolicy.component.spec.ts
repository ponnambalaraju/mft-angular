import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthenticationpolicyComponent } from './authenticationpolicy.component';

describe('AuthenticationpolicyComponent', () => {
  let component: AuthenticationpolicyComponent;
  let fixture: ComponentFixture<AuthenticationpolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AuthenticationpolicyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AuthenticationpolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
