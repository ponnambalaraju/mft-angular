import { Component } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { MftService } from 'src/app/services/mft.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Users } from 'src/app/models/users';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { BaseComponent } from '../base/base.component';
import { SelectionChangedEvent } from 'ag-grid-community';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-clientsetup',
  templateUrl: './clientsetup.component.html',
  styleUrls: ['./clientsetup.component.css']
})
export class ClientsetupComponent extends BaseComponent {

  userData: any;
  clientForm: FormGroup;
  button_disable: boolean = true;
  disableAllButtons: boolean = true;
  contactname_error: string = "";
  contactno_error: string = "";
  contactemail_error: string = "";
  clientid_error: string = "";
  clientname_error: string = "";
  primary_contact_name_error: string = "";
  primary_contact_email_error: string = "";
  primary_contact_no_error: any;
  secondary_contact_name_error: string = "";
  secondary_contact_no_error: any;
  secondary_contact_email_error: string = "";
  previewImage: any;

  constructor(public override modalService: NgbModal, private mftServices: MftService, private loggedInUser: Users, private formBuilder: FormBuilder) {
    super(modalService);
    const today = new Date();
    this.clientexpiry_minDate = { year: today.getFullYear(), month: today.getMonth() + 1, day: today.getDate() };
  }

  separateDialCode = false;
  SearchCountryField = SearchCountryField;
  CountryISO = CountryISO;
  PhoneNumberFormat = PhoneNumberFormat;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.India];

  changePreferredCountries() {
    this.preferredCountries = [CountryISO.UnitedStates, CountryISO.India];
  }

  apiUrl: string;
  clientColumnDefs: any;
  RowData: any;
  AgLoad: boolean = true;
  gridApi: any;
  expiry_date: NgbDateStruct;
  selectedDate: NgbDateStruct;
  finalExpiryDate: string;
  clientexpiry_minDate: NgbDateStruct;
  user_pk: string

  ngOnInit() {
    this.clientColumnDefs = [
      { headerName: 'Client PK', field: 'client_pk', hide: true, suppressColumnsToolPanel: true },
      { headerName: 'Client ID', field: 'client_id', sortable: true, filter: true, resizable: true, minWidth: 100, headerCheckboxSelection: true, checkboxSelection: true },
      { headerName: 'Client Name', field: 'client_name', sortable: true, filter: true,  resizable: true, minWidth: 250 },
      { headerName: 'Client Status (Current)', field: 'client_status', sortable: true, filter: true, resizable: true, minWidth: 125, valueGetter: this.getStatusExpiredValue.bind(this) },
      { headerName: 'Client Creation Date', field: 'client_creation_date', sortable: true, filter: true, resizable: true, minWidth: 230 },
      { headerName: 'Client Activation Date', field: 'client_activation_date', sortable: true, filter: true, resizable: true, minWidth: 230 },
      { headerName: 'Client Deactivation Date (Last)', field: 'client_deactivation_date', sortable: true, filter: true, resizable: true, minWidth: 230 },
      { headerName: 'Client Expiry Date', field: 'client_expiry_date', sortable: true, filter: true, resizable: true, minWidth: 230 },
      { headerName: 'No of Triggers Allowed', field: 'number_of_allowed_trigger', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'No of User Allowed', field: 'number_of_allowed_user', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Primary Contact Name', field: 'primary_contact_name', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Primary Contact No', field: 'primary_contact_no', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Primary Email Id', field: 'primary_contact_email', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Secondary Contact Name', field: 'secondary_contact_name', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Secondary Contact No', field: 'secondary_contact_no', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Secondary Email Id', field: 'secondary_contact_email', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Allow HTI Amazon S3', field: 'allow_hti_amazon_s3', sortable: true, filter: true, resizable: true, minWidth: 200 },
      { headerName: 'Allow Fax', field: 'allow_fax', sortable: true, filter: true, resizable: true, minWidth: 200 },
      // { headerName: 'Fax API URL', field: 'fax_api_url', sortable: true, filter: true, resizable: true, minWidth: 200 },
      // { headerName: 'Fax User ID', field: 'fax_user_id', sortable: true, filter: true, resizable: true, minWidth: 200 },
      // { headerName: 'Fax User Password', field: 'fax_user_password', sortable: true, filter: true, resizable: true, minWidth: 200 },
      // { headerName: 'Fax Number', field: 'fax_number', sortable: true, filter: true, resizable: true, minWidth: 200 }
    ];

    this.mftServices.data$.subscribe((value) => {
      this.userData = this.loggedInUser.getUser();
      this.user_pk = this.loggedInUser.getUser().user_pk;
    });

    this.clientForm = this.formBuilder.group({
      client_pk: ['', []],
      client_name: ['', [Validators.required, Validators.maxLength(45),Validators.pattern(/^[a-zA-Z0-9 ]{2,}$/)]],
      client_id: ['', []],
      client_expiry_date: ['', [Validators.required]],
      number_of_allowed_trigger: ['', [Validators.required, Validators.maxLength(45),Validators.pattern(/^[0-9]{1,}$/)]],
      number_of_allowed_user: ['', [Validators.required, Validators.maxLength(45),Validators.pattern(/^[0-9]{1,}$/) ]],
      client_logo: [''],
      primary_contact_name: ['', [Validators.required, Validators.maxLength(45),Validators.pattern(/^[a-zA-Z0-9 ]{2,}$/)]],
      primary_contact_email: ['',[Validators.required, Validators.maxLength(45),Validators.pattern('[a-z0-9._]+@[a-z0-9.-]+\\.[a-z]{2,}$')]],
      primary_contact_no: ['', [Validators.required]],
      secondary_contact_name: ['', []],
      secondary_contact_email: ['',[]],
      secondary_contact_no: ['', [Validators.required]],
      allow_hti_amazon_s3: [],
      allow_fax: [],
    });

    this.clientForm.get('secondary_contact_email')?.valueChanges.subscribe((selected_secondary_contact_email: string) => {
      if (selected_secondary_contact_email !== "") {
        this.clientForm.get('secondary_contact_name')?.setValidators([Validators.required, Validators.maxLength(20),Validators.pattern(/^[a-zA-Z 0-9 ]{2,}$/)]);
        //this.clientForm.get('secondary_contact_no')?.setValidators([Validators.required]);
        this.clientForm.get('secondary_contact_email')?.setValidators([Validators.required, Validators.pattern('[a-z0-9._]+@[a-z0-9.-]+\\.[a-z]{2,}$'), Validators.maxLength(45)]);
      } else {
        this.clientForm.get('secondary_contact_name')?.clearValidators();
        //this.clientForm.get('secondary_contact_no')?.clearValidators();
        this.clientForm.get('secondary_contact_email')?.clearValidators();
      }
      this.clientForm.get('secondary_contact_name')?.updateValueAndValidity();
      //this.clientForm.get('secondary_contact_no')?.updateValueAndValidity();
      this.clientForm.get('secondary_contact_email')?.updateValueAndValidity({ emitEvent: false });
    });

    this.popupModalService.showMessageAlertPopupModal.subscribe((result :{ show: boolean }) => {
      if (!result.show) {
        this.active_disable = true;
        this.deactive_disable = true;
        this.edit_disable = true;
      }
    });
  }

  clientDataBind(params: any) {
    this.gridApi = params.api;

    const httpParams = new HttpParams();
    this.mftServices.loadData("client_list", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        params.api.setRowData(data.body);
        params.api.refreshCells();
        if (data.body.length === 0) {
          this.button_disable = true;
          this.edit_disable = true;
        } else {
          if (this.gridApi.getSelectedRows().length === 0) {
            this.button_disable = true;
            this.edit_disable = true;
          } else {
            this.button_disable = false;
            this.edit_disable = false;
          }
        }
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  }

  onSelectionChanged(event: SelectionChangedEvent) {
    const selectedData = this.gridApi.getSelectedRows();
    this.active_disable = true;
    this.deactive_disable = true;
    this.edit_disable = true;

    if (selectedData.length > 0) {
      const hasActive = selectedData.some((item: { client_status: string }) => item.client_status === "ACTIVE");
      const hasDeactive = selectedData.some((item: { client_status: string }) => item.client_status === "INACTIVE");

      this.disableActiveDeactive(selectedData, hasActive, hasDeactive);
    }
  }

  currentEvent: string;
  open(content:any, clickEvent: string) {
    this.submitted = false;
    this.currentEvent = clickEvent;
    if (clickEvent === "NEW") {
      this.clientForm.patchValue({
        client_pk: '', client_id: '', client_name: '', number_of_allowed_trigger: '', number_of_allowed_user: '', client_expiry_date: '', primary_contact_name: '', secondary_contact_name: '',
        primary_contact_email: '', secondary_contact_email: '', primary_contact_no: '', secondary_contact_no: '', allow_fax: '',
        });
    }

    if (clickEvent === "EDIT") {
      const selectedData = this.gridApi.getSelectedRows();
      const specificDate = new Date(selectedData[0]["client_expiry_date"]);
      const day = specificDate.getDate();
      const month = specificDate.getMonth() + 1;
      const year = specificDate.getFullYear();
      this.selectedDate = { year: year, month: month, day: day };

      this.clientForm.patchValue({
        client_pk: selectedData[0]["client_pk"], client_id: selectedData[0]["client_id"], client_name: selectedData[0]["client_name"], number_of_allowed_trigger: selectedData[0]["number_of_allowed_trigger"],
        client_expiry_date: this.selectedDate, number_of_allowed_user: selectedData[0]["number_of_allowed_user"], primary_contact_name: selectedData[0]["primary_contact_name"],
        secondary_contact_name: selectedData[0]["secondary_contact_name"], primary_contact_email: selectedData[0]["primary_contact_email"],
        secondary_contact_email: selectedData[0]["secondary_contact_email"], primary_contact_no: selectedData[0]["primary_contact_no"].split(' ').join(' '),
        secondary_contact_no: selectedData[0]["secondary_contact_no"].split(' ').join(' '), allow_hti_amazon_s3: selectedData[0]["allow_hti_amazon_s3"], allow_fax: selectedData[0]["allow_fax"],
      });
    }
    const modalRef = this.modalService.open(content, {backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title'});
    modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  };

  save_client() {
    this.contactname_error = "";
    this.contactno_error = "";
    this.contactemail_error = "";
    this.clientid_error = "";
    this.clientname_error = "";

    this.submitted = true;
    if (this.clientForm.invalid) {
      const invalid = [];
      const controls = this.clientForm.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
      if (this.clientForm.controls['secondary_contact_email'].value === '') {
        if (invalid.includes('secondary_contact_no') && invalid.length !== 1) { return; }
      }
      else { return; }
    }

    if (this.currentEvent === 'NEW') {
      /* let client_id_check: boolean = this.checkValueInColumn('client_id', this.clientForm.value['client_id']);
      if (client_id_check) {
        this.clientid_error = "Client ID already exist. Please provide valid Client ID";
        return;
      } */
      let client_name_check: boolean = this.checkValueInColumn('client_name', this.clientForm.value['client_name']);
      if (client_name_check) {
        this.clientname_error = "Client Name already exist. Please provide valid Client Name";
        return;
      }
    }

    if (this.clientForm.value['client_expiry_date'] !== null && this.clientForm.value['client_expiry_date'] !== undefined) {
      let obj: any = this.clientForm.value['client_expiry_date'];
      this.expiry_date = { day: obj['day'], month: obj['month'], year: obj['year'] };
      this.finalExpiryDate = obj['month'] + '/' + obj['day'] + '/' + obj['year'];
    } else {
      alert("Please enter client expiry date");
      return;
    }

    if (this.clientForm.value['primary_contact_name'] === this.clientForm.value['secondary_contact_name']) {
      this.contactname_error = "Primary Contact Name and Secondary Contact Name cannot be same"; return;
    } else if (this.clientForm.value['primary_contact_email'] === this.clientForm.value['secondary_contact_email']) {
      this.contactemail_error = "Primary Contact Email and Secondary Contact Email cannot be same"; return;
    } else if (this.clientForm.value['primary_contact_no'] === this.clientForm.value['secondary_contact_no']) {
      this.contactno_error = "Primary Contact No and Secondary Contact No cannot be same"; return;
    }

    var formData: any = new FormData();
    formData.append('client_pk', this.clientForm.value['client_pk']),
    formData.append('client_id', this.clientForm.value['client_id']),
    formData.append('client_name', this.clientForm.value['client_name']),
    formData.append('client_status', this.gridApi.getSelectedRows().length > 0 ? this.gridApi.getSelectedRows()[0]["client_status"] : ''),
    formData.append('client_creation_date', this.gridApi.getSelectedRows().length > 0 ? this.gridApi.getSelectedRows()[0]["client_creation_date"] : ''),
    formData.append('client_activation_date', this.gridApi.getSelectedRows().length > 0 ? this.gridApi.getSelectedRows()[0]["client_activation_date"] : ''),
    formData.append('client_expiry_date', this.finalExpiryDate),
    formData.append('number_of_allowed_trigger', this.clientForm.value['number_of_allowed_trigger']),
    formData.append('number_of_allowed_user', this.clientForm.value['number_of_allowed_user']),
    formData.append('primary_contact_no', JSON.parse(JSON.stringify(this.clientForm.value["primary_contact_no"])).internationalNumber),
    formData.append('secondary_contact_no',this.clientForm.value['secondary_contact_no'] !== null && this.clientForm.controls['secondary_contact_email'].value !== '' ? JSON.parse(JSON.stringify(this.clientForm.value["secondary_contact_no"])).internationalNumber : '') ,
    formData.append('primary_contact_name', this.clientForm.value['primary_contact_name']),
    formData.append('secondary_contact_name', this.clientForm.controls['secondary_contact_email'].value !== '' ? this.clientForm.value['secondary_contact_name'] : ''),
    formData.append('primary_contact_email', this.clientForm.value['primary_contact_email']),
    formData.append('secondary_contact_email', this.clientForm.value['secondary_contact_email']),
    formData.append('mft_ui_address', this.mftServices.mft_ui_address),
    formData.append('client_logo', this.clientForm.value['client_logo']),
    formData.append('user_created_by', this.user_pk),
    formData.append('allow_hti_amazon_s3', this.clientForm.value['allow_hti_amazon_s3']),
    formData.append('allow_fax', this.clientForm.value['allow_fax']),

    this.mftServices.postData("save_client_user", formData).subscribe(
      (data: HttpResponse<any>) => {
        if (data.body.result === 'SUCCESS') {
          this.mftServices.updatedAlert(data.body.result);
          this.modalService.dismissAll('Save Client');
          this.gridApi.setRowData(data.body.data);
          this.gridApi.refreshCells();

          this.mftService.loggedInUser.getUser().client_list = [];
          this.mftService.loggedInUser.getUser().client_list = data.body.data;
        } else {
          this.modalService.dismissAll('Save Client');
          let popup_data = { process: 'Failure', modalMessage: data.body.data, yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
        }
      },
      (httpError: HttpErrorResponse) => { super.httpErrorHandler(httpError); }
    );
  };

  functionCallback = function (data: any): void {
    const elements = document.querySelectorAll(".modal-dialog");

    elements.forEach((element: Element) => {
      const htmlElement = element as HTMLElement;
      if (htmlElement.style) {
        htmlElement.style.display = "block";
      }
    });
  };

  onFileSelected(event: any): void {

    let dotIndex = event.target.files[0].name.lastIndexOf('.');
    this.previewImage = event.target.files[0];

    if (dotIndex !== -1) {
      let fileType = event.target.files[0].name.substring(dotIndex + 1).toLowerCase();
      if (fileType === 'jpeg' || fileType === 'jpg' || fileType === 'png') {
        let fileSize = event.target.files[0].size
        if (fileSize < 500000 ) {
          this.clientForm.patchValue({ client_logo: event.target.files[0] });
          this.clientForm.get('client_logo')?.updateValueAndValidity();
        } else {
          this.clientForm.patchValue({ client_logo: '' });
          this.clientForm.get('client_logo')?.updateValueAndValidity();
          let popup_data = { process: 'Failure', modalMessage: 'File size exceeds the allowed limit. Please upload less than 0.5MB size file.', yesButtonText: 'OK', isNoVisible: false };
          this.popupModalService.openMessageAlertPopupModal(popup_data); return;
        }
      } else {
        this.clientForm.patchValue({ client_logo: '' });
        this.clientForm.get('client_logo')?.updateValueAndValidity();
        let popup_data = { process: 'Failure', modalMessage: 'Invalid image type. Please upload an image file. ', yesButtonText: 'OK', isNoVisible: false };
        this.popupModalService.openMessageAlertPopupModal(popup_data); return;
      }
    }
    this.clientForm.patchValue({ client_logo: '' });
    this.clientForm.get('client_logo')?.updateValueAndValidity();
    let popup_data = { process: 'Failure', modalMessage: 'Invalid image type. Please upload an image file. ', yesButtonText: 'OK', isNoVisible: false };
    this.popupModalService.openMessageAlertPopupModal(popup_data); return;
  };

  remove_client_logo() {
    this.clientForm.patchValue({ client_logo: '' });
    this.clientForm.get('client_logo')?.updateValueAndValidity();
  }

  previewImageUrl: string;

  preview_client_logo(content: any){

        var reader = new FileReader();
        reader.readAsDataURL(this.previewImage);
        reader.onload = () => {
          this.previewImageUrl = reader.result as string;
        };
        const modalRef = this.modalService.open(content, {backdrop: 'static', centered: true, ariaLabelledBy: 'modal-basic-title'});
        modalRef.result.then((result) => {
          this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }


  checkValueInColumn(columnId: string, searchValue: any): boolean {
    let duplicateFound = false;
    this.gridApi.forEachNode((node: any) => {
      const cellValue = this.gridApi.getValue(columnId, node);
      if (cellValue === searchValue) {
        duplicateFound = true;
        return; // Exit the forEachNode loop early if the value is found
      }
    });
    return duplicateFound;
  };

  getStatusExpiredValue(params: any) {
    if (params.data.client_expiry_date !== null && new Date(params.data.client_expiry_date) < new Date()) {
      return params.data.client_status + ' / EXPIRED';
    } else {
      return params.data.client_status;
    }
  }

}
