import { Component, ElementRef, EventEmitter, Input, Output, forwardRef } from '@angular/core';
import { BaseComponent } from '../base/base.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-password-input',
  templateUrl: './password-input.component.html',
  styleUrls: ['./password-input.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => PasswordInputComponent),
      multi: true,
    },
  ],
})
export class PasswordInputComponent extends BaseComponent implements ControlValueAccessor {
  @Input() ngModelName: string = '';
  @Input() childValue: string;

  constructor(public override modalService: NgbModal, public el: ElementRef) { super(modalService); }

  @Output() passwordChange = new EventEmitter<string>();
  showPassword: boolean = false;

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  getPasswordValue(): string {
    return this.ngModelName;
  }

  // Method to get the input field value
  getInputValue() {
    return this.el.nativeElement.querySelector('input').value;
  }

  password: string = '';
  isStrongPassword: boolean = false;
  passwordStrength: number = 0;

  // Implement ControlValueAccessor interface
  onChange: any = () => {};
  onTouch: any = () => {};

  writeValue(value: any) {
    this.password = value;
    this.onChange(value);
    this.onTouch();
  }

  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouch = fn;
  }

}
