import { Component, Input, OnChanges, SimpleChanges, Output, EventEmitter, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { FileElement } from './model/element';
import { MatMenuTrigger } from '@angular/material/menu';
import { MatDialog } from '@angular/material/dialog';
import { NewFolderDialogComponent } from './modals/newFolderDialog/newFolderDialog.component';
import { RenameDialogComponent } from './modals/renameDialog/renameDialog.component';
import { MftService } from 'src/app/services/mft.service';
import { HttpErrorResponse, HttpParams, HttpResponse } from '@angular/common/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { v4 as uuidv4 } from 'uuid';
import { EncryptionService } from '../services/encryption.service';
import { WizardComponent } from '../components/wizard/wizard.component';
import * as XLSX from 'xlsx';
import * as Papa from 'papaparse';

@Component({
  selector: 'file-manager',
  templateUrl: './file-manager.component.html',
  styleUrls: ['./file-manager.component.css']
})
export class FileManagerComponent {
  fileInput: HTMLInputElement;
  sheetNames: any;
  sheet: HTMLInputElement;
  @ViewChild('sheetSelectionDialog', { static: true }) sheetNameDialog!: ElementRef;
  selectedSheetName: string = '';
  file: any;
  fileType: any;
  isPopupOpenSheet: boolean;
  ext_file_content: any;
  isPopupOpenFile: boolean;
  isLoading: boolean;
  filename: any;


  constructor(public dialog: MatDialog, public modalService: NgbModal, private mftServices: MftService,
    private loadDatasets: WizardComponent, private router: Router, private encryptionService: EncryptionService) {
  }
  @Input() fileElements: FileElement[];
  @Input() canNavigateUp: string;
  @Input() path: string;

  @Output() folderAdded = new EventEmitter<{ name: string }>();
  @Output() elementRemoved = new EventEmitter<FileElement>();
  @Output() elementRenamed = new EventEmitter<FileElement>();
  @Output() navigatedDown = new EventEmitter<FileElement>();
  @Output() elementMoved = new EventEmitter<{ element: FileElement; moveTo: FileElement }>();
  @Output() navigatedUp = new EventEmitter();

  isPopupOpen = false;
  selectedFiles: any;
  files: any[] = [];
  folderOptions: any[] = [];
  otherfolder: string = '';
  parsedData: any[] = [];
  headers: string[];
    rows: any[] = [];

  ngOnInit(): void {
    this.mftServices.data$.subscribe((value) => {
      this.loadActiveDataintegration();
    });
  }


  deleteElement(element: FileElement) {
    this.elementRemoved.emit(element);
  }
  public wizard = { wizard_pk: '', wizard_id: ''}
  navigate(element: FileElement) {
    this.wizard.wizard_pk = element.wizard_pk ?? '';
    this.wizard.wizard_id = element.wizard_id ?? '';
    if (element.isFolder) {
      this.navigatedDown.emit(element);
    }
  }

  navigateUp() {
    this.navigatedUp.emit();
  }

  moveElement(element: FileElement, moveTo: FileElement) {
    this.elementMoved.emit({ element: element, moveTo: moveTo });
  }

  openNewFolderDialog() {
    let dialogRef = this.dialog.open(NewFolderDialogComponent);
    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        this.folderAdded.emit({ name: res });
      }
    });
  }

  openRenameDialog(element: FileElement) {
    let dialogRef = this.dialog.open(RenameDialogComponent);
    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        element.folder_name = res;
        this.elementRenamed.emit(element);
      }
    });
  }

  openMenu(event: MouseEvent, element: FileElement, viewChild: MatMenuTrigger) {
    event.preventDefault();
    viewChild.openMenu();
  }
  openFile(element: FileElement) {
    this.router.navigate(['/etl/wizard/fileviewer'], {
      state: { fileElement: element }
    });
  }

  openUploadPopup() {
    this.isPopupOpen = true;
  }

  onFileChange(event: any): void {
    this.selectedFiles= event.target.files;
    if (!this.selectedFiles || this.selectedFiles.length <= 0) {
      alert('Please select a file to upload!');
      return;
    } else {
      const formData: any = new FormData();
      this.file = this.selectedFiles[0];
      this.fileType = this.file.name.substring(this.file.name.lastIndexOf('.') + 1);
      this.filename = this.file.name
      formData.append('file', this.file);
      formData.append('file_type', this.fileType);
      if (this.fileType === 'xlsx' || this.fileType === 'xls'){
        this.mftServices.postData("get_sheet_name", formData).subscribe(
          (data: HttpResponse<any>) => {
            if (data.body.status === 'SUCCESS') {
              this.sheetNames = data.body.sheets;
              this.openSheetSelectionDialog();
            } else if (data.body.status === 'FAILURE') {
              this.mftServices.updatedAlert(data.body.message);
            }
          },
          error => {
            console.error(error);
            this.mftServices.updatedAlert("An unexpected error occurred.");
          }
        );
      }
      else{ this.upload_datasets(this.file); }
      this.fileInput.value = '';
    }
}

upload_datasets(file: File){
  const formData: any = new FormData();
  const uploadDatasets = {
    dataset_pk : '',
    parent_folder_id : this.wizard.wizard_id,
    dataset_id : uuidv4(),
    user_pk : this.mftServices.loggedInUser.getUser().user_pk,
    client_pk : this.mftServices.loggedInUser.getUser().client_pk,
    wizard_pk : this.wizard.wizard_pk,
    file_name: file.name,
    file_size: file.size,
    file_type: file.name.substring(file.name.lastIndexOf('.') + 1),
    created_at : ''
  };
  let Data = this.encryptionService.encrypt(JSON.stringify(uploadDatasets));
  formData.append('file', file);
  formData.append('datasets_Data', Data);
  this.mftServices.postData("upload_datasets", formData).subscribe(
    response => {
      if (response.body && (response.body as any)['message'].includes('SUCCESS')) {
        this.mftServices.updatedAlert("Upload Success.");
        this.isPopupOpen = false;
        this.loadDatasets.loadDataSets();

      } else {
        this.mftServices.updatedAlert("Failed to Upload Datasets.");

      }
      this.modalService.dismissAll('Update User');
    },
    error => { console.error(error); }
  );
}

openSheetSelectionDialog() {
  this.sheetNameDialog.nativeElement.style.display = 'block';
}

onSheetSelect(name: string) {
  this.isPopupOpen = false;
  this.sheetNameDialog.nativeElement.style.display = 'none';
  this.isRowPopupOpen = true;
  if (this.selectedSheetName === name) {
    this.selectedSheetName = '';
  } else {
    this.selectedSheetName = name;
  }
  console.log('Selected sheet:', this.selectedSheetName);
}

isRowPopupOpen = false;
startRow: number | null = null;
endRow: number | null = null;

onRowSelectionConfirm() {
  this.isPopupOpen = false;
  this.isRowPopupOpen = false;
  const formData: any = new FormData();
      formData.append('file', this.file);
      formData.append('file_type', this.fileType);
      formData.append('sheet_name', this.selectedSheetName);
      formData.append('start_row', this.startRow);
      formData.append('end_row', this.endRow);
      this.mftServices.postData("extract_row", formData).subscribe(
        (data: HttpResponse<any>) => {
          if (data.body.status === 'SUCCESS') {
            this.ext_file_content = data.body.file;
            this.fileType = data.body.filetype;
            this.parseFileContent();
            this.openPopup();
            this.isLoading = false;
          } else if (data.body.status === 'FAILURE') {
            this.mftServices.updatedAlert(data.body.message);
          }
        },
        error => {
          console.error(error);
          this.mftServices.updatedAlert("An unexpected error occurred.");
        }
      );
}

skipProcess(){
  this.upload_datasets(this.file);
}
parseFileContent() {
  const binaryContent = atob(this.ext_file_content); // Decode Base64
  if (this.fileType === 'csv') {
    Papa.parse(binaryContent, {
      delimiter: ',',
      header: true,
      complete: (result) => {
        this.parsedData = result.data;
        this.headers = Object.keys(this.parsedData[0] || {});
        this.rows = this.parsedData;
        this.isLoading = false;
      },
      error: (error: any) => {
        console.error('Error parsing CSV/TSV file:', error);
        this.isLoading = false;
      }
    });
  } else if (this.fileType === 'xls' || this.fileType === 'xlsx') {
    try {
      const workbook = XLSX.read(binaryContent, { type: 'binary' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

      const parsedJson = this.convertXlsxToJson(jsonData);
      this.headers = Object.keys(parsedJson[0] || {});
      this.rows = parsedJson;
    } catch (error) {
      console.error('Error processing XLSX file:', error);
    } finally {
      this.isLoading = false;
    }
  }
}

convertXlsxToJson(sheetData: any[]): any[] {
  const headers = sheetData[0];
  const rows = sheetData.slice(1);
  return rows.map(row => {
    const obj: any = {};
    row.forEach((cell: any, index: number) => {
      obj[headers[index]] = cell;
    });
    return obj;
  });
}

openPopup() {
  this.isPopupOpenFile = true;
  // Logic to open the popup where the table will be displayed
}

closeRowPopup() {
  this.isRowPopupOpen = false;
  this.isPopupOpenFile = false;

}

closeUploadPopup() {
  this.isPopupOpen = false;
  this.sheetNameDialog.nativeElement.style.display = 'none';
}

uploadExtDataset(){
  if (this.headers.length === 0 || this.rows.length === 0) {
    alert('No data to process.');
    return;
  }

  // Create worksheet
  const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.rows, { header: this.headers });

  // Create workbook and add worksheet
  const wb: XLSX.WorkBook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, this.selectedSheetName);

  // Create a Blob from the workbook
  const wbout: any = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob: Blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

  // Create a File object
  const file: File = new File([blob], this.filename, { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  this.isPopupOpenFile = false;
  this.upload_datasets(file);

}

isValid(form: any): boolean {
  return (this.startRow !== null || this.endRow === null) && form.form.valid;
}
getFileIcon(mimetype: string): string {
  switch (mimetype) {
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
      return 'assets/images/xlsx.png';
    case 'text/tab-separated-values':
      return 'assets/images/tsv.png';
    case 'application/json':
      return 'assets/images/json.png';
    case 'text/csv':
      return 'assets/images/csv.png';
    default:
      return 'assets/images/default.png';
  }
}


  selectFolder(dataintegration: any): void {
    if (dataintegration.dataintegration_pk === 1) {
      this.fileInput = document.getElementById('file') as HTMLInputElement;
      this.fileInput.click();
    }
    console.log('Selected folder:', dataintegration);
  }


  loadActiveDataintegration(): void {
    const httpParams = new HttpParams();
    this.mftServices.loadData("load_active_dataintegration", httpParams).subscribe(
      (data: HttpResponse<any>) => {
        data.body.forEach((obj: any) => {
          if (this.otherfolder.includes(obj.dataintegration_pk.toString())) {
            obj.dataintegration_status = true;
          } else {
            obj.dataintegration_status = false;
          }
        });
        this.folderOptions = data.body;
      },
      (httpError: HttpErrorResponse) => {
        if (httpError instanceof HttpErrorResponse && httpError.status === 401) {
          console.error('Popup model', httpError.message);
        } else {
          console.error('There was an error!', httpError.message);
        }
      }
      );
  }

}
