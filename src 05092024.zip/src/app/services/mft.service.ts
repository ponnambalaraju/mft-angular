import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { PlatformLocation } from '@angular/common';
import { Users } from '../models/users';


@Injectable({
  providedIn: 'root'
})

export class MftService {
  httpErrorHandler(httpError: HttpErrorResponse) {
    throw new Error('Method not implemented.');
  }

  urlAddress: string = new URL(window.location.href).hostname === 'localhost' || new URL(window.location.href).hostname === '127.0.0.1' ? 'http://' + new URL(window.location.href).hostname + ':5000' : new URL(window.location.href).origin;
  session_id: string | undefined = '';
  totalAngularPackages: any;
  errorMessage: any;
  loggedInUser: Users;
  public mft_ui_address: string;
  getActiveFolders: any;


  constructor(private http: HttpClient, private platformLocation: PlatformLocation, private loggedUser: Users) {
    // Use PlatformLocation to get the complete URL
    const protocol = this.platformLocation.protocol;
    const hostname = this.platformLocation.hostname;
    const port = this.platformLocation.port;
    const baseHref = this.platformLocation.getBaseHrefFromDOM();

    // Construct the complete URL
    this.mft_ui_address = `${protocol}//${hostname}:${port}${baseHref}`;
    this.loggedInUser = this.loggedUser;
  }

  private dataSubject: BehaviorSubject<string> = new BehaviorSubject<string>('Initial Value');
  data$ = this.dataSubject.asObservable();

  private popupSubject: BehaviorSubject<string> = new BehaviorSubject<string>('');
  successMessage$ = this.popupSubject.asObservable();
  dangerMessage$ = this.popupSubject.asObservable();

  updateData(value: string) {
    this.dataSubject.next(value);
  }

  updatedAlert(value: string) {
    this.popupSubject.next(value);
  }

  public loadData(url: string, params: HttpParams) {
    return this.http.get<any>(this.urlAddress + environment.mft_context + '/' + url, { params: params, observe: 'response', withCredentials: true });
  }

  public postData(url: string, params: HttpParams) {
    var result = this.http.post(this.urlAddress + environment.mft_context + '/' + url, params, { observe: 'response', withCredentials: true });
    return result;
  }

  downloadFile(file_audit_pk_list: string): Observable<HttpResponse<Blob>> {

    //const params = new HttpParams().set('file_audit_pk_list', file_audit_pk_list);
    //return this.http.get<any>(this.urlAddress + '/download', { params: params, observe: 'response', withCredentials: true });

    const url = this.urlAddress + '/file_download?file_audit_pk_list=' + file_audit_pk_list; // Replace with your actual API endpoint
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      // Add any additional headers needed for your API
    });

    // Set the responseType to 'blob' to handle binary data
    return this.http.get(url, {
      headers: headers,
      observe: 'response',
      responseType: 'blob',
      withCredentials: true
    });
  }

  aws_s3_download_files(file_list: string, client_pk: string): Observable<HttpResponse<Blob>> {
    let url = this.urlAddress + environment.mft_context + '/aws_s3_download_files?file_list=' + file_list + '&client_pk=' + client_pk;
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return this.http.get(url, {
      observe: 'response',
      responseType: 'blob',
      withCredentials: true,
      headers: headers
    });
  }


}
